 BEGIN; 
 CREATE OR REPLACE FUNCTION "int".int_classval_for_class_prop_object_check(
	iid_class_prop bigint,
	iid_classval bigint)
    RETURNS text
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL SAFE 
    SET search_path=bpd, "int"
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 27.02.2025
    --Автор: Иванов Д.Ю.
    --Версия: 1.0
    --Описание: Функция проверяет класс значение объектного свойства класса на допустимость
    --**************************************************************************
    classval "bpd"."class"%ROWTYPE; --Класс значение
	class_prop "bpd"."class_prop"%ROWTYPE; --Свойство класса
    classcarrier "bpd"."class"%ROWTYPE; --Класс носитель
	inherited_object_data "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения наследуемого объектного свойства
	global_prop_area_val bigint; --Область значения глобального свойства
    --*********************************************************
    action_state character varying DEFAULT 'action_allowed'; --Статус действия
BEGIN 
	--Шаг №01 Запрашиваем проверяемые сущности
	SELECT * INTO classval FROM ONLY "bpd"."class" WHERE id = iid_classval;
	IF (classval IS NULL) THEN
        RETURN 'class_val_not_found';
	ELSE
		SELECT * INTO class_prop FROM ONLY "bpd"."class_prop" WHERE id = iid_class_prop;
		IF (class_prop IS NULL) THEN
			RETURN 'class_prop_not_found';
		ELSE
			SELECT * INTO classcarrier FROM ONLY "bpd"."class" WHERE id = class_prop.id_class;
			IF (classcarrier IS NULL) THEN
				RETURN 'class_carrier_not_found';
			END IF;
		END IF;	
	END IF;

	--Шаг №02 Проверяем класс значение на общие признаки
	IF NOT (classval."on_abstraction") THEN
		RETURN 'class_val_not_abstraction';
	ELSE
		IF NOT(classval."on") THEN
			RETURN 'class_val_not_on';
		END IF;
	END IF;

	--Шаг №03 Проверяем класс значение на нахождение в корзине и совпадение концепций
	IF EXISTS(SELECT FROM "bpd"."group" g 
		JOIN "bpd"."conception" c ON c.id = g.id_con
		WHERE g.id = c.group_recycle AND c.id = classval.id_con AND g.id = classval.id_group_root) THEN
		RETURN 'class_val_in_recycle_space';
	ELSE
		IF (classval.id_con <> class_prop.id_conception) THEN
			RETURN 'class_val_conception_not_match';
		END IF;	
	END IF;

	--Шаг №04 Проверяем класс значение и класс свойства не циклические ссылки
	--Определяем вхождение класса значения в ветвь класса носителя свойства
	IF EXISTS(WITH 
				RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
					(SELECT 
						rp."id",
						rp."id_parent",
						0,
						ARRAY [rp."id"],
						false
					FROM ONLY "bpd"."class" rp
					WHERE rp."id" = class_prop.id_class
				UNION all
				SELECT 
					rpc."id",
					rpc."id_parent",
					rpos."level" + 1,
					rpos."patch" || ARRAY [rpc."id"],    
					rpc."id" = ANY(rpos."patch")
				FROM ONLY "bpd"."class" rpc
				JOIN rpos ON rpos."id" = rpc."id_parent"
				WHERE NOT "cycle") 
				SELECT FROM rpos WHERE id = classval.id) THEN
				
		RETURN 'class_val_include_branch_class_carrier';
	ELSE
		--Определяем вхождение класса носителя в ветвь класса значения свойства
		IF EXISTS(WITH 
					RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
						(SELECT 
							rp."id",
							rp."id_parent",
							0,
							ARRAY [rp."id"],
							false
						FROM ONLY "bpd"."class" rp
						WHERE rp."id" = classval.id
					UNION all
					SELECT 
						rpc."id",
						rpc."id_parent",
						rpos."level" + 1,
						rpos."patch" || ARRAY [rpc."id"],    
						rpc."id" = ANY(rpos."patch")
					FROM ONLY "bpd"."class" rpc
					JOIN rpos ON rpos."id" = rpc."id_parent"
					WHERE NOT "cycle") 
					SELECT * FROM rpos WHERE id = class_prop.id_class) THEN
			RETURN 'class_carrier_include_branch_class_val';
		END IF;
	END IF;

	IF class_prop.inheritance THEN
		--Шаг №05.1 Проверяем класс значение для наследованного свойства
		--Запрашиваем данные значения наследуемого свойства
		SELECT * INTO inherited_object_data   
			FROM ONLY "bpd"."vclass_prop_object_val" 
			WHERE id_class_prop = class_prop.id_prop_inherit;

		IF  (inherited_object_data IS NULL) THEN
			RETURN 'inherited_object_data_not_set';
		ELSE
			IF NOT(inherited_object_data.on_val) THEN 
				RETURN 'inherited_object_data_class_val_not_set';
			ELSE
				--Определяем вхождение указанного класса значения в ветвь класса значения наследуемого свойства
				IF NOT EXISTS(WITH
							RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
							(SELECT 
									rp."id",
									rp."id_parent",
									0,
									ARRAY [rp."id"],
									false
									FROM ONLY "bpd"."class" rp
								WHERE rp."id" = inherited_object_data.id_class_val
							UNION all
								SELECT 
								rpc."id",
								rpc."id_parent",
								rpos."level" + 1,
								rpos."patch" || ARRAY [rpc."id"],    
								rpc."id" = ANY(rpos."patch")
								FROM ONLY "bpd"."class" rpc
								JOIN rpos ON rpos."id" = rpc."id_parent"
								WHERE NOT "cycle") 
							SELECT * FROM rpos WHERE id = classval.id) THEN
					
					RETURN 'class_val_not_include_branch_class_val_inherited_class_prop';                                
				END IF;
			END IF;
		END IF;
	ELSE
		--Шаг №05.1 Проверяем класс значение для определяющего свойства связанного с глобальным	
		IF EXISTS(SELECT FROM ONLY bpd.class_prop cp
     				LEFT JOIN bpd.global_prop_link_class_prop lgp 
					ON lgp.id_class_prop_definition = cp.id_prop_definition
					WHERE cp.id = class_prop.id) THEN
			
			--Определяем вхождение указанного класса значения в ветвь класса значения наследуемого свойства
			SELECT gp.id_area_val INTO global_prop_area_val FROM bpd.global_prop gp
					JOIN bpd.global_prop_link_class_prop lgp ON lgp.id_global_prop = gp.id
					JOIN ONLY bpd.class_prop cp ON cp.id_prop_definition = lgp.id_class_prop_definition
					WHERE cp.id = class_prop.id;
					
			IF NOT EXISTS(WITH
						RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
						(SELECT 
								rp."id",
								rp."id_parent",
								0,
								ARRAY [rp."id"],
								false
								FROM ONLY "bpd"."class" rp
							WHERE rp."id" = global_prop_area_val
						UNION all
							SELECT 
							rpc."id",
							rpc."id_parent",
							rpos."level" + 1,
							rpos."patch" || ARRAY [rpc."id"],    
							rpc."id" = ANY(rpos."patch")
							FROM ONLY "bpd"."class" rpc
							JOIN rpos ON rpos."id" = rpc."id_parent"
							WHERE NOT "cycle") 
						SELECT * FROM rpos WHERE id = classval.id) THEN
				
				RETURN 'class_val_not_include_branch_class_val_global_prop';                                
				END IF;
			
		END IF;
	END IF;

	RETURN action_state;
END;
$BODY$;

ALTER FUNCTION "int".int_classval_for_class_prop_object_check(bigint, bigint)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION "int".int_classval_for_class_prop_object_check(bigint, bigint) TO base_level WITH GRANT OPTION;

GRANT EXECUTE ON FUNCTION "int".int_classval_for_class_prop_object_check(bigint, bigint) TO funcowner;

REVOKE ALL ON FUNCTION "int".int_classval_for_class_prop_object_check(bigint, bigint) FROM PUBLIC;


 END;
 BEGIN; 
 CREATE OR REPLACE FUNCTION bpd.class_allowed_rl2_for_group_by_id_position(IN iid_position bigint,IN iid_group bigint)
    RETURNS SETOF bpd.vclass
    LANGUAGE 'plpgsql'
    STABLE SECURITY DEFINER
    PARALLEL SAFE
    COST 100    ROWS 1000 
    
    SET search_path=bpd
AS $BODY$
DECLARE
	--**************************************************************************
    --ДАТА: 15.06.2021
    --Автор: Иванов Д.Ю.
    --Версия: 3.0
    --Описание: Функция возвращает список разрешенных активных классов с учетом разрешения уровня 2 класс на позицию для выбранной группы по идентификатору позиции
    --**************************************************************************
	class_array BIGINT[]; --Массив объектов
BEGIN
	--Проверка активации списка разрешающих правил уровня 2 класс на позицию для указанной позиции
	
	IF EXISTS(SELECT FROM "bpd"."rulel2_class_on_position" rl2 
											WHERE rl2.id_position = iid_position) THEN
		class_array = (WITH 
			RECURSIVE rclass(id_path, id, id_parent, level, path, cycle) AS (
			 SELECT 
				rc.id,
				rc.id,
				rc.id_parent,
				0,
				ARRAY[rc.id] AS "array",
				false AS bool
			   FROM ONLY bpd.class rc WHERE
					EXISTS(SELECT FROM "bpd"."rulel2_class_on_position" rl2 WHERE (rl2.id_class = rc.id)
							AND (rl2.id_position = iid_position) AND (rc.id_group = iid_group))
			UNION ALL
			 SELECT rclass_1.id_path,
				rcc.id,
				rcc.id_parent,
				rclass_1.level + 1,
				ARRAY[rcc.id] || rclass_1.path,
				rcc.id = ANY (rclass_1.path)
			   FROM ONLY bpd.class rcc
				 JOIN rclass rclass_1 ON rclass_1.id = rcc.id_parent
			  WHERE NOT rclass_1.cycle
			), 
				classgroup(id_path, id) AS (
			 SELECT DISTINCT rc.id_path, 
				first_value(rc.id) OVER (PARTITION BY rc.id ORDER BY rc.level DESC) AS first_value
			   FROM rclass rc
			)
	 	SELECT array_agg(cp.id) FROM classgroup cp);
		 
		RETURN QUERY SELECT * FROM int.int_vclass_by_id_array(class_array);						
	ELSE
		RETURN QUERY SELECT * FROM bpd.class_allowed_rl1_by_id_position(iid_position) c WHERE
				(c.id_group = iid_group) AND c.is_root;
	END IF;
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.group_move(IN iid bigint,IN iid_parent bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, ext, err
AS $BODY$

DECLARE
    --ОГРАНИЧЕНИЯ МЕТОДА
    --1. Нельзя изменить концепцию группы
    --2. Нельзя переместить корзину
    --3. Нельзя переместить группу во вложенные в группу группы или в саму себя
    --4. Нельзя переносить группу содержащую классы в пространство корзины
    --**************************************************************************
    --ДАТА: 13.06.2020
    --Версия: 2.1 
    --Автор: Иванов Д.Ю.
    --Описание: Функция перемещает группу
    --**************************************************************************
    group_recycle "bpd"."group"%ROWTYPE; --Группа корзины концепции
    
    mgroup "bpd"."group"%ROWTYPE; --Переносимая группа
    mgroup_name_is_unique BOOLEAN DEFAULT  FALSE; -- Имя переносимой группы уникально в указанном расположении
    
    pgroup "bpd"."group"%ROWTYPE; --Новая родительская группа
    pgroup_is_recycle BOOLEAN DEFAULT FALSE; --целевая группа корзина
    
    --1. Не допускается перенос группы в саму себя
    --2. Недопускается перенос группы в дочерниии группы
    on_moving_correct BOOLEAN DEFAULT FALSE; --перенос коррктен и отвечает базовым правилам построения дерева
    
    iid_moved_class BIGINT; -- ИДЕНТИФИКАТОРЫ ПЕРЕМЕЩЕННЫХ КЛАССОВ
    
    childgroup RECORD; -- дочерние группы переносимой группы
    
    action_timestamp timestamp; -- Время создания группы
    action_state character varying DEFAULT 'none'; --Статус действия    
BEGIN
    --ВЫБИРАЕМ ГРУППУ ПОДЛЕЖАЩУЮ ПЕРЕНОСУ
    SELECT * INTO mgroup FROM "bpd"."group" WHERE id = iid;
    IF (mgroup IS NULL) THEN
        action_state = 'group_moved_not_found';
    ELSE
        --ОПРЕДЕЛЯЕМ ГРУПУУ КОРЗИНЫ ТЕКУЩЕЙ КОНЦЕПЦИИ
        SELECT g.* INTO   group_recycle   FROM "bpd"."group" g 
        JOIN "bpd"."conception" c ON c.id = g.id_con
        WHERE g.id = c.group_recycle AND c.id = mgroup.id_con;
        --ОПРЕДЕЛЯЕМ ЯВЛЯЕТСЯ ЛИ ПЕРЕНОСИМАЯ ГРУППА КОРЗИНОЙ
        IF (mgroup.id = group_recycle.id) THEN
            action_state = 'group_moved_is_recycle';
        ELSE
            --ОПРЕДЕЛЯЕМ ЯВЛЯЕТСЯ ЛИ НОВОЕ РОДИТЕЛЬСКАЯ ПОЗИЦИЯ КОРЗИНОЙ ИЛИ УДАЛЕННОЙ ГРУППОЙ
            IF (iid_parent > 0) THEN
                SELECT * INTO pgroup FROM "bpd"."group" WHERE id = iid_parent;
                IF (pgroup IS NULL) THEN
                    action_state = 'group_target_not_found';
                ELSE
                    IF (mgroup.id_con <> pgroup.id_con) THEN
                        action_state = 'conception_not_match';
                    ELSE    
                        --Проверяем является ли целевая группа корзиной или входит в корзину
                        IF (group_recycle.id = pgroup.id) THEN
                            pgroup_is_recycle = TRUE;
                            action_state = 'moved_allowed';
                        ELSE
                            IF (group_recycle.id = pgroup.id_root) THEN
                                action_state = 'group_target_in_recycle_space';
                            ELSE
                                IF (pgroup.on_class) THEN
                                    action_state = 'group_target_not_include_child_group';
                                ELSE
                                    action_state = 'moved_allowed';
                                END IF;        
                            END IF;    
                        END IF; 
                    END IF;    
                END IF;
            ELSE
                IF (iid_parent = 0) THEN
                    action_state = 'moved_allowed';
                END IF;    
            END IF;    
        END IF;

        IF (action_state = 'moved_allowed') THEN
            --ОПРЕДЕЛЯЕМ ДОПУСТИМОСТЬ ИМЕНИ ПЕРЕНОСИМОЙ ПОЗИЦИИ В НОВОМ РАСПОЛОЖЕНИИ
            IF (pgroup_is_recycle ) THEN
                mgroup_name_is_unique = TRUE;
            ELSE    
                mgroup_name_is_unique = NOT EXISTS(SELECT FROM "bpd"."group" g
                                    WHERE (LOWER(g."name") = LOWER(mgroup.name)) AND (g.id_con = mgroup.id_con) AND (g.id_parent = iid_parent));
            END IF;

            IF NOT(mgroup_name_is_unique) THEN
                action_state = 'group_moved_name_not_unique';
            ELSE
                --ОПРЕДЕЛЯЕМ СПИСОК ГРУПП ПОДЛЕЖАЩИХ ПЕРЕНОСУ
                CREATE TEMP TABLE groupmove ON COMMIT DROP AS
                WITH 
                    RECURSIVE rpos ("id", "id_parent", "level", "path", "cycle") AS 
                        (SELECT 
                            rp."id",
                            rp."id_parent",
                            0,
                            ARRAY [rp."id"],
                            FALSE
                        FROM "bpd"."group" rp
                        WHERE rp."id" = iid
                    UNION all
                        SELECT 
                            rpc.id,
                            rpc.id_parent,
                            rpos.level + 1,
                            rpos.path || ARRAY [rpc.id],    
                            rpc.id = ANY(rpos.path)
                        FROM "bpd"."group" rpc
                        JOIN rpos ON rpos."id" = rpc."id_parent"
                        WHERE NOT "cycle") 
                    SELECT * FROM rpos;

                IF iid_parent > 0 THEN
                    --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС В СУЩЕСТВУЮЩЕЕ РАСПОЛОЖЕНИЕ
                    IF (mgroup.id_parent <> iid_parent) THEN 
                        --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС ВО ВЛОЖЕННЫЕ ГРУППЫ ПЕРЕНОСИМОЙ ГРУППЫ ИЛИ САМОЙ В СЕБЯ
                        on_moving_correct = NOT EXISTS (SELECT FROM groupmove gm WHERE gm.id = iid_parent);
                    ELSE    
                        on_moving_correct = FALSE;
                    END IF;
                ELSE
                    IF (iid_parent = 0) THEN        
                        --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС В СУЩЕСТВУЮЩЕЕ РАСПОЛОЖЕНИЕ
                        IF (mgroup.id_parent > 0 )THEN 
                            --ПОЗИЦИЯ ПЕРЕНОСИТСЯ В КОРЕНЬ И НЕ БЛОКИРОВАНА
                            on_moving_correct = TRUE;
                        END IF;
                    END IF;
                END IF;
                
                IF NOT(on_moving_correct) THEN
                    action_state = 'group_moved_target_path_not_correct';
                ELSE
                    action_state = 'action_allowed';
                END IF;

                IF (action_state = 'action_allowed') THEN
                --Если позиция перенесена но не нарушены правила вложенности вносим изменения и нет блокировок удаления
                --ШАГ №00 Формирование обновленного штампа времени
                    action_timestamp = LOCALTIMESTAMP(3);
                    IF iid_parent > 0 THEN
                    --ШАГ №01 Преносим группу
                        UPDATE bpd."group" SET
                            "id_parent" = iid_parent,
                            "timestamp" = action_timestamp
                        WHERE
                            "id" = iid;
                    --ШАГ №02 Переопределяем уровни вложенности для дочерних групп    
                        UPDATE "bpd"."group" g
                            SET 
                                "id_root" = pgroup."id_root", 
                                "level" = (pgroup.level +   groupmove.level + 1),
                                "path_array" = pgroup.path_array || groupmove.path,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = g."id";
                                    
                    --ШАГ №03 Переопределяем корневую группу для вложенных классов и Отключаем признак белого списка в классах 
                        UPDATE ONLY "bpd"."class" c
                            SET 
                                "id_group_root" = pgroup."id_root",
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = c."id_group";

					--ШАГ №03.1 Очищаем белый список разрешений уровня 2 класс на позицию
                        DELETE FROM "bpd"."rulel2_class_on_position" rl2
                            WHERE EXISTS(SELECT FROM ONLY "bpd"."class" c
                            JOIN groupmove gm ON gm.id = c.id_group
                            WHERE rl2.id_class = c.id);

					--ШАГ №03.2 Очищаем белый список разрешений уровня 1 группа на шаблон
                        DELETE FROM "bpd"."rulel1_group_on_pos_temp" rl1
                            WHERE EXISTS(SELECT  FROM groupmove gm
                            WHERE rl1.id_group = gm.id);		
							
					--Шаг №04.1 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
                        FOR iid_moved_class IN SELECT id FROM ONLY "bpd"."class" c 
                            WHERE EXISTS(SELECT FROM groupmove 
                                WHERE groupmove.id = c."id_group")
                            LOOP 
                            PERFORM int.int_sync_timestamp_by_id_class(iid_moved_class);       
                        END LOOP;
                    
					--Шаг №04.2 Обновить штамп времени timestamp_child_change бывшей и новой родительских групп
                        UPDATE "bpd"."group" 
                            SET
                                timestamp_child_change = action_timestamp
                            WHERE (id = mgroup.id_parent) OR id = (iid_parent);
                    END IF;    
                
                    IF iid_parent = 0 THEN
                    --ШАГ №01 Преносим группу
                        UPDATE bpd."group" 
                            SET
                            "id_root" = iid, 
                            "id_parent" = 0,
                            "level" = 0,
                            "timestamp" = action_timestamp
                        WHERE "id" = iid;
                    
					--ШАГ №02 Переопределяем уровни вложенности для дочерних групп 
                        UPDATE "bpd"."group" g
                            SET 
                                "id_root" = iid, 
                                "level" = groupmove.level,
                                "path_array" = groupmove.path,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                        WHERE groupmove.id = g."id" AND   mgroup.id <> iid;
                            
                    --ШАГ №03 Переопределяем корневую группу для вложенных классов
                        UPDATE ONLY "bpd"."class" c
                            SET 
                                "id_group_root" = iid,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = c."id_group";
                            
                    --ШАГ №03.1 Очищаем белый список разрешений уровня 2 класс на позицию
                        DELETE FROM "bpd"."rulel2_class_on_position" rl2
                            WHERE EXISTS(SELECT  FROM ONLY "bpd"."class" c
                            JOIN groupmove gm ON gm.id = c.id_group
                            WHERE rl2.id_class = c.id);
					
					--ШАГ №03.2 Очищаем белый список разрешений уровня 1 группа на шаблон
                        DELETE FROM "bpd"."rulel1_group_on_pos_temp" rl1
                            WHERE EXISTS(SELECT  FROM groupmove gm
                            WHERE rl1.id_group = gm.id);		
                    
					--Шаг №04 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
                        FOR iid_moved_class IN SELECT id FROM ONLY "bpd"."class" c 
                            WHERE EXISTS(SELECT  FROM groupmove 
                            WHERE groupmove.id = c."id_group")
                        LOOP 
                            PERFORM int.int_sync_timestamp_by_id_class(iid_moved_class);       
                        END LOOP;    
                    
					--Шаг №04.1 Обновить штамп времени timestamp_child_change бывшей родительской группы
                        UPDATE ONLY "bpd"."group" 
                            SET
                                timestamp_child_change = action_timestamp
                            WHERE id = mgroup.id_parent;
                    END IF;        
                END IF;
            END IF;
        END IF;            
    END IF;
        
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
    perform error_exception( 'group_move', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_move_to_group(IN iid_class bigint,IN iid_group bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
--ОГРАНИЧЕНИЯ МЕТОДА
--1. Нельзя изменить концепцию класса
--2. Нельзя переместить наследующий класс с уровнем вложенности level > 0
--3. Нельзя разрывать по разным группа цепочки наследующих классов
--4. Нельзя переносить классы в группы on_class false
DECLARE
    --**************************************************************************
    --ДАТА: 13.04.2020
    --Автор: Иванов Д.Ю.
    --Версия: 2.0
    --Описание: Функция копирует класс в новое указанное расположение группы
    --**************************************************************************
    mclass "bpd"."class"%ROWTYPE; --Переносимый класс
    pgroup "bpd"."group"%ROWTYPE; --Новая родительская группа
    
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ РОДИТЕЛЬСКОГО КЛАССА
    class_move_name  character varying; -- Уникальное имя копии класса паттерна
    class_name_temp character varying; --Временная переменная для хранения промежуточных результатов
    n INTEGER DEFAULT 1;
    
    action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КАССА
    --*********************************************************
    result "bpd"."errarg"%ROWTYPE; --Формировниае ошибки функции
BEGIN
    --ВЫБИРАЕМ ПЕРЕНОСИМЫЙ КЛАСС
    SELECT * INTO mclass FROM ONLY "bpd"."class" WHERE id = iid_class;
    IF (mclass IS NULL) THEN
        action_state = 'class_move_not_found';
    ELSE
        IF (mclass.level > 0) THEN 
            action_state = 'class_move_not_root';
        ELSE
        --ВЫБИРАЕМ НОВУЮ РОДИТЕЛЬСКУЮ ГРУППУ
        SELECT * INTO pgroup FROM "bpd"."group" WHERE id = iid_group;
            IF (pgroup IS NULL) THEN
                action_state = 'group_target_not_found';
            ELSE
                IF NOT (pgroup.on_class) THEN
                    action_state = 'group_target_not_include_class_move';
                ELSE
                    IF (pgroup.id = mclass.id_group) THEN
                        action_state = 'class_move_in_group_target';
                    ELSE
                        --ОПРЕДЕЛЯЕМ СООТВЕСТВИЕ КОНЦЕПЦИЙ КЛАССА И НОВОЙ ГРУППЫ
                        IF (mclass.id_con <> pgroup.id_con) THEN
                            action_state = 'conception_not_math';
                        ELSE
                            action_state = 'action_allowed';
                        END IF;    
                    END IF;
                END IF;    
            END IF;    
        END IF;
    END IF;    

    IF (action_state = 'action_allowed') THEN
                        
        --ОПРЕДЕЛЯЕМ СПИСОК КЛАССОВ ПОДЛЕЖАЩИХ ПЕРЕНОСУ
        CREATE TEMP TABLE classmove ON COMMIT DROP AS
        WITH 
            RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
                (SELECT 
                    rp."id",
                    rp."id_parent",
                    0,
                    ARRAY [rp."id"],
                    false
                FROM ONLY "bpd"."class" rp
                WHERE rp."id" = iid_class
        UNION all
        SELECT 
            rpc."id",
            rpc."id_parent",
            rpos."level" + 1,
            rpos."patch" || ARRAY [rpc."id"],    
            rpc."id" = ANY(rpos."patch")
        FROM ONLY "bpd"."class" rpc
        JOIN rpos ON rpos."id" = rpc."id_parent"
        WHERE NOT "cycle") 
        SELECT * FROM rpos;
        --=================================================
        --ШАГ №00 Подготовить штамп времени переноса класса
        action_timestamp = LOCALTIMESTAMP(3);
            
        --Шаг №05 Проверяем уникальность имени класса в списке потомков класса цели
        is_unique_name = NOT EXISTS(SELECT FROM ONLY "bpd"."class" 
                            WHERE ("name" = mclass.name) AND ("id_group" = pgroup.id));
        
        --Шаг №05.1 Определяем уникальное именя класса в списке потомков класса цели                    
        IF NOT is_unique_name THEN
            class_name_temp =  mclass.name || ' - Копия';
            LOOP
                class_move_name = concat( class_name_temp,  '(', n, ')');
                is_unique_name = NOT EXISTS(SELECT FROM ONLY "bpd"."class" 
                                    WHERE ("name" = class_move_name) AND ("id_group" = pgroup.id));
                n = n + 1;                
                IF is_unique_name THEN
                    mclass.name = class_move_name;
                    EXIT;  -- выход из цикла
                END IF;
            END LOOP;
        END IF;    
        
        --ШАГ №01.1 Переименовать класс            
        UPDATE ONLY "bpd"."class" 
            SET 
                "name" = mclass.name
            WHERE "id" = mclass.id;
        
        --ШАГ №01.2 Перенести класс            
        UPDATE ONLY "bpd"."class" c
            SET 
                "id_group" = pgroup."id", 
                "id_group_root" = pgroup."id_root",
                "timestamp" = action_timestamp
            FROM classmove 
            WHERE classmove.id = c."id";
        
        --ШАГ №01.3 Перенести класс в правилах RL1
        UPDATE ONLY "bpd"."rulel1_class_on_pos_temp" rl1
            SET 
                "id_group" = pgroup."id"
            FROM classmove 
            WHERE classmove.id = rl1."id_class";    
            
        --Шаг №02 Обновить привязку групп объектов    
        UPDATE "bpd"."object" o
            SET 
                "id_group" = pgroup."id", 
                "id_group_root" = pgroup."id_root", 
                "timestamp" = action_timestamp
            FROM classmove cm
            WHERE cm.id = o."id_class";
        
        --ШАГ №02.1 Очищаем белый список разрешений уровня 2 класс на позицию
        DELETE FROM "bpd"."rulel2_class_on_position" rl2
        WHERE EXISTS(SELECT FROM classmove cm WHERE cm.id = rl2.id_class);            

		--ШАГ №02.2 Очищаем белый список разрешений уровня 1 группа на шаблон
        DELETE FROM "bpd"."rulel1_class_on_pos_temp" rl1
                            WHERE EXISTS(SELECT  FROM classmove cm
                            WHERE rl1.id_class = cm.id);		
        
        --Шаг №03.1 Обновить штамп времени timestamp_child_change бывшей и новой родительских групп
        UPDATE ONLY "bpd"."group" 
            SET
                timestamp_child_change = action_timestamp
            WHERE (id = mclass.id_parent) OR id = (iid_group);        
    END IF;        
           
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'class_move_to_group', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_prop_add(IN iid_class bigint,IN iid_prop_type integer,IN ion_override boolean,IN iid_data_type integer,IN iname character varying,IN idesc character varying,IN itag character varying,IN isort integer,OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 22.04.2020/19.02.2021
    --Версия: 3.0 
    --Автор: Иванов Д.Ю.
    --Описание: Функция добавляет свойство класса STEP 1
    --**************************************************************************
    eclass "bpd"."class"%ROWTYPE; -- РЕДАКТИРУЕМЫЙ КЛАСС К КОТОРОМУ ДОБАВЛЯЕТСЯ СВОЙСТВО
    extensible_chek BOOLEAN DEFAULT FALSE; 
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ СВОЙСТВА КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ КЛАСС
    valid_prop_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП СВОЙСТВА
    valid_data_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП СВОЙСТВА

    action_state character varying DEFAULT 'none'; --Статус действия
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    --*********************************************************
    result "bpd"."errarg"%ROWTYPE; --Формировниае ошибки функции
BEGIN 
  	--Шаг №01 Запрашиваем несущий класс
	SELECT * INTO   eclass   FROM ONLY "bpd"."class" WHERE id = iid_class;
	IF (eclass IS NULL) THEN
        action_state = 'class_upd_not_found';
	ELSE
        --Шаг №02 Определяем доступность расширения несущего класса
        IF (eclass.level > 0) THEN
            SELECT "on_extensible" INTO extensible_chek FROM ONLY "bpd"."class" WHERE id = eclass.id_parent;
            IF (extensible_chek IS DISTINCT FROM TRUE) THEN 
                action_state = 'class_inherited_not_extensible';
                extensible_chek = FALSE;
            END IF;    
        ELSE
            extensible_chek = TRUE;
        END IF;            
            
        IF (extensible_chek) THEN
            --Шаг №03 Определяем совместимость типа свойства с единицами измерения класса
            IF (iid_prop_type = 3) AND (eclass.id_unit <> 7) THEN
                action_state = 'prop_type_not_allow_unit';
            ELSE

                --Шаг №04 Определяем уникальность предложенного имени свойства в пределах свойств несущего класса
                is_unique_name = NOT EXISTS(SELECT FROM ONLY "bpd"."class_prop" WHERE (LOWER("name") = LOWER(iname) AND "id_class" = eclass.id) OR (iname = ''));
                IF NOT(is_unique_name) THEN
                    action_state = 'class_prop_name_not_unique';
                ELSE
                
                    --Шаг №05 Проверяем Доступность указанного типа свойства          
                    valid_prop_type = EXISTS(SELECT FROM "bpd"."prop_type" pt WHERE (pt.id = iid_prop_type) AND pt.on);
                    IF NOT(valid_prop_type) THEN
                        --Указанный тип свойства класса не найден
                        action_state = 'prop_type_not_found';
                    ELSE
                
                        --Шаг №06 Проверяем Доступность указанного типа данных для выбранного типа свойства в указанной концепции
                        valid_data_type = EXISTS(SELECT FROM bpd.con_prop_data_type_by_id_prop_type(eclass.id_con, iid_prop_type) pt
                                                WHERE pt.id = iid_data_type);
                        IF NOT(valid_data_type) THEN
                            --Указанный тип данных не допустим
                            action_state = 'data_type_not_allowed';
                        ELSE
                        
                            --Шаг №07  Определяем правильность значения параметра ion_override для создаваемого свойства
                            IF NOT (eclass."on_abstraction") THEN
                                IF (iid_prop_type = 3) AND ion_override THEN
                                    --Недопустимое значение переопределяемости для объектного свойства вещественного класса
                                    action_state = 'class_prop_override_not_valid';
                                ELSE
                                    action_state = 'action_allowed';
                                END IF;
                            ELSE
                                action_state = 'action_allowed';
                            END IF;      
                        END IF;
                    END IF;
                END IF;
            END IF;    
        END IF;
    END IF;        
           
    IF (action_state = 'action_allowed') THEN
        --ВСЕ УСЛОВИЯ ВЫПОЛНЕНЫ ДОБАВЛЯЕМ СВОЙСТВО
        --ШАГ №00 Создать снимок текущего представления класса
            --PERFORM bpd.int_class_snapshot_create(eclass.id);
        --ШАГ №01 Обновляем штамп времени текущего представления класса
            action_timestamp = LOCALTIMESTAMP(3);
        
        --ШАГ №01.1 Определяем значение сортировки
        isort = COALESCE((SELECT MAX(sort) FROM ONLY "bpd"."class_prop" WHERE id_class = eclass.id),0) + 1;        
           
        --ШАГ №02 Добавляем новое свойство обновленному представлению класса
            INSERT INTO "bpd"."class_prop" ( 
                        "id_conception",
                        "id_class",
                        "timestamp_class", 
                        "id_prop_type",
                        "id_data_type",
                        "name",
                        "desc", 
                        "tag",
                        "sort",
                        "on_inherit",
                        "inheritance",
                        "on_override", 
                        "id_prop_inherit",
                        "timestamp_class_inherit",
                        
                        "id_class_definition",
                        "timestamp_class_definition",
                        "id_prop_definition") 
                VALUES 
                    (   eclass.id_con,
                        eclass.id, 
                        action_timestamp,
                        iid_prop_type, 
                        iid_data_type, 
                        iname, 
                        idesc,
                        itag, 
                        isort,
                        FALSE,
                        FALSE,
                        ion_override,
                        -1,
                        null,
                        eclass.id, 
                        action_timestamp,
                        -1
                    )
                RETURNING "id"  INTO "outid";
                "outid" = COALESCE("outid",0); 

        --ШАГ №02.1 Назначаем новое свойство в качестве определяющего самому себе
            UPDATE ONLY "bpd"."class_prop"
                SET
                    "id_prop_definition" = "outid",
                    "timestamp_class_definition" = action_timestamp
                WHERE id = "outid";    
        
        --ШАГ №03 Запускаем процедуру наследования свойства подчиненными классами
            IF "outid" > 0 THEN
                PERFORM  int.int_class_prop_inherit("outid", FALSE);
            END IF;        
        --ШАГ №04 Запускаем процедуру обновления штампов времени классов
            PERFORM  int.int_upd_timestamp_class_rec_by_id_class(eclass.id, action_timestamp);    
    END IF;

	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
  	perform error_exception( 'class_prop_add', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_prop_object_val_set(IN iid_class_prop bigint,IN iid_class_val bigint,IN ibquantity_min numeric,IN ibquantity_max numeric,IN iembed_mode integer,IN iembed_single boolean,IN iembed_class_real_id bigint,IN iid_unit_conversion_rule integer,OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, "int", err
AS $BODY$
DECLARE 
    --**************************************************************************
    --ДАТА: 03.04.2020
    --Версия: 6.0
    --Автор: Иванов Д.Ю.
    --Описание: Функция устанавливает класс значение объектного свойства STEP 2
    --**************************************************************************
    class_prop_upd "bpd"."vclass_prop"%ROWTYPE; -- РЕДАКТИРУЕМОЕ СВОЙСТВО КЛАССА
    class_val "bpd"."vclass"%ROWTYPE; -- КЛАСС ЗНАЧЕНИЕ СВОЙСТВА КОТОРОЕ ДОБАВЛЯЕТСЯ К СВОЙСТВУ КЛАССА
    group_recycle "bpd"."group"%ROWTYPE; --Группа корзины концепции
    
    class_val_include_branch_class_val BOOLEAN DEFAULT FALSE; --Выбранный класс значение входит в ветвь класса значения наследуемого свойства
    class_val_include_branch_class_carrier BOOLEAN DEFAULT FALSE; --Выбранный класс значение входит в ветвь класса носителя свойства
    class_carrier_include_branch_class_val BOOLEAN DEFAULT FALSE; --Выбранный класс носитель входит в ветвь класса значения свойства
    
    inherited_class_prop "bpd"."vclass_prop"%ROWTYPE; --Наследуемое свойство
    inherited_object_data "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения наследуемого объектного свойства тип 3
        
    inheriting_object_data "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения наследующего объектного свойства тип 3
    
    class_real_val "bpd"."vclass"%ROWTYPE; --ВЕЩЕСТВЕННЫЙ КЛАСС ШАБЛОН ДЛЯ СОЗДАНИЯ ОБЪЕКТОВ
    class_real_val_include_branch_class_val BOOLEAN DEFAULT FALSE; --Выбранный класс шаблон входит в ветвь класса значения свойства
    unit_conversion_rule "bpd"."vunit_conversion_rules"%ROWTYPE; --Заданное правило пересчета
    cur_bquantity NUMERIC; --Количество встраиваемых объектов в базовых величинах
    cur_сquantity NUMERIC; --Количество встраиваемых объектов в величинах правила пересчета
    
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
BEGIN 
	--Шаг №01 Запрашиваем редактируемого свойства
	SELECT * INTO class_prop_upd   FROM ONLY "bpd"."vclass_prop" WHERE id = iid_class_prop;
	IF (class_prop_upd IS NULL) THEN
        action_state = 'class_prop_update_not_found';
	ELSE
        --Шаг №02 Определяем тип свойства
        IF (class_prop_upd.id_prop_type <> 3) THEN
            action_state = 'class_prop_type_not_object';
        ELSE
            --==================================================================================
            --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА НАЧАЛО
            --==================================================================================
            --Шаг №03 Определяем возможность переопределения значения
            IF (NOT class_prop_upd.inheritance) THEN
                --Свойство определяющее, изменение значения разрешено
                action_state = 'action_allowed';
            ELSE 
                --Шаг №04 Определяем наследуемое свойство
                SELECT * INTO inherited_class_prop   FROM ONLY "bpd"."vclass_prop" WHERE id = class_prop_upd."id_prop_inherit";
                IF (inherited_class_prop IS NULL) THEN
                    action_state = 'class_prop_inherit_not_found';
                ELSE
                    IF (inherited_class_prop.on_override) THEN
                        --Наследуемое свойство переопределяемое, изменение значения разрешено
                        action_state = 'action_allowed';
                    ELSE
                        --Наследуемое свойство НЕ переопределяемое, изменение значения НЕ разрешено
                        action_state = 'class_prop_inherit_not_override';
                    END IF;    
                END IF;
            END IF;
            --=================================================================================
            --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА КОНЕЦ
            --=================================================================================
        END IF;
    END IF;        
    
    IF (action_state = 'action_allowed') THEN
        --============================================================================
        --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ УКАЗАННОГО КЛАССА ЗНАЧЕНИЯ НАЧАЛО
        --============================================================================
        action_state = int_classval_for_class_prop_object_check(iid_class_prop, iid_class_val);
        --============================================================================
        --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ УКАЗАННОГО КЛАССА ЗНАЧЕНИЯ КОНЕЦ
        --============================================================================
    END IF;        
    IF (action_state = 'action_allowed') THEN
    --Шаг №09 Определяем правильность значений пределов встраивания
        IF (ibquantity_max < ibquantity_min) AND (ibquantity_max > 0) AND (ibquantity_min > 0) THEN
            action_state = 'bquantity_max_less_min';
        ELSE
            action_state = 'action_allowed';
        END IF;
    END IF;
    --=========================================================================================
    --******ОБЛАСТЬ ПРОВЕРКИ ПАРАМЕТРОВ АВТОМАТИЗАЦИИ ВСТРАИВАНИЯ ОБЪЕКТОВ ЗНАЧЕНИЙ НАЧАЛО
    --=========================================================================================
    IF (action_state = 'action_allowed') THEN
        IF NOT(iembed_mode = ANY(ARRAY[0, 1, 2])) THEN
            action_state = 'embed_mode_not_valid';
        ELSE
            IF (iembed_mode = 0) THEN
                --Автоматизация встраивания выключена
                iembed_single = TRUE;
                iembed_class_real_id = -1;
                iid_unit_conversion_rule = -1;
                action_state = 'action_allowed';
            ELSE
                IF ((iembed_mode = 1) AND (ibquantity_max <=0)) THEN
                    action_state = 'embed_limit_max_not_valid';
                ELSE
                    IF ((iembed_mode = 2) AND (ibquantity_min <=0)) THEN
                        action_state = 'embed_limit_min_not_valid';
                    ELSE
                        --Получаем данные о количестве встраиваемых объектов
                        CASE iembed_mode
                            WHEN 1 THEN
                                cur_bquantity = ibquantity_max;
                            WHEN 2 THEN
                                cur_bquantity = ibquantity_min;
                        END CASE;
                        
                        SELECT * INTO class_real_val  FROM ONLY "bpd"."vclass" WHERE id = iembed_class_real_id;
                        IF (class_real_val IS NULL)  THEN
                            action_state = 'class_real_val_not_found';
                        ELSE
                            IF (class_real_val."on_abstraction") THEN
                                action_state = 'class_real_val_not_real';
                            ELSE
                                IF NOT(class_real_val."on") THEN
                                    action_state = 'class_real_val_not_on';
                                ELSE
                                    --Проверяем готовность класса к созданию объектов
                                    IF NOT(bpd.class_act_prop_check(class_real_val.id)) THEN
                                        action_state = 'class_real_val_include_noready_class_prop';
                                    ELSE    
                                        --Проверяем готовность формата имен объектов классов к созданию объектов
                                        IF (NOT int.int_class_format_check(class_real_val.id)) THEN
                                            action_state = 'class_real_val_noready_name_format';
                                        ELSE
                                            class_real_val_include_branch_class_val = EXISTS(
                                                    WITH 
                                                    RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
                                                        (SELECT 
                                                            rp."id",
                                                            rp."id_parent",
                                                            0,
                                                            ARRAY [rp."id"],
                                                            false
                                                            FROM ONLY "bpd"."class" rp
                                                        WHERE rp."id" = class_val.id
                                                    UNION all
                                                        SELECT 
                                                        rpc."id",
                                                        rpc."id_parent",
                                                        rpos."level" + 1,
                                                        rpos."patch" || ARRAY [rpc."id"],    
                                                        rpc."id" = ANY(rpos."patch")
                                                        FROM ONLY "bpd"."class" rpc
                                                        JOIN rpos ON rpos."id" = rpc."id_parent"
                                                        WHERE NOT "cycle") 
                                                    SELECT * FROM rpos WHERE id = class_real_val.id);
                                                
                                            IF class_real_val_include_branch_class_val THEN
                                                --Выполняем проверку доступности указанного правила пересчета
                                                IF (NOT EXISTS(SELECT 1 FROM "bpd"."class_unit_conversion_rules" cu
                                                                 WHERE cu.id_class = class_real_val.id AND 
                                                                 cu.id_unit_conversion_rule = iid_unit_conversion_rule)) THEN
                                                    action_state = 'class_unit_conversion_rule_not_available';
                                                ELSE                                 
                                                    --Запрашиваем заданное правило пересчета
                                                    SELECT * INTO unit_conversion_rule FROM "bpd"."vunit_conversion_rules" WHERE "id" = iid_unit_conversion_rule;                
                                                    IF (unit_conversion_rule IS NULL) THEN
                                                        action_state = 'unit_conversion_rule_not_found';
                                                    ELSE
                                                        cur_сquantity = cur_bquantity/unit_conversion_rule.mc;

                                                        IF cur_bquantity <> 1 AND unit_conversion_rule.on_single THEN
                                                            --Правило пересчета для объектов индивидуального учета не допускает значений не равных 1
                                                            action_state = 'rule_quantity_on_single_violated';
                                                        ELSE
                                                            IF NOT iembed_single AND unit_conversion_rule.on_single THEN
                                                                --Правило пересчета для объектов индивидуального учета не допускает значений не равных 1
                                                                action_state = 'rule_quantity_on_single_embed_single_violated';
                                                            ELSE
                                                                IF unit_conversion_rule.not_fractional AND (cur_сquantity <> floor(cur_сquantity)) THEN
                                                                    --Правило пересчета для объектов не допускает дробных значений
                                                                    action_state = 'rule_quantity_not_fractional_violated';
                                                                ELSE
                                                                    action_state = 'action_allowed';
                                                                END IF;    
                                                            END IF;    
                                                        END IF;                    
                                                    END IF;    
                                                END IF; 
                                            ELSE    
                                                action_state = 'class_real_val_not_include_branch_class_val';
                                            END IF;
                                        END IF;
                                    END IF;
                                END IF;        
                            END IF;
                        END IF;    
                    END IF;    
                END IF;    
            END IF;    
        END IF;
    END IF;
    --=========================================================================================
    --******ОБЛАСТЬ ПРОВЕРКИ ПАРАМЕТРОВ АВТОМАТИЗАЦИИ ВСТРАИВАНИЯ ОБЪЕКТОВ ЗНАЧЕНИЙ КОНЕЦ
    --=========================================================================================
    
    IF (action_state = 'action_allowed') THEN
        
        --ШАГ №01 Получаем данные значения наследующего свойства OBJECT
        SELECT * INTO inheriting_object_data FROM "bpd"."vclass_prop_object_val"        
                        WHERE id_class_prop = class_prop_upd.id;
                        
        --Шаг №02 Определяем штам времени для измененного класса
        action_timestamp = LOCALTIMESTAMP(3);
        
        IF (inheriting_object_data.tablename = 'notsaved') THEN

            --Шаг №03 Добавляем класс значение свойства
            INSERT INTO "bpd"."class_prop_obj_val_class" ( 
				"id_conception",
                "id_class", 
                "id_class_prop", 
                "bquantity_max", 
                "bquantity_min", 
                "id_class_val", 
                "timestamp_class_val",
                
                embed_mode,
                embed_single,
                embed_class_real_id,
                id_unit_conversion_rule,
                
                "timestamp_class") 
            VALUES (
				class_prop_upd."id_conception",
                class_prop_upd.id_class, 
                class_prop_upd.id, 
                ibquantity_max, 
                ibquantity_min,  
                class_val.id, 
                class_val.timestamp,
                
                iembed_mode,
                iembed_single,
                iembed_class_real_id,
                iid_unit_conversion_rule,
                
                action_timestamp)
            RETURNING "id"  INTO "outid";
            "outid" = COALESCE("outid",0);
        ELSE
            
            --Шаг №03 Обновляем класс значение свойства
            UPDATE ONLY "bpd"."class_prop_obj_val_class" 
                SET 
                    "bquantity_max" = ibquantity_max,
                    "bquantity_min" = ibquantity_min,
                    
                    "id_class_val" = class_val.id,
                    "timestamp_class_val" = class_val.timestamp,
                    
                    embed_mode = iembed_mode,
                    embed_single = iembed_single,
                    embed_class_real_id = iembed_class_real_id,
                    id_unit_conversion_rule = iid_unit_conversion_rule,
                    
                    "timestamp_class" = action_timestamp    
                WHERE     
                    "id_class_prop" = class_prop_upd.id;     
                    
            "outid" = inheriting_object_data.id; 
        END IF;
        
        --Шаг №03.1 Переопределяем место хранения значения наследованного переопределяемого свойства
        IF class_prop_upd.inheritance THEN
            UPDATE ONLY "bpd"."class_prop" 
                SET 
                    on_inherit = FALSE
                WHERE id = class_prop_upd.id;        
        END IF;        
        
        --Шаг №04.1 Обновить штамп времени класса
        UPDATE ONLY "bpd"."class" c
            SET 
                "timestamp" = action_timestamp            
            WHERE (c.id = class_prop_upd.id_class)  AND (c."timestamp" <> action_timestamp);        
    
        --Шаг №04.2 Обновить штамп времени свойства класса
        UPDATE ONLY "bpd"."class_prop" cp
            SET 
                "timestamp_class" = action_timestamp            
            WHERE (cp.id = class_prop_upd.id) AND (cp."timestamp_class" <> action_timestamp);
                    
        --Шаг №05 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
            --PERFORM bpd.int_sync_timestamp_by_id_class(class_carrier.id);
        --Шаг №06 Запустить каскадное наследовниае значения свойства в наследующих классах    
            PERFORM int.int_class_prop_val_inherit(class_prop_upd.id, true);            
    END IF;        
	
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
 	perform error_exception( 'class_prop_object_val_set', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_allowed_rl2_for_class_by_id_position(IN iid_position bigint,IN iid_class bigint)
    RETURNS SETOF bpd.vclass
    LANGUAGE 'plpgsql'
    STABLE SECURITY DEFINER
    PARALLEL SAFE
    COST 100    ROWS 1000 
    
    SET search_path=bpd
AS $BODY$
DECLARE
	--**************************************************************************
    --ДАТА: 15.06.2021
    --Автор: Иванов Д.Ю.
    --Версия: 3.0
    --Описание: Функция возвращает список разрешенных активных классов с учетом разрешения уровня 2 класс на позицию для выбранного класса по идентификатору позиции
    --**************************************************************************
	class_array BIGINT[]; --Массив объектов
BEGIN
	--Проверка активации списка разрешающих правил уровня 2 класс на позицию для указанной позиции
	IF EXISTS(SELECT FROM "bpd"."rulel2_class_on_position" rl2 
											WHERE rl2.id_position = iid_position) THEN
		class_array = (WITH 
			RECURSIVE rclass(id, id_parent, level, path, cycle) AS (
			 SELECT 
				rc.id,
				rc.id_parent,
				0,
				ARRAY[rc.id] AS "array",
				false AS bool
			   FROM ONLY bpd.class rc WHERE
					EXISTS(SELECT FROM "bpd"."rulel2_class_on_position" rl2 WHERE (rl2.id_class = rc.id)
							AND (rl2.id_position = iid_position))
			UNION ALL
			 SELECT 
				rcc.id,
				rcc.id_parent,
				rclass_1.level + 1,
				ARRAY[rcc.id] || rclass_1.path,
				rcc.id = ANY (rclass_1.path)
			   FROM ONLY bpd.class rcc
				 JOIN rclass rclass_1 ON rclass_1.id = rcc.id_parent
			  WHERE NOT rclass_1.cycle
			)	 	
			SELECT array_agg(c.id) FROM rclass c WHERE c.id_parent = iid_class);
		
	ELSE
		RETURN QUERY SELECT * FROM bpd.class_allowed_rl1_by_id_position(iid_position) c WHERE
				(c.id_parent = iid_class);
	END IF;

	RETURN QUERY  SELECT * FROM int.int_vclass_by_id_array(class_array);					
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_prop_enum_val_set(IN iid_class_prop bigint,IN iid_prop_enum bigint,IN iid_prop_enum_val bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL SAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 11.03.2020
    --Автор: Иванов Д.Ю.
	--Версия: 3.0
    --Описание: Функция добавляет значение в виде элемента перечисления для свойства класса типа перечисление
    --**************************************************************************
    eclass_prop "bpd"."vclass_prop"%ROWTYPE; -- РЕДАКТИРУЕМОЕ СВОЙСТВО КЛАССА
    inherit_class_prop "bpd"."vclass_prop"%ROWTYPE; --НАСЛЕДУЕМОЕ СВОЙСТВО КЛАССА
    inherit_class_prop_enum_val "bpd"."class_prop_enum_val"%ROWTYPE; --Данные значения наследуемого свойства класса
    
    aprop_enum "bpd"."vprop_enum"%ROWTYPE; -- Назначаемое перечисление
    aprop_enum_val "bpd"."vprop_enum_val"%ROWTYPE; -- Назначаемый элемент перечисления
    
    class_carrier "bpd"."class"%ROWTYPE; -- РЕДАКТИРУЕМЫЙ КЛАСС НОСИТЕЛЬ СВОЙСТВА К КОТОРОМУ ДОБАВЛЯЕТСЯ ЗНАЧЕНИЕ СВОЙСТВА
    eprop_enum_val "bpd"."vclass_prop_enum_val"; --Данные значения свойства
	global_prop_area_val bigint; --Область значения глобального свойства
        
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    --*********************************************************
	action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления

    result "bpd"."errarg"%ROWTYPE; --Формировниае ошибки функции
BEGIN 
	SELECT * INTO eclass_prop   FROM ONLY "bpd"."vclass_prop" WHERE id = iid_class_prop;
	--Проверяем существование редактируемого свойства
	IF (eclass_prop IS NULL) THEN
        --Редактируемое свойство не найдено
        action_state = 'class_prop_not_found';
	ELSE 
        SELECT * INTO class_carrier  FROM ONLY "bpd"."class" WHERE id = eclass_prop.id_class;
        IF (class_carrier IS NULL) THEN
            --Класс носитель свойства не найден
            action_state = 'class_carrier_not_found';
        ELSE
            IF  (eclass_prop.id_prop_type <> 2) THEN
                --Свойство класса не является перечислением
                action_state = 'class_prop_not_enum_type';
            ELSE
                SELECT * INTO aprop_enum FROM "bpd"."vprop_enum" WHERE "id_prop_enum" = iid_prop_enum;
                IF (aprop_enum IS NULL) THEN
                    --Указанное перечисление не найдено
                    action_state = 'prop_enum_not_found';
                ELSE
                    IF (eclass_prop."id_conception" <> aprop_enum."id_conception") THEN
                        action_state = 'conception_not_match';
                    ELSE    
                        IF NOT(aprop_enum.id_prop_enum_use_area = ANY (ARRAY[3,4])) THEN
                            --Область применения перечисления не охватывает объекты и классы
                            action_state = 'prop_enum_use_area_out_of_range';
                        ELSE    
                            IF COALESCE(iid_prop_enum_val, -1) > 0 THEN
                                SELECT * INTO aprop_enum_val FROM "bpd"."vprop_enum_val" WHERE "id_prop_enum_val" = iid_prop_enum_val;
                                IF (aprop_enum_val IS NULL) THEN
                                    --Указанный элемент перечисления не найден
                                    action_state = 'prop_enum_val_not_found';
                                ELSE
                                    IF (aprop_enum.id_prop_enum <> aprop_enum_val.id_prop_enum) THEN
                                        --Указанный элемент перечисления не входит в выбранное перечисление
                                        action_state = 'prop_enum_val_out_of_range';
                                    ELSE
                                        --Указанный элемент перечисления допустим
                                        action_state = 'action_allowed';
                                    END IF;  
                                END IF;
                            ELSE
                                --Указанный элемент перечисления допустим
                                action_state = 'action_allowed';
                            END IF;
	                    END IF;    
                    END IF;    
                END IF;
            END IF;
        END IF;
	END IF;

	IF (action_state = 'action_allowed') THEN
		IF (aprop_enum.id_conception <> eclass_prop.id_conception) THEN
			--Концепции свойства и перечисления не совпадают
			action_state = 'conception_not_match';
		ELSE
			--==========================================================================================
			--***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА НАЧАЛО
			--==========================================================================================
			IF (NOT eclass_prop.inheritance) THEN
				--Свойство определяющее
				--Проверяем класс значение для определяющего свойства связанного с глобальным	
				IF EXISTS(SELECT FROM ONLY bpd.class_prop cp
		     				LEFT JOIN bpd.global_prop_link_class_prop lgp 
							ON lgp.id_class_prop_definition = cp.id_prop_definition
							WHERE cp.id = eclass_prop.id) THEN
			
					--Определяем совпадение указанного перечисления с областью значения глобального свойства
					SELECT gp.id_area_val INTO global_prop_area_val FROM bpd.global_prop gp
							JOIN bpd.global_prop_link_class_prop lgp ON lgp.id_global_prop = gp.id
							JOIN ONLY bpd.class_prop cp ON cp.id_prop_definition = lgp.id_class_prop_definition
							WHERE cp.id = eclass_prop.id;
					
					IF (global_prop_area_val <> aprop_enum.id_prop_enum) THEN
						
						action_state = 'enum_val_not_match_enum_val_global_prop';                                
					ELSE
						action_state = 'action_allowed';
					END IF;
				END IF;	
			ELSE 
				--Определяем наследуемое свойство
				SELECT * INTO inherit_class_prop   FROM ONLY "bpd"."vclass_prop" WHERE id = eclass_prop."id_prop_inherit";
				IF (inherit_class_prop IS NULL) THEN
					--Наследуемое свойство не найдено
					action_state = 'inherit_class_prop_not_found';
				ELSE
					IF NOT(inherit_class_prop.on_override) THEN
						--Наследуемое свойство не переопределяемое, изменение значения не разрешено
						action_state = 'inherit_class_prop_not_override';
					ELSE
						SELECT * INTO inherit_class_prop_enum_val FROM  ONLY "bpd"."class_prop_enum_val" WHERE "id_class_prop" = inherit_class_prop.id;
						IF (inherit_class_prop_enum_val IS NULL) THEN
							--Данные значения наследуемого свойства не определены
							action_state = 'inherit_prop_enum_val_not_set';
						ELSE
							IF (inherit_class_prop_enum_val.id_prop_enum <> aprop_enum.id_prop_enum) THEN
								--Перечисления редактируемого и наследованного свойств не совпадают
								action_state = 'prop_enum_not_match';
							ELSE
								--Действие разрешено
								action_state = 'action_allowed';
							END IF;
						END IF;     
					END IF;    
				END IF;    
			END IF;
			--==========================================================================================
			--***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА КОНЕЦ
			--==========================================================================================
		END IF;
	END IF;    
	
	IF (action_state = 'action_allowed') THEN
        --Шаг №01 Определяем штам времени для измененного класса
        action_timestamp = LOCALTIMESTAMP(3);    
        
        --Шаг №02 Удаляем существующие значения классов
        --DELETE FROM ONLY "bpd"."class_prop_enum_val"
        --    WHERE "id_class_prop" = eclass_prop.id;        
        
        --Шаг №03 Добавляем значение свойства    
        INSERT INTO "bpd"."class_prop_enum_val" ( 
            "id_conception",
			"id_class", 
            "timestamp_class", 
            "id_class_prop", 
            "id_prop_enum", 
            "id_prop_enum_val", 
            "inheritance") 
        VALUES ( 
			class_carrier.id_con,
            class_carrier.id,
            action_timestamp,
            eclass_prop.id,
            iid_prop_enum,
            iid_prop_enum_val,
            FALSE)
            ON CONFLICT ("id_class_prop") DO 
		UPDATE SET 
			"id_prop_enum" = EXCLUDED."id_prop_enum",
            "id_prop_enum_val" = EXCLUDED."id_prop_enum_val",
            "inheritance" = FALSE;
        
        --Шаг №03.1 Переопределяем место хранения значения наследованного переопределяемого свойства и тип данных свойства по перечислению
        IF eclass_prop.inheritance THEN
            UPDATE ONLY "bpd"."class_prop" 
                SET 
                    on_inherit = FALSE,
                    id_data_type = aprop_enum.id_data_type
                WHERE id = eclass_prop.id;        
        END IF;     
        
        --Шаг №04.1 Обновить штамп времени класса
        UPDATE ONLY "bpd"."class" c
            SET 
                "timestamp" = action_timestamp            
            WHERE (c.id = class_carrier.id)  AND (c."timestamp" <> action_timestamp);        
    
        --Шаг №04.2 Обновить штамп времени свойства класса
        UPDATE ONLY "bpd"."class_prop" cp
            SET 
                "timestamp_class" = action_timestamp            
            WHERE (cp.id = eclass_prop.id) AND (cp."timestamp_class" <> action_timestamp);
                    
        --Шаг №05 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
            --PERFORM bpd.int_sync_timestamp_by_id_class(class_carrier.id);
        --Шаг №06 Запустить каскадное наследовниае значения свойства в наследующих классах    
            PERFORM int.int_class_prop_val_inherit(eclass_prop.id, true);                   
	END IF;
	
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'class_prop_enum_val_set', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_allowed_rl1_by_id_position(IN iid_position bigint)
    RETURNS SETOF bpd.vclass
    LANGUAGE 'plpgsql'
    STABLE SECURITY DEFINER
    PARALLEL SAFE
    COST 100    ROWS 1000 
    
    SET search_path=bpd
AS $BODY$
DECLARE
	--**************************************************************************
    --ДАТА: 15.06.2021
    --Автор: Иванов Д.Ю.
    --Версия: 3.0
    --Описание: Функция возвращает список разрешенных активных классов на основе разрешения уровня 1 группа на шаблон по идентификатору позиции
    --**************************************************************************
    iid_pos_temp BIGINT; --Идентификатор шаблона позиции
    class_array BIGINT[]; --Массив классов
BEGIN

    SELECT id_pos_temp INTO iid_pos_temp FROM "bpd"."position" WHERE id = iid_position;
        
        class_array = (WITH 
            RECURSIVE rgroup ("id", "id_parent", "patch", "cycle") AS 
            (SELECT 
                rg."id",
                rg."id_parent",
                ARRAY [rg."id"],
                false
            FROM "bpd"."group" rg
            JOIN "bpd"."rulel1_group_on_pos_temp" rl1 ON rl1.id_group = rg.id
            WHERE rl1.id_pos_temp = COALESCE(iid_pos_temp, -1)
            UNION all
            SELECT 
                rgc."id",
                rgc."id_parent",
                rgroup."patch" || ARRAY [rgc."id"],    
                rgc."id" = ANY(rgroup."patch")
            FROM "bpd"."group" rgc
            JOIN rgroup ON rgroup."id" = rgc."id_parent"
            WHERE NOT "cycle"
            ),
            rclass(id, level, id_parent, patch, cycle) AS 
            (SELECT 
                rc.id,
                rc.level,
                rc.id_parent,
                ARRAY[rc.id] AS "array",
                false AS bool
               FROM ONLY bpd."class" rc
                 JOIN bpd.rulel1_class_on_pos_temp rl1 ON (rc.id = rl1.id_class)
                 WHERE rl1.id_pos_temp = COALESCE(iid_pos_temp, -1)
            UNION ALL
            SELECT rcc.id,
                rcc.level,
                rcc.id_parent,
                (rclass.patch || ARRAY[rcc.id]),
                (rcc.id = ANY (rclass.patch))
            FROM ONLY bpd."class" rcc
                JOIN rclass ON rclass.id = rcc.id_parent
            WHERE NOT rclass.cycle)
            SELECT array_agg(c.id) FROM ONLY bpd.class c
                WHERE
                    EXISTS(SELECT FROM rgroup WHERE c.id_group = rgroup.id)
                    OR
                    EXISTS(SELECT FROM rclass WHERE c.id = rclass.id));
    
    RETURN QUERY  SELECT * FROM int.int_vclass_by_id_array(class_array);
    
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.global_prop_add(IN iid_conception bigint,IN iid_prop_type integer,IN iid_data_type integer,IN iname character varying,IN idesc character varying,IN ivisible boolean,OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 04.06.2020/05.02.2021
    --Версия: 2.0 
    --Автор: Иванов Д.Ю.
    --Описание: Функция добавляет глобальное свойство концепции
    --**************************************************************************
    econception "bpd"."conception"%ROWTYPE; -- Редактируемая концепция
    
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ СВОЙСТВА КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ КЛАСС
    valid_prop_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП СВОЙСТВА
    valid_data_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП СВОЙСТВА
   
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
	action_state character varying DEFAULT 'none'; --Статус действия
BEGIN 
	--Шаг №01 Запрашиваем редакти
	SELECT * INTO  econception   FROM ONLY "bpd"."conception" WHERE id = iid_conception;
	IF (econception IS NULL) THEN
        action_state = 'conception_not_found';
	ELSE
        --Шаг №02 Определяем уникальность предложенного имени свойства в пределах указанной концепции
        is_unique_name = NOT EXISTS(SELECT FROM ONLY "bpd"."global_prop" WHERE ((LOWER("name") = LOWER(iname)) AND ("id_conception" = econception.id)) OR (iname = ''));
        IF NOT(is_unique_name) THEN
            action_state = 'global_prop_name_not_unique';
        ELSE
            --Шаг №03 Проверяем Доступность указанного типа свойства          
            valid_prop_type = EXISTS(SELECT FROM "bpd"."prop_type" pt WHERE (pt.id = iid_prop_type) AND pt.on);
            IF NOT(valid_prop_type) THEN
                --Указанный тип свойства класса не найден
                action_state = 'prop_type_not_found';
            ELSE
                --Шаг №04 Проверяем Доступность указанного типа данных для выбранного типа свойства в указанной концепции
                valid_data_type = EXISTS(SELECT FROM bpd.con_prop_data_type_by_id_prop_type(econception.id, iid_prop_type) pt
                                        WHERE pt.id = iid_data_type);
                IF NOT(valid_data_type) THEN
                    --Указанный тип данных не допустим
                    action_state = 'data_type_not_allowed';
                ELSE
                    action_state = 'action_allowed';
                END IF;
            END IF;    
        END IF;
    END IF;        
           
    IF (action_state = 'action_allowed') THEN
        --ВСЕ УСЛОВИЯ ВЫПОЛНЕНЫ ДОБАВЛЯЕМ СВОЙСТВО
        --ШАГ №00 Обновляем штамп времени текущего представления класса
        action_timestamp = LOCALTIMESTAMP(3);
        --ШАГ №01 Добавляем новое глобальное свойство 
        INSERT INTO "bpd"."global_prop" ( 
            "id_conception", 
            "id_prop_type", 
            "id_data_type", 
            "name", 
            "desc",
            "visible",
            "timestamp"
            ) 
        VALUES ( 
            iid_conception, 
            iid_prop_type, 
            iid_data_type, 
            iname, 
            idesc,
            ivisible,
            action_timestamp)
        RETURNING "id"  INTO "outid";
        "outid" = COALESCE("outid",0); 
    END IF;

	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'global_prop_add', action_state); 
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.global_prop_area_val_set(IN iid_global_prop bigint,IN iid_area_val bigint,OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 03.07.2020
    --Версия: 1.0
    --Автор: Иванов Д.Ю.
    --Описание: Функция добавляет область значений глобального свойства
    --**************************************************************************
    eglobal_prop "bpd"."vglobal_prop"%ROWTYPE; --Редактируемое глобальное свойство
    
    class_val "bpd"."vclass"%ROWTYPE; --Класс значение объектного свойства определяющий область значений подчиненных объектных свойств
    enum_val  "bpd"."vprop_enum"%ROWTYPE; --Перечисление свойства-перечисления определяющее область значений подчиненных объектных свойств
    entity_val "bpd"."ventity"%ROWTYPE; --Сущность свойства-ссылки определяющая область значений подчиненных объектных свойств
    
    cur_id_area_val BIGINT DEFAULT -1::BIGINT;
    cur_id_data_type INT DEFAULT 15; --Тип данных глобального свойства
    cur_timestamp_area_val timestamp without time zone DEFAULT '1990-01-01 00:00:00'::timestamp without time zone;
    
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
BEGIN 
	--Шаг №01 Запрашиваем редактируемое глобальное смвойство
	SELECT * INTO eglobal_prop   FROM ONLY "bpd"."vglobal_prop" WHERE id = iid_global_prop;
	IF (eglobal_prop IS NULL) THEN
        action_state = 'global_prop_not_found';
	ELSE
        --Шаг №02 Проверяем доступность  изменения глобального свойства
        IF (eglobal_prop.is_use) THEN
            action_state = 'global_prop_is_use';
        ELSE 
            --Шаг №02 Определяем тип действие в зависимости от типа свойства
            CASE (eglobal_prop.id_prop_type) 
                WHEN 1 THEN 
                --Свойство пользовательское
                    IF (EXISTS(SELECT FROM bpd.con_prop_data_type_by_id_prop_type(eglobal_prop.id_conception, eglobal_prop.id_prop_type) pt
                                            WHERE pt.id = iid_area_val)) THEN
                    	action_state = 'action_allowed';
						cur_id_area_val = iid_area_val;
                    	cur_id_data_type = iid_area_val;
					ELSE
						--Указанный тип данных не допустим
                        action_state = 'data_type_not_allowed';
					END IF;
                WHEN 2 THEN
                --Свойство перечисление
                    SELECT * INTO enum_val FROM "bpd"."vprop_enum" WHERE "id_prop_enum" = iid_area_val;
                    IF (enum_val IS NULL) THEN
                        --Указанное перечисление не найдено
                        action_state = 'prop_enum_not_found';
                    ELSE
                        IF (enum_val.id_conception <> eglobal_prop.id_conception) THEN
                            action_state = 'enum_val_conception_not_match';
                        ELSE
                            --Действие допустимо
                            action_state = 'action_allowed';
                            cur_id_area_val = enum_val."id_prop_enum";
                            cur_id_data_type = enum_val."id_data_type";
                        END IF;    
                    END IF;    
                WHEN 3 THEN
                --Свойство объектное
                    --Шаг №05 Определяем класс значение
                    SELECT * INTO class_val   FROM ONLY "bpd"."vclass" WHERE id = iid_area_val;
                    IF (class_val IS NULL)  THEN
                        action_state = 'class_val_not_found';
                    ELSE
                        IF NOT (class_val."on_abstraction") THEN
                            action_state = 'class_val_not_abstraction';
                        ELSE
                            IF (class_val.id_con <> eglobal_prop.id_conception) THEN
                                action_state = 'class_val_conception_not_match';
                            ELSE
                                --Действие допустимо
                                action_state = 'action_allowed';
                                cur_id_area_val = class_val.id;
                                cur_timestamp_area_val = class_val."timestamp";
                                cur_id_data_type = 15;
                            END IF;
                        END IF;
                    END IF;            
                WHEN 4 THEN
                --Свойство ссылка
                    SELECT * INTO entity_val FROM "bpd"."ventity" WHERE "id" = iid_area_val;
                    IF (entity_val IS NULL) THEN
                        --Указанная сущность не найдена
                        action_state = 'entity_not_found';
                    ELSE
                        IF NOT (entity_val.can_link) THEN
                            --Указанная сущность не может быть залинкована
                            action_state = 'entity_not_can_link';
                        ELSE    
                            --Действие допустимо
                            action_state = 'action_allowed';
                            cur_id_area_val = entity_val."id";
                            cur_id_data_type = 15;
                        END IF;
                    END IF;    
            END CASE;
        END IF;
    END IF;    
        
    IF (action_state = 'action_allowed') THEN
        --Шаг №00 Определяем штам времени для измененного класса
        action_timestamp = LOCALTIMESTAMP(3);
        
        --ШАГ №01 Обновляем глобальное свойство по данным пользователя
        UPDATE ONLY "bpd"."global_prop" 
        SET 
            "id_data_type" = cur_id_data_type,
            "id_area_val" = cur_id_area_val,
            "timestamp_area_val" = cur_timestamp_area_val,
            "timestamp" = action_timestamp
        WHERE "id" = eglobal_prop.id;  
    END IF;        
                
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'global_prop_area_val_set', action_state);	
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.global_prop_upd(IN iid_global_prop bigint,IN iid_prop_type integer,IN iid_data_type integer,IN iname character varying,IN idesc character varying,IN ivisible boolean)
    RETURNS void
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 05.06.2020
    --Версия: 1.0
    --Автор: Иванов Д.Ю.
    --Описание: Функция обновляет глобальное свойство концепции
    --**************************************************************************
    eglobal_prop "bpd"."vglobal_prop"%ROWTYPE; -- РЕДАКТИРУЕМОЕ СВОЙСТВО КЛАССА
       
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ СВОЙСТВА КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ КЛАСС
    valid_prop_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП СВОЙСТВА
    valid_data_type BOOLEAN DEFAULT  FALSE; -- ДЕЙСТВИТЕЛЬНЫЙ ТИП ДАННЫХ СВОЙСТВА
    
    cur_id_area_val BIGINT; --Текщее значение области значений глобального свойства
    cur_timestamp_area_val Timestamp Without Time Zone; --штамп времени текщего значения области значений глобального свойства

    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    action_state character varying DEFAULT 'none'; --Статус действия
BEGIN 
	--Шаг №01 Запрашиваем редактируемое свойство
	SELECT * INTO eglobal_prop   FROM ONLY "bpd"."vglobal_prop" WHERE id = iid_global_prop;
	IF (eglobal_prop IS NULL) THEN
        action_state = 'global_prop_not_found';
	ELSE
        --Шаг №02 Проверяем доступность  изменения глобального свойства
        IF (eglobal_prop.is_use) AND 
           ((eglobal_prop."id_prop_type" <> iid_prop_type) OR
           (eglobal_prop."id_data_type" <> iid_data_type) OR 
           (eglobal_prop."name" <> iname) OR 
           (eglobal_prop."desc" <> idesc)) THEN
            action_state = 'global_prop_is_use';
        ELSE           
            --Шаг №03 Проверяем уникальность предложенного наименования свойства
            is_unique_name = NOT EXISTS(SELECT FROM "bpd"."global_prop" gp
                         WHERE ((LOWER(gp."name") = LOWER(iname)) AND (gp."id_conception" = eglobal_prop.id_conception) AND (gp.id <> eglobal_prop.id)) OR (iname = ''));
            IF NOT(is_unique_name) THEN
                action_state = 'global_prop_name_not_unique';
            ELSE 
                --Шаг №04 Проверяем Доступность указанного типа свойства          
                valid_prop_type = EXISTS(SELECT FROM "bpd"."prop_type" pt WHERE (pt.id = iid_prop_type) AND pt.on);
                IF NOT(valid_prop_type) THEN
                    --Указанный тип свойства класса не найден
                    action_state = 'prop_type_not_found';
                ELSE
                    --Шаг №04.1 При изменении типа свойства обнуляем данные области значения
                    IF (iid_prop_type <> eglobal_prop."id_prop_type") THEN
                        eglobal_prop."id_area_val" = null;
                        eglobal_prop."timestamp_area_val" = null;
                    END IF;
                    --Шаг №05 Проверяем Доступность указанного типа данных для выбранного типа свойства в указанной концепции
                    valid_data_type = EXISTS(SELECT FROM bpd.con_prop_data_type_by_id_prop_type(eglobal_prop.id_conception, iid_prop_type) pt
                                            WHERE pt.id = iid_data_type);
                    IF NOT(valid_data_type) THEN
                        --Указанный тип данных не допустим
                        action_state = 'data_type_not_allowed';
                    ELSE
                        action_state = 'action_allowed';
                    END IF;
                END IF;                                                                 
            END IF;    
        END IF;
	END IF;
	
	IF (action_state = 'action_allowed') THEN     
        --ШАГ №00 Обновляем штамп времени текущего представления класса
        action_timestamp = LOCALTIMESTAMP(3);
        
        --ШАГ №01 Определяем значение области значений
        IF ((eglobal_prop.id_prop_type <> iid_prop_type) OR  (eglobal_prop.id_data_type <> iid_data_type))THEN
            cur_id_area_val = NULL;
            cur_timestamp_area_val = NULL;
        ELSE
            cur_id_area_val = eglobal_prop.id_area_val;
            cur_timestamp_area_val = eglobal_prop.timestamp_area_val;
        END IF;
        
        --ШАГ №02 Обновляем глобальное свойство по данным пользователя
        UPDATE ONLY "bpd"."global_prop" 
        SET 
            "id_prop_type" = iid_prop_type, 
            "id_data_type" = iid_data_type,
            "name" = iname,
            "desc" = idesc,
            "id_area_val" = cur_id_area_val,
            "timestamp_area_val" = cur_timestamp_area_val,
            "timestamp" = action_timestamp,
            "visible" = ivisible
        WHERE "id" = eglobal_prop.id;  
    END IF;
    
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'global_prop_upd', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_move_to_class(IN iid_pattern bigint,IN iid_target bigint,OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL UNSAFE
    COST 100
    
    SET search_path=bpd, err, "int"
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 06.04.2020
    --Автор: Иванов Д.Ю.
    --Версия: 2.0 (27.04.2020)
    --Описание: Функция копирует класс в новое указанное расположение с последующим удалением класса паттерна
    --**************************************************************************
    class_target "bpd"."class"%ROWTYPE; --Целевой класс в который осуществляется копирование
    extensible_chek BOOLEAN DEFAULT FALSE; 
    class_pattern "bpd"."class"%ROWTYPE; --Класс образец который копируется в новое расположение
    class_pattern_child "bpd"."class"%ROWTYPE; --Потомки класса образца
    
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ РОДИТЕЛЬСКОГО КЛАССА
    class_pattern_name  character varying; -- Уникальное имя копии класса паттерна
    class_name_temp character varying; --Временная переменная для хранения промежуточных результатов
    n INTEGER DEFAULT 1;
    
    target_include_real_class BOOLEAN DEFAULT  FALSE; --Целевой класс содержит вещественные классы
    target_include_abstraction_class BOOLEAN DEFAULT  FALSE; --Целевой класс содержит абстрактные классы
    class_pattern_include_class_target BOOLEAN DEFAULT  FALSE; --Класс паттерн содержит класс цель
    
    class_prop_pattern "bpd"."vclass_prop"%ROWTYPE; --Временная переменная текущего свойства класса паттерна
    
    id_class_prop_copy BIGINT; --Временная переменная ИД копии свойства
    class_prop_copy "bpd"."vclass_prop"%ROWTYPE; --Полученная копия свойства
    
    user_big_data_pattern "bpd"."vclass_prop_user_big_val"%ROWTYPE; -- Данные значения копируемого ползовательского свойства тип 1 BIG
    user_small_data_pattern "bpd"."vclass_prop_user_small_val"%ROWTYPE; -- Данные значения копируемого ползовательского свойства тип 1 SMALL
    enum_data_pattern "bpd"."vclass_prop_enum_val"%ROWTYPE; -- Данные значения копируемого свойства перечисления тип 2
    object_data_pattern "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения копируемого объектного свойства тип 3
    link_data_pattern "bpd"."vclass_prop_link_val"%ROWTYPE; -- Данные значения копируемого свойства-ссылки тип 4
    
    include_class_val BOOLEAN DEFAULT FALSE; --Удаляемый класс содержит классы назначенные в качестве значений объектных свойств
    include_class_area BOOLEAN DEFAULT FALSE; --Удаляемый класс содержит классы назначенные в области значений объектных свойств
    
    action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КАССА
    --*********************************************************
    result "bpd"."errarg"%ROWTYPE; --Формировниае ошибки функции
BEGIN 
    --Шаг №01 Запрашиваем класс цель
	SELECT * INTO  class_target FROM ONLY "bpd"."class" WHERE id = iid_target;
	IF (class_target IS NULL) THEN
        action_state = 'class_target_not_found';
	ELSE
        IF NOT(class_target.on) THEN
            --Класс цель выключен и не может принемать новые классы
            action_state = 'class_target_not_on';
        ELSE
            --Шаг №02 Определяем возможность вложения других классов в класс цель
            IF NOT(class_target.on_abstraction) THEN
                --Класс цель не абстрактный и не может содержать другие классы
                action_state = 'class_target_not_abstraction';
            ELSE
                --Шаг №02 Определяем доступность расширения несущего класса
                IF (class_target.level > 0) THEN
                    SELECT "on_extensible" INTO extensible_chek FROM ONLY "bpd"."class" WHERE id = class_target.id_parent;
                    IF (extensible_chek IS DISTINCT FROM TRUE) THEN 
                        action_state = 'class_inherited_not_extensible';
                        extensible_chek = FALSE;
                    END IF;    
                ELSE
                    extensible_chek = TRUE;
                END IF;
                
                IF (extensible_chek) THEN
                    --Шаг №03 Запрашиваем класс паттерн
                    SELECT * INTO  class_pattern FROM ONLY "bpd"."class" WHERE id = iid_pattern;
                    IF (class_pattern IS NULL) THEN
                        action_state = 'class_pattern_not_found';
                    ELSE
                        --Шаг №04 Проверяем соотвествие концепций
                        IF (class_target.id = class_pattern.id_parent) THEN
                            action_state = 'class_pattern_in_class_target';
                        ELSE
                            --Шаг №04 Проверяем соотвествие концепций
                            IF (class_target.id_con <> class_pattern.id_con) THEN
                                action_state = 'conception_not_math';
                            ELSE
                                --Шаг №04.1 Проверяем соотвествие измеряемых величин
                                IF (class_target.id_unit <> class_pattern.id_unit) THEN
                                    action_state = 'unit_not_math';
                                ELSE
                                    --Шаг №04.2 Проверяем коррекность параметра расширяемости переносимого класса
                                    IF ((NOT class_target.on_extensible) AND class_pattern.on_extensible) THEN
                                        action_state = 'class_target_not_include_class_pattern_extensible';
                                    ELSE
                                        --Шаг №04.3 Проверяем допустимость целевого класса в структуре дерева
                                        --**********************************************************************************
                                        --ПРОВЕРКА  копирования или переноса класса в самого себя или вложенные классы НАЧАЛО
                                        --**********************************************************************************
                                        --Шаг №04.3.1 Определяем вхождение класса цели в ветви класса паттерна (защита от зацикливания) 
                                        class_pattern_include_class_target =  EXISTS (SELECT FROM (WITH 
                                            RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                (SELECT 
                                                    c."id",
                                                    c."id_parent",
                                                    0,
                                                    ARRAY [c."id"],
                                                    FALSE
                                                FROM ONLY "bpd"."class" c
                                                WHERE c."id" = iid_pattern
                                            UNION all
                                                SELECT 
                                                    rc."id",
                                                    rc."id_parent",
                                                    rclass."level" + 1,
                                                    rclass."patch" || ARRAY [rc."id"],    
                                                    rc."id" = ANY(rclass."patch")
                                                FROM ONLY "bpd"."class" rc
                                                JOIN rclass ON rclass."id" = rc."id_parent"
                                                WHERE NOT "cycle") 
                                            SELECT * FROM rclass) c WHERE c.id = iid_target);
                                            
                                        IF (class_pattern_include_class_target) THEN
                                            action_state = 'class_pattern_include_class_target';
                                        ELSE
                                        --**********************************************************************************
                                        --ПРОВЕРКА  копирования или переноса класса в самого себя или вложенные классы КОНЕЦ
                                        --**********************************************************************************
                                            --Шаг №05 Проверяем уникальность имени класса в списке потомков класса цели
                                            is_unique_name = NOT EXISTS(SELECT 1 FROM ONLY "bpd"."class" 
                                                                WHERE "name" = class_pattern.name AND "id_parent" = class_target.id);
                                            
                                            --Шаг №05.1 Определяем уникальное именя класса в списке потомков класса цели                    
                                            IF NOT is_unique_name THEN
                                                class_name_temp =  class_pattern.name || ' - Копия';
                                                LOOP
                                                    class_pattern_name = concat( class_name_temp,  '(', n, ')');
                                                    is_unique_name = NOT EXISTS(SELECT 1 FROM ONLY "bpd"."class" 
                                                                        WHERE "name" = class_pattern_name AND "id_parent" = class_target.id);
                                                    n = n + 1;                
                                                    IF is_unique_name THEN
                                                        class_pattern.name = class_pattern_name;
                                                        EXIT;  -- выход из цикла
                                                    END IF;
                                                END LOOP;
                                            END IF;
                                            --Шаг №06 Определяем допустимость вложений в целевой класс класса паттерна
                                            IF class_pattern.on_abstraction THEN
                                            --Шаг №06.1 Проверка наличия вещественных классов у целевого класса
                                                target_include_real_class = EXISTS ( SELECT 1
                                                                            FROM ONLY bpd.class c
                                                                                WHERE c.id_parent = class_target.id AND (NOT c.on_abstraction));
                                                IF  target_include_real_class THEN
                                                    action_state = 'class_target_cannot_include_abstraction_class';
                                                ELSE
                                                    action_state = 'action_allowed';
                                                END IF;    
                                            ELSE
                                            --Шаг №06.2 Проверка наличия абстрактных классов у целевого класса
                                                target_include_abstraction_class = EXISTS ( SELECT 1
                                                                            FROM ONLY bpd.class c
                                                                                WHERE c.id_parent = class_target.id AND c.on_abstraction);
                                                IF  target_include_abstraction_class THEN
                                                    action_state = 'class_target_cannot_include_real_class';
                                                ELSE
                                                    action_state = 'action_allowed';
                                                END IF;
                                            END IF;
                                        END IF;    
                                    END IF;    
                                END IF;    
                            END IF;    
                        END IF;    
                    END IF;  
                END IF;    
            END IF;    
        END IF;    
	END IF;
	
	IF (action_state = 'action_allowed') THEN
	--*********************************************************************************
	--ПРОВЕРКА ДОСТУПНОСТИ УДАЛЕНИЯ ПЕРЕНОСИМОГО КЛАССА ИЗ ТЕКУЩЕГО РАСПОЛОЖЕНИЯ НАЧАЛО
	--*********************************************************************************
	--ОПРЕДЕЛЯЕМ СПИСОК КЛАССОВ ПОДЛЕЖАЩИХ ПЕРЕМЕЩЕНИЮ
        CREATE TEMP TABLE classmove ON COMMIT DROP AS
                WITH 
                    RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                        (SELECT 
                            rc."id",
                            rc."id_parent",
                            0,
                            ARRAY [rc."id"],
                            false
                        FROM ONLY "bpd"."class" rc
                        WHERE rc."id" = iid_pattern
                UNION ALL
                    SELECT 
                        rpc."id",
                        rpc."id_parent",
                        rclass."level" + 1,
                        rclass."patch" || ARRAY [rpc."id"],    
                        rpc."id" = ANY(rclass."patch")
                    FROM ONLY "bpd"."class" rpc
                    JOIN rclass ON rclass."id" = rpc."id_parent"
                    WHERE NOT "cycle") 
        SELECT * FROM rclass;
        --Определить наличие классов назначенных в качетве значения в списке удаляемых классов
        include_class_val = (EXISTS( SELECT FROM classmove cd JOIN ONLY "bpd"."class_prop_obj_val_class" cv ON cd.id = cv."id_class_val") OR 
                            EXISTS( SELECT FROM classmove cd JOIN "bpd"."global_prop" gp ON cd.id = gp.id_area_val WHERE gp.id_prop_type = 3) OR 
                            EXISTS( SELECT FROM classmove cd JOIN "bpd"."pos_temp_prop_obj_val" cv ON cd.id = cv."id_class_val"));
    
        IF include_class_val THEN 
            action_state = 'class_del_include_class_val_for_object_prop';
        ELSE
            include_class_area = EXISTS( SELECT 1 FROM "bpd"."global_prop" gp WHERE (gp."id_prop_type" = 3) AND EXISTS( SELECT 1 FROM classmove cd WHERE cd.id = gp.id_area_val ));
            IF (include_class_area) THEN
                action_state = 'class_del_include_class_area_val_for_global_prop';
            ELSE    
                action_state = 'action_allowed';
            END IF;    
            DROP TABLE classmove;
        END IF;
	
	--*********************************************************************************
	--ПРОВЕРКА ДОСТУПНОСТИ УДАЛЕНИЯ ПЕРЕНОСИМОГО КЛАССА ИЗ ТЕКУЩЕГО РАСПОЛОЖЕНИЯ КОНЕЦ
	--*********************************************************************************
	END IF;
    IF (action_state = 'action_allowed') THEN    
        --Шаг №01 Определяем штам времени 
        action_timestamp = LOCALTIMESTAMP(3);    
        
        --Шаг №02 Добавляем Класс паттерн в класс цель
        INSERT INTO "bpd"."class" ( 
            "id_con",
            "id_group",
            "id_group_root",
            "id_parent",
            "timestamp_parent",
            "id_root",
            "timestamp_root",
            "level",
            "path_array",
            "name",
            "name_format",
            "quantity_show",
            "desc",
            "on",
            "on_extensible",
            "on_abstraction",
            "on_freeze",
            "id_unit",
            "id_unit_conversion_rule",
            "barcode_manufacturer",
            "barcode_local",
            "timestamp",       
            "timestamp_child_change",
            "ready") 
        VALUES  (
            class_target."id_con",
            class_target."id_group",
            class_target."id_group_root",
            class_target."id",
            class_target."timestamp",
            class_target."id_root",
            class_target."timestamp_root",
            class_target."level" + 1,
            class_target."path_array",
            class_pattern."name",
            class_pattern."name_format",
            class_pattern."quantity_show",
            class_pattern."desc",
            class_pattern."on",
            class_pattern."on_extensible",
            class_pattern."on_abstraction",
            false,
            class_pattern."id_unit",
            class_pattern."id_unit_conversion_rule",
            class_pattern."barcode_manufacturer",
            0,
            action_timestamp,            
            action_timestamp,
            false)              
        RETURNING "id"  INTO "outid";
        "outid" = COALESCE("outid",0);
        
        --Шаг №02.1 Обновить массив пути класса
        UPDATE ONLY "bpd"."class" 
            SET
            path_array = path_array || ARRAY["outid"]
        WHERE id = "outid";
        
        --Шаг №02.2 Расчитываем баркод класса по идентификатору
        IF NOT class_pattern.on_abstraction THEN
            UPDATE ONLY "bpd"."class" 
                SET
                barcode_local = int_ean13_class_create("outid"),
                quantity_show = class_target.quantity_show,
                name_format = class_target.name_format
                WHERE id = "outid";
        END IF;
        
        --Шаг №02.3 Дублируем список правил конвертации величин измерения для вещественных классов
        IF NOT class_pattern.on_abstraction THEN
            INSERT INTO "bpd"."class_unit_conversion_rules" ( 
                "id_conception",
                "id_class", 
                "id_unit", 
                "id_unit_conversion_rule") 
            SELECT  
                "id_conception",
                "outid", 
                id_unit, 
                id_unit_conversion_rule
            FROM "bpd"."class_unit_conversion_rules"    
            WHERE "id_class" = class_pattern.id;    
        END IF;    
        
        --Шаг №3 Добавить свойства класса паттерна
        FOR class_prop_pattern IN SELECT cp.* FROM "bpd"."vclass_prop" cp WHERE cp.id_class = class_pattern.id
        LOOP
            --Шаг №3.1 Добавить свойства класса паттерна
            INSERT INTO "bpd"."class_prop" ( 
                "id_conception",
                "desc", 
                "id_class", 
                "id_data_type", 
                "id_prop_inherit", 
                "id_prop_type", 
                "inheritance", 
                "name", 
                "on_inherit", 
                "on_override", 
                "tag",
                "sort", 
                "timestamp_class", 
                "timestamp_class_inherit",
                  
                "id_class_definition",
                "timestamp_class_definition",
                "id_prop_definition") 
            VALUES(
                class_prop_pattern."id_conception",
                class_prop_pattern."desc",
                "outid",
                class_prop_pattern."id_data_type",
                -1,
                class_prop_pattern."id_prop_type",
                FALSE,
                class_prop_pattern."name",
                FALSE, 
                class_prop_pattern."on_override", 
                class_prop_pattern."tag",
                class_prop_pattern."sort",
                action_timestamp,
                class_target."timestamp",
                
                "outid",
                action_timestamp,
                -1)
            RETURNING "id"  INTO id_class_prop_copy;
            id_class_prop_copy = COALESCE(id_class_prop_copy,0);
        
            --Шаг №03.2 Назначаем новое свойство в качестве определяющего самому себе для классов сменивших расположение при копировании
            IF (class_target.id <> class_pattern.id_parent) THEN
                UPDATE ONLY "bpd"."class_prop"
                    SET
                        "id_prop_definition" = id_class_prop_copy
                    WHERE id = id_class_prop_copy;    
                
                --Шаг №03.3 Определяем наличие связи копируемого свойства с глобальным и копируем связь при необходимости
                IF (class_prop_pattern."on_global") THEN
                    PERFORM bpd.global_prop_link_class_prop_include(class_prop_pattern."id_global_prop", id_class_prop_copy);
                END IF;     
            ELSE
                --Для наследованных свойств классов сохранивших расположение
                IF (class_prop_pattern."inheritance") THEN
                    UPDATE ONLY "bpd"."class_prop"
                        SET
                            "id_prop_inherit" = class_prop_pattern."id_prop_inherit",
                            "timestamp_class_inherit" = class_prop_pattern."timestamp_class_inherit",
                            "on_inherit" = class_prop_pattern."on_inherit" 
                        WHERE id = id_class_prop_copy;    
                ELSE
                    --Шаг №03.2 Назначаем новое свойство в качестве определяющего самому себе для классов сменивших расположение при копировании
                    UPDATE ONLY "bpd"."class_prop"
                    SET
                        "id_prop_definition" = id_class_prop_copy,
                        "timestamp_class_definition" = action_timestamp
                    WHERE id = id_class_prop_copy;            
                    
                    --Шаг №03.3 Определяем наличие связи копируемого свойства с глобальным и копируем связь при необходимости
                    IF (class_prop_pattern."on_global") THEN
                        PERFORM bpd.global_prop_link_class_prop_include(class_prop_pattern."id_global_prop", id_class_prop_copy);
                    END IF;            
                END IF;        
            END IF;           
            
            --Шаг №03.2 Запрашиваем полученное скопированное свойство
            SELECT * INTO class_prop_copy FROM "bpd"."vclass_prop" WHERE id = id_class_prop_copy;
                
            --Шаг №04 Добавить значения свойств класса паттерна
            --*************************************************************************
            --**********ОБРАБОТКА ЗНАЧЕНИЙ СВОЙСТВ ПО ТИПУ СВОЙСТВА НАЧАЛО*************        
            --*************************************************************************
            --ШАГ №04 Получаем данные значения свойства класса паттерна
            CASE class_prop_pattern.id_prop_type
                WHEN 1 THEN --Пользовательское свойство
                    CASE class_prop_pattern.id_data_type
                        WHEN 7, 8, 14 THEN --BIG
                            
                            --ШАГ №04.1 Получаем данные значения копируемого свойства USER BIG
                            SELECT * INTO user_big_data_pattern FROM "bpd"."vclass_prop_user_big_val"        
                                            WHERE id_class_prop = class_prop_pattern.id;
                            
                            IF NOT(user_big_data_pattern IS NULL) THEN
                                    
                                --ШАГ №04.3 Данные значения наследующего свойства USER BIG не сохранены, встявляем
                                INSERT INTO "bpd"."class_prop_user_big_val"
                                    ("id_conception",	
									 "id_class",
                                     "timestamp_class",   
                                     "id_class_prop",
                                     "id_data_type",
                                     "inheritance",

                                     "min_val", 
                                     "max_val", 
                                     
                                     "val_text",
                                     "val_bytea",
                                     "val_json")
                                VALUES 
                                   (class_prop_copy.id_conception,
									class_prop_copy.id_class,
                                    class_prop_copy.timestamp_class,
                                    class_prop_copy.id,
                                    class_prop_pattern.id_data_type,
                                    TRUE,
                                    
                                    user_big_data_pattern."min_val", 
                                    user_big_data_pattern."max_val", 
                                    
                                    user_big_data_pattern."val_text",
                                    user_big_data_pattern."val_bytea",
                                    user_big_data_pattern."val_json");
                            END IF;
                        ELSE --SMALL (CASE)
                            
                            --ШАГ №04.1 Получаем данные значения наследуемого свойства USER SMALL
                            SELECT * INTO user_small_data_pattern FROM "bpd"."vclass_prop_user_small_val"        
                                            WHERE id_class_prop = class_prop_pattern.id;
                            
                            IF NOT(user_small_data_pattern IS NULL) THEN
                                --ШАГ №04.3 Данные значения наследующего свойства USER SMALL не сохранены, встявляем
                                INSERT INTO "bpd"."class_prop_user_small_val"
								   ("id_conception",	
                                    "id_class",
                                    "timestamp_class",   
                                    "id_class_prop",
                                    "id_data_type",
                                    "inheritance",
                             
                                    "min_on",
                                    "min_val",
                                    "max_on",
                                    "max_val",
                                    "round_on",
                                    "round",
                                    
                                    "val_varchar",
                                    "val_int",
                                    "val_numeric",
                                    "val_real",
                                    "val_double",
                                    "val_money",
                                    "val_boolean",
                                    "val_date",
                                    "val_time",
                                    "val_interval",
                                    "val_timestamp",
                                    "val_bigint")
                                VALUES 
								   (class_prop_copy.id_conception,
                                    class_prop_copy."id_class",
                                    class_prop_copy."timestamp_class",
                                    class_prop_copy.id,
                                    class_prop_pattern."id_data_type",
                                    TRUE,
                            
                                    user_small_data_pattern."min_on",
                                    user_small_data_pattern."min_val",
                                    user_small_data_pattern."max_on",
                                    user_small_data_pattern."max_val",
                                    user_small_data_pattern."round_on",
                                    user_small_data_pattern."round",
                                    
                                    user_small_data_pattern."val_varchar",
                                    user_small_data_pattern."val_int",
                                    user_small_data_pattern."val_numeric",
                                    user_small_data_pattern."val_real",
                                    user_small_data_pattern."val_double",
                                    user_small_data_pattern."val_money",
                                    user_small_data_pattern."val_boolean",
                                    user_small_data_pattern."val_date",
                                    user_small_data_pattern."val_time",
                                    user_small_data_pattern."val_interval",
                                    user_small_data_pattern."val_timestamp",
                                    user_small_data_pattern."val_bigint");
                            END IF;        
                    END CASE;    
                WHEN 2 THEN --Перечисление    
                    --ШАГ №04.1 Получаем данные значения наследуемого свойства ENUM
                    SELECT * INTO enum_data_pattern FROM "bpd"."vclass_prop_enum_val"        
                                    WHERE id_class_prop = class_prop_pattern.id;
                    
                    IF NOT(enum_data_pattern IS NULL) THEN
                            
                        --ШАГ №04.3 Данные значения наследующего свойства ENUM не сохранены, встявляем
                        INSERT INTO "bpd"."class_prop_enum_val"
						   ("id_conception",	
                            "id_class",
                            "timestamp_class",   
                            "id_class_prop",
                            "inheritance",

                            "id_prop_enum",
                            
                            "id_prop_enum_val")
                        VALUES 
						   (class_prop_copy.id_conception,
                            class_prop_copy.id_class,
                            class_prop_copy.timestamp_class,
                            class_prop_copy.id,
                            TRUE,
                            
                            enum_data_pattern."id_prop_enum",
                            
                            enum_data_pattern."id_prop_enum_val");
                    END IF;        
                WHEN 3 THEN --Объектное
                    --ШАГ №04.1 Получаем данные значения наследуемого свойства OBJECT
                    SELECT * INTO object_data_pattern FROM "bpd"."vclass_prop_object_val"        
                                    WHERE id_class_prop = class_prop_pattern.id;
                    
                    IF NOT(object_data_pattern IS NULL) THEN
                        --ШАГ №04.3 Данные значения наследующего свойства OBJECT не сохранены, встявляем
                        INSERT INTO "bpd"."class_prop_obj_val_class" 
						   ("id_conception",	
                            "id_class",
                            "timestamp_class",
                            "id_class_prop",
                            
                            "bquantity_max",
                            "bquantity_min",
                            
                            "id_class_val",
                            "timestamp_class_val")
                        VALUES
						   (class_prop_copy.id_conception,
                            class_prop_copy.id_class,
                            class_prop_copy."timestamp_class",
                            class_prop_copy.id,
                           
                            object_data_pattern.bquantity_max,
                            object_data_pattern.bquantity_min,
                            
                            object_data_pattern.id_class_val,
                            object_data_pattern.timestamp_class_val);
                    END IF;    
                WHEN 4 THEN --Ссылка    
                    --ШАГ №04.1 Получаем данные значения наследуемого свойства LINK
                    SELECT * INTO link_data_pattern FROM "bpd"."vclass_prop_link_val"        
                                    WHERE id_class_prop = class_prop_pattern.id;
                    
                    IF NOT(link_data_pattern IS NULL) THEN
                            
                        --ШАГ №04.3 Данные значения наследующего свойства LINK не сохранены, встявляем
                        INSERT INTO "bpd"."class_prop_link_val"
						   ("id_conception",	
                            "id_class",
                            "timestamp_class",   
                            "id_class_prop",
                            "inheritance",

                            "id_entity",
                            "id_entity_instance")
                        VALUES 
						   (class_prop_copy.id_conception,
                            class_prop_copy.id_class,
                            class_prop_copy.timestamp_class,
                            class_prop_copy.id,
                            TRUE,
                            
                            link_data_pattern."id_entity",
                            link_data_pattern."id_entity_instance");
                    END IF;            
            END CASE;    
            --*************************************************************************
            --**********ОБРАБОТКА ЗНАЧЕНИЙ СВОЙСТВ ПО ТИПУ СВОЙСТВА КОНЕЦ**************
            --*************************************************************************
        END LOOP;
        
        --Шаг №02 Добавить свойства родительского класса
        FOR class_prop_copy IN SELECT cp.* FROM "bpd"."vclass_prop" cp WHERE cp.id_class = class_target."id"
        LOOP
            PERFORM  int.int_class_prop_inherit(class_prop_copy.id, "outid");
        END LOOP;
        
        --Шаг №03 Добавить значения свойств родительского класса
        FOR class_prop_copy IN SELECT cp.* FROM "bpd"."vclass_prop" cp WHERE cp.id_class = "outid"
        LOOP
            PERFORM  int.int_class_prop_val_inherit(class_prop_copy.id);
        END LOOP;
          
        --Шаг №06 Обновить штамп времени timestamp_child_change родительского класса
        UPDATE ONLY "bpd"."class" 
            SET
                "on_extensible" = true,
                timestamp_child_change = action_timestamp
            WHERE id = class_target."id";         
        
        --Шаг №07 Запустить процедуру рекурсивного копирования вложенных классов класса образца
        FOR class_pattern_child IN SELECT c.* FROM ONLY "bpd"."class" c WHERE c.id_parent = class_pattern."id"
        LOOP
            PERFORM  int.int_class_copy_to_class(class_pattern_child.id, "outid");
        END LOOP; 
        
        --Шаг №08 Удалить класс образец в текущем расположении
        PERFORM  "bpd"."class_del"(iid_pattern);
	END IF;
	
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
	perform error_exception( 'class_move_to_class', action_state);
END;
$BODY$;
CREATE OR REPLACE FUNCTION bpd.class_prop_link_val_set(IN iid_class_prop bigint,IN iid_entity bigint,IN iid_entity_instance bigint,IN iid_sub_entity_instance bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    VOLATILE SECURITY DEFINER
    PARALLEL SAFE
    COST 100
    
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --Дата: 02.04.2020
    --Автор: Иванов Д.Ю.
	--Версия: 3.0
    --Описание: Функция добавляет значение в виде ссылки на сущность для свойства класса типа ссылка
    --**************************************************************************
    eclass_prop "bpd"."vclass_prop"%ROWTYPE; -- Редактируемое свойство класса
    class_carrier "bpd"."class"%ROWTYPE; -- Класс носитель редактируемого свойства
    inherit_class_prop "bpd"."vclass_prop"%ROWTYPE; --НАСЛЕДУЕМОЕ СВОЙСТВО КЛАССА
    inherit_class_prop_link_val "bpd"."class_prop_link_val"%ROWTYPE; --Данные значения наследуемого свойства класса
    
    link_entity "bpd"."ventity"%ROWTYPE; -- Линкуемая сущность
    link_entity_instance record; --Экземпляр линкуемой сущности
    cur_entity_instance bigint; --Текущее значение идентификатора экземпляра линкуемой сущности
    cur_entity_instance_conception bigint default -1; --Концепция текущего значения идентификатора экземпляра линкуемой сущности
    global_prop_area_val bigint; --Область значения глобального свойства
            
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
    --*********************************************************
	action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
BEGIN 
	SELECT * INTO eclass_prop   FROM ONLY "bpd"."vclass_prop" WHERE id = iid_class_prop;
	IF (eclass_prop IS NULL) THEN
        --Редактируемое свойство не найдено
        action_state = 'class_prop_not_found';
	ELSE 
        SELECT * INTO class_carrier  FROM ONLY "bpd"."class" WHERE id = eclass_prop.id_class;
        IF (class_carrier IS NULL) THEN
            --Класс носитель свойства не найден
            action_state = 'class_carrier_not_found';
        ELSE
            IF (eclass_prop.id_prop_type <> 4) THEN
                --Свойство класса не является ссылкой
                action_state = 'class_prop_not_link_type';
            ELSE
                SELECT * INTO link_entity FROM "bpd"."ventity" WHERE "id" = iid_entity;
                IF (link_entity IS NULL) THEN
                    --Указанная сущность не найдена
                    action_state = 'entity_not_found';
                ELSE
                    IF NOT (link_entity.can_link) THEN
                        --Указанная сущность не может быть залинкована
                        action_state = 'entity_not_can_link';
                    ELSE    
                        IF COALESCE(iid_entity_instance, -1) > 0 THEN
                            CASE (link_entity.id)
                                WHEN 3 THEN
                                    --pos_temp
                                    SELECT * INTO link_entity_instance FROM "bpd"."pos_temp" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_con;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;    
                                WHEN 4 THEN 
                                    --position
                                    SELECT * INTO link_entity_instance FROM "bpd"."position" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_con;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;    
                                
                                WHEN 8 THEN
                                    --user
                                    SELECT * INTO link_entity_instance FROM "bpd"."users" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = eclass_prop.id_conception;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;    
                                    
                                WHEN 9 THEN
                                    --pos_prop
                                    SELECT * INTO link_entity_instance FROM "bpd"."vposition_prop" WHERE "id_pos_temp_prop" = iid_entity_instance AND "id_position_carrier" = iid_sub_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_conception;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;            
                                
                                WHEN 10 THEN
                                    --pos_temp_prop
                                    SELECT * INTO link_entity_instance FROM "bpd"."pos_temp_prop" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_conception;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;
                                WHEN 17 THEN
                                    --group
                                    SELECT * INTO link_entity_instance FROM "bpd"."group" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_con;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;    
                                WHEN 18 THEN
                                    --class
                                    SELECT * INTO link_entity_instance FROM ONLY "bpd"."class" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        IF (class_carrier.id = link_entity_instance.id) THEN
                                            action_state = 'entity_instance_is_circular_link';
                                        ELSE    
                                            cur_entity_instance_conception = link_entity_instance.id_con;
                                            action_state = 'entity_instance_is_allowed';
                                        END IF;    
                                    END IF;    
                                WHEN 19 THEN
                                    --class_prop
                                    SELECT * INTO link_entity_instance FROM ONLY "bpd"."class_prop" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        IF (eclass_prop.id = link_entity_instance.id) THEN
                                            action_state = 'entity_instance_is_circular_link';
                                        ELSE
                                            cur_entity_instance_conception = link_entity_instance.id_conception;
                                            action_state = 'entity_instance_is_allowed';
                                        END IF;    
                                    END IF;    
                                WHEN 20 THEN
                                    --object
                                    SELECT * INTO link_entity_instance FROM "bpd"."object" WHERE "id" = iid_entity_instance;
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_conception;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;    
                                WHEN 44 THEN
                                    --object_prop
                                    SELECT * INTO link_entity_instance FROM "bpd"."vobject_prop" WHERE ("id_class_prop" = iid_entity_instance) AND ("id_object_carrier" = iid_sub_entity_instance);
                                    IF (link_entity_instance IS NULL) THEN
                                        action_state = 'entity_instance_not_found';
                                    ELSE
                                        cur_entity_instance_conception = link_entity_instance.id_conception;
                                        action_state = 'entity_instance_is_allowed';
                                    END IF;        
                            END CASE;
                            
                            IF (action_state = 'entity_instance_is_allowed') THEN
                                IF (cur_entity_instance_conception <> eclass_prop.id_conception) THEN
                                    --Концепции свойства и линкуемого экземпляра сущности не совпадают
                                    action_state = 'conception_not_match';
                                ELSE
                                    --Указанный экземпляр сущности допустим
                                    action_state = 'entity_instance_is_valid';
                                    cur_entity_instance = iid_entity_instance;
                                END IF;    
                            END IF;    
                        ELSE
                            --Указанный экземпляр сущности допустим
                            action_state = 'entity_instance_is_valid';
                            cur_entity_instance = null;
                        END IF;
                        IF (action_state = 'entity_instance_is_valid') THEN
                            --==========================================================================================
                            --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА НАЧАЛО
                            --==========================================================================================
                            IF NOT(eclass_prop.inheritance) THEN
                               --Свойство определяющее
								--Проверяем класс значение для определяющего свойства связанного с глобальным	
								IF EXISTS(SELECT FROM ONLY bpd.class_prop cp
						     				LEFT JOIN bpd.global_prop_link_class_prop lgp 
											ON lgp.id_class_prop_definition = cp.id_prop_definition
											WHERE cp.id = eclass_prop.id) THEN
							
									--Определяем совпадение указанного перечисления с областью значения глобального свойства
									SELECT gp.id_area_val INTO global_prop_area_val FROM bpd.global_prop gp
											JOIN bpd.global_prop_link_class_prop lgp ON lgp.id_global_prop = gp.id
											JOIN ONLY bpd.class_prop cp ON cp.id_prop_definition = lgp.id_class_prop_definition
											WHERE cp.id = eclass_prop.id;
									
									IF (global_prop_area_val <> link_entity.id) THEN
										
										action_state = 'link_val_not_match_link_val_global_prop';                                
									ELSE
										action_state = 'action_allowed';
									END IF;
								END IF;	
                            ELSE 
                                --Определяем наследуемое свойство
                                SELECT * INTO inherit_class_prop   FROM ONLY "bpd"."vclass_prop" WHERE id = eclass_prop."id_prop_inherit";
                                IF (inherit_class_prop IS NULL) THEN
                                    --Наследуемое свойство не найдено
                                    action_state = 'inherit_class_prop_not_found';
                                ELSE
                                    IF NOT(inherit_class_prop.on_override) THEN
                                        --Наследуемое свойство не переопределяемое, изменение значения не разрешено
                                        action_state = 'inherit_class_prop_not_override';
                                    ELSE
                                        SELECT * INTO inherit_class_prop_link_val FROM  ONLY "bpd"."class_prop_link_val" WHERE "id_class_prop" = inherit_class_prop.id;
                                        IF (inherit_class_prop_link_val IS NULL) THEN
                                            --Данные значения наследуемого свойства не определены
                                            action_state = 'inherit_class_prop_val_not_set';
                                        ELSE
                                            IF (inherit_class_prop_link_val.id_entity <> iid_entity) THEN
                                                --Сущности редактируемого и наследованного свойств не совпадают
                                                action_state = 'entity_not_match';
                                            ELSE
                                                --Действие разрешено
                                                action_state = 'action_allowed';
                                            END IF;
                                        END IF;     
                                    END IF;
                                END IF;
                            END IF;
                            --==========================================================================================
                            --***********ОБЛАСТЬ ПРОВЕРКИ ДОПУСТИМОСТИ ПЕРЕОПРЕДЕЛЕНИЯ ЗНАЧЕНИЯ СВОЙСТВА КОНЕЦ
                            --==========================================================================================    
                        END IF;
                    END IF;    
                END IF;
            END IF;
        END IF;
	END IF;
	
	IF (action_state = 'action_allowed') THEN
        --Шаг №01 Определяем штам времени для измененного класса
        action_timestamp = LOCALTIMESTAMP(3);    
        
        --Шаг №02 Удаляем существующие значения классов
        --DELETE FROM ONLY "bpd"."class_prop_link_val"
        --    WHERE "id_class_prop" = eclass_prop.id;        
        
        --Шаг №03 Добавляем значение свойства    
        INSERT INTO "bpd"."class_prop_link_val" ( 
            "id_conception",
			"id_class", 
            "timestamp_class", 
            "id_class_prop", 
            "id_entity", 
            "id_entity_instance", 
            "id_sub_entity_instance",
            "inheritance") 
        VALUES ( 
			class_carrier.id_con,
            class_carrier.id,
            action_timestamp,
            eclass_prop.id,
            iid_entity,
            iid_entity_instance,
            iid_sub_entity_instance,
            FALSE)
            ON CONFLICT ("id_class_prop") DO 
		UPDATE SET 
			"id_entity" = EXCLUDED."id_entity",
            "id_entity_instance" = EXCLUDED."id_entity_instance",
            "id_sub_entity_instance" = EXCLUDED."id_sub_entity_instance",
			"inheritance" = FALSE;
			
        --Шаг №04.1 Обновить штамп времени класса
        UPDATE ONLY "bpd"."class" c
            SET 
                "timestamp" = action_timestamp            
            WHERE (c.id = class_carrier.id)  AND (c."timestamp" <> action_timestamp);        
    
        --Шаг №04.2 Обновить штамп времени свойства класса
        UPDATE ONLY "bpd"."class_prop" cp
            SET 
                "timestamp_class" = action_timestamp            
            WHERE (cp.id = eclass_prop.id) AND (cp."timestamp_class" <> action_timestamp);
        
        --Шаг №04.1 Переопределяем место хранения значения наследованного переопределяемого свойства
        IF eclass_prop.inheritance THEN
            UPDATE ONLY "bpd"."class_prop" 
                SET 
                    on_inherit = FALSE
                WHERE id = eclass_prop.id;        
        END IF;    
                    
        --Шаг №05 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
            --PERFORM bpd.int_sync_timestamp_by_id_class(class_carrier.id);
        --Шаг №06 Запустить каскадное наследовниае значения свойства в наследующих классах    
            PERFORM int.int_class_prop_val_inherit(eclass_prop.id, true);                   
    END IF;    
	
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
    perform error_exception( 'class_prop_link_val_set', action_state);
END;
$BODY$;

 END;
BEGIN;
TRUNCATE err.error_code_ru;
INSERT INTO err.error_code_ru(
	codeerr, actionerr, entity, messageerr, hinterr, classerr, func)
	VALUES 
('emembed_object_quantity_above_max', 'copy', 'object', 'Суммарное количество объектов полученное в результате копирования объекта в указанное расположение превышает разрешенный лимит на встраивание', '-', '3', 'object_copy'), 
('none', 'copy', 'object', 'Неизвестная ошибка копирования объекта', '-', '3', 'object_copy'), 
('class_object_pattern_not_include_branch_class_val', 'copy', 'object', 'Класс копируемого объекта не наследован от класса значения объектного свойства', '-', '3', 'object_copy'), 
('on_override_true_not_allowed', 'update', 'class_prop', 'Указанное редактируемое свойсво наследовано от не переопределяемого свойства класса и не может быть переопределяемым', '-', '3', 'class_prop_upd'), 
('on_inherit_false_not_allowed', 'update', 'class_prop', 'Указанное редактируемое свойсво наследовано от не переопределяемого свойства класса и не допускает отключение режима наследования значения', '-', '3', 'class_prop_upd'), 
('class_real_include_noready_class_prop', 'insert', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'object_add_by_single_unit'), 
('ppos_not_found', 'insert', 'object', 'Указанная целевая позиция не найдена', '-', '3', 'object_add_by_single_unit'), 
('conception_ppos_and_pclass_not_match', 'insert', 'object', 'Концепции вещественного класса и целевой позиции не совпадают', '-', '3', 'object_add_by_single_unit'), 
('ppos_in_recycle_space', 'insert', 'object', 'Целевая позиция удалена в корзину', '-', '3', 'object_add_by_single_unit'), 
('pos_prototype_ppos_not_allow_include_object', 'insert', 'object', 'Прототип шаблона позиции не допускает размещение объектов', '-', '3', 'object_add'), 
('pos_prototype_ppos_not_allow_include_object', 'insert', 'object', 'Прототип шаблона позиции не допускает размещение объектов', '-', '3', 'object_add_by_single_unit'), 
('rulel1_class_on_pos_temp_not_allowed', 'insert', 'object', 'Классу объекта не назначено разрешение уровня 1 для шаблона указанной позиции', '-', '3', 'object_add_by_single_unit'), 
('rulel2_class_on_position_not_allowed', 'insert', 'object', 'Перечень правил вложенности позиции уровня 2 класс на позицию не содержит разрешения для указанного вещественного класса', '-', '3', 'object_add_by_single_unit'), 
('class_unit_conversion_rule_not_available', 'insert', 'object', 'Указано правило пересчета не назначено для выбранного вещественного класса', '-', '3', 'object_add_by_single_unit'), 
('unit_conversion_rule_not_found', 'insert', 'object', 'Указанное правило пересчета не найдено', '-', '3', 'object_add_by_single_unit'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'object_add_by_single_unit'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указаное значение колличества объекта превышает заданную точность округления', '-', '3', 'object_add_by_single_unit'), 
('rule_quantity_violated', 'insert', 'object', 'Указанное количество объектов меньше нуля', 'Количество объектов не может быть отрицательной величиной', '3', 'object_add_by_single_unit'), 
('conception_not_found', 'insert', 'global_prop', 'Указанная концепция не найдена', '-', '1', 'global_prop_add'), 
('log_set_main_link_not_found', 'update', 'log', 'Указанная запись лога не найдена', '-', '1', 'log_set_main_link'), 
('object_carrier_not_found', 'insert', 'object', 'Указанный объект носитель свойства не найден', '-', '1', 'object_prop_object_val_add'), 
('object_carrier_not_found', 'insert', 'object', 'Указанный объект носитель свойства не найден', '-', '1', 'object_prop_object_val_add_new'), 
('object_val_not_found', 'insert', 'object', 'Указанный объект значение свойства не найден', '-', '1', 'object_prop_object_val_add'), 
('parent_position_not_found', 'insert', 'object', 'Позиция целевого объекта не найдена', '-', '1', 'object_prop_object_val_add'), 
('parent_position_not_found', 'insert', 'object', 'Позиция целевого объекта не найдена', '-', '1', 'object_prop_object_val_add_new'), 
('object_carrier_include_branch_object_val', 'insert', 'object', 'Указанный целевой объект встроен в объект значение', '-', '3', 'object_prop_object_val_add'), 
('object_conception_not_math', 'insert', 'object', 'Концепции целевого объекта и объекта значения не совпадают', '-', '3', 'object_prop_object_val_add'), 
('parent_position_in_recycle_space', 'insert', 'object', 'Целевой объект удален в корзину', '-', '3', 'object_prop_object_val_add'), 
('class_parent_not_on', 'insert', 'class', 'Указанный родительский класс выключен', '-', '3', 'class_add'), 
('class_parent_not_abstraction', 'insert', 'class', 'Указанный родительский класс не является абстрактным', '-', '3', 'class_add'), 
('none', 'insert', 'class', 'Неизвестная ошибка создания класса', '-', '3', 'class_add'), 
('parent_position_in_recycle_space', 'insert', 'object', 'Целевой объект удален в корзину', '-', '3', 'object_prop_object_val_add_new'), 
('class_prop_obj_val_not_found', 'insert', 'object', 'Данные значения объектного свойства не определены в снимке класса объекта носителя', '-', '3', 'object_prop_object_val_add_new'), 
('log_link_is_log_main_link', 'delete', 'log_link', 'Указанная ссылка записи журнала определена как основная', 'Назначте другую ссылку в качестве основной ссылки записи журнала, перед удалением текущей ссылки', '3', 'log_link_del'), 
('class_parent_not_include_abstraction_class', 'insert', 'class', 'Указанный родительский класс содержит вещественные классы и не допускает вложения абстрактных классов', '-', '3', 'class_add'), 
('class_add_is_real_not_extensible', 'insert', 'class', 'Создавемый класс помечен как вещественный и не может быть расширяемым', 'Вещественные классы предназначены для создания объектов и не допускают определения дополнительных свойств в объектах', '3', 'class_add'), 
('unit_conversion_rules_is_undefined', 'insert', 'class', 'Указанна неопределенная измеряемая величина, не допустимая для вещественных классов', 'Вещественный классы не могут иметь неопределенную измеряемую величину', '3', 'class_add'), 
('unit_not_match', 'insert', 'class', 'Измеряемая величина родительского класса не совпадает с измеряемой величиной выбранного правила пересчета', 'Укажите правило пересчета входящее в список правил родительского класса', '3', 'class_add'), 
('conception_not_match', 'insert', 'class', 'Концепции правила пересчета и родительского класса не совпадают', '-', '3', 'class_add'), 
('class_unit_not_allowed', 'insert', 'class', 'Указанная измеряемая величина не совпадает с измеряемой величиной родительского класса', 'Родительский класс имеет определенную измеряемую величину и не доспускает ее изменение в наследующих классах', '3', 'class_add'), 
('barcode_manufacturer_not_volidation', 'insert', 'class', 'Штрих-код производителя не проходит контрольную проверку', 'Укажите допустимый штрих-код производителя', '3', 'class_add'), 
('class_add_name_not_unique', 'insert', 'class', 'Наименование класса  не является уникальным в текущем расположении', 'Наименования классов в одном расположении должны быть уникальны', '2', 'class_add'), 
('unknown_error', 'any', 'entity', 'Неизвестная ошибка функции API', 'Обратитесь к разработчику программного интерфейса', '3', 'class_add'), 
('group_parent_not_found', 'insert', 'class', 'Указанная родительская группа не найдена', '-', '1', 'class_add'), 
('group_parent_in_recycle_space', 'insert', 'class', 'Указанная родительская группа входит в пространство корзины концепции', '-', '3', 'class_add'), 
('group_parent_not_include_class', 'insert', 'class', 'Указанная родительская группа не допускает размещение классов', '-', '3', 'class_add'), 
('class_add_extensible_not_volidation', 'insert', 'class', 'Недопустимо создание не расширяемого базового класса', 'Базовый класс должен обеспечивать возможность расширения свойств для вложенных абстрактных классов', '3', 'class_add'), 
('prop_type_not_found', 'insert', 'global_prop', 'Указаный тип свойства класса не найден', '-', '7', 'global_prop_add'), 
('format_is_empty', 'update', 'class', 'В метод передан пустой или недопустимый формат', '-', '3', 'class_act_name_format_set'), 
('format_is_over_limit', 'update', 'class', 'Представленный формат превышает установленный лимит на длинну строки 255 символов', '-', '3', 'class_act_name_format_set'), 
('group_del_not_found', 'delete', 'group', 'Указанная группа не найдена', '-', '1', 'group_del'), 
('class_not_allow_set_format', 'update', 'class', 'Указанный класс не является абстрактным классом и не допускает определение формата имен объектов', 'Указанный класс является вещественным', '3', 'class_act_name_format_set'), 
('class_not_found', 'update', 'class', 'Указанный класс не найден', '-', '7', 'class_act_name_format_set'), 
('class_parent_not_found', 'insert', 'class', 'Указанный родительский класс не найден', '-', '1', 'class_add'), 
('class_real_include_noready_class_prop', 'insert', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'object_add'), 
('class_real_noready_name_format', 'insert', 'object', 'Шаблон наименования объектов выбранного вещественного класса не готов к созданию объектов', '-', '3', 'object_add'), 
('unit_conversion_rules_not_found', 'insert', 'class', 'Указанное правило пересчета не найдено', '-', '1', 'class_add'), 
('format_class_prop_not_found', 'update', 'class', 'Представленный формат содержит ссылки на свойства отсуствующие в указанном классе', '-', '3', 'class_act_name_format_set'), 
('class_act_is_found', 'restore', 'class', 'Указанный объект имеет активное представление класса', 'Объект сопоставлен с активным представлением своего класса и не нуждается в восстановлении', '3', 'class_act_restore'), 
('class_snapshot_not_found', 'restore', 'class', 'Указанный объект имеет опрного снимка класса', 'Концепция повреждена, нарушена целостность объектных данных', '3', 'class_act_restore'), 
('group_restore_create_error', 'restore', 'class', 'Ошибка восстановления группы активного класса', 'Текущая структура концепции не позволяет создать группу для востанавливаемого класса. Попробуйте метод восстановления концепции.', '3', 'class_act_restore'), 
('conception_not_match', 'copy', 'position', 'Концепции копируемой и целевой позиций не совпадают', '-', '3', 'position_copy'), 
('pclass_not_real', 'insert', 'object', 'Выбранный класс не является вещественным', '-', '3', 'object_add'), 
('class_add_name_is_empty', 'insert', 'class', 'Выбранное наименование слишком короткое', '-', '3', 'class_add'), 
('class_target_not_found', 'restore', 'class', 'Указанный целевой класс выключен и не может принимать новые классы', 'Восстановление активного класса происходит в выключенный родительский класс', '3', 'class_act_restore'), 
('class_target_not_abstraction', 'restore', 'class', 'Указанный целевой класс не является абстрактным', 'Указанный целевой класс должен быть абстрактным для успешного добавления вложенного класса', '3', 'class_act_restore'), 
('unit_not_math', 'restore', 'class', 'Измеряемые величины целевого и восстанавливаемого классов не совпадают', '-', '3', 'class_act_restore'), 
('class_target_cannot_include_abstraction_class', 'restore', 'class', 'Указанный целевой класс не допускает вложения абстрактных классов', 'Целевой класс содержит вещественные классы и не может содержать абстрактные классы', '3', 'class_act_restore'), 
('class_target_cannot_include_real_class', 'restore', 'class', 'Указанный целевой класс не допускает вложения вещественных классов', 'Целевой класс содержит абстрактные классы и не может содержать вещественные классы', '3', 'class_act_restore'), 
('none', 'update', 'class', 'Незвестная ошибка определения формата имен объектов', '-', '3', 'class_act_name_format_set'), 
('doc_parent_not_found', 'insert', 'doc_file', 'Указанный документ не найден', '-', '1', 'doc_file_add'), 
('class_target_not_found', 'copy', 'class', 'Указанный целевой класс не найден', '-', '1', 'class_copy_to_class'), 
('none', 'restore', 'class', 'Неизвестная ошибка восстановления активного класса объекта', 'Возможно повреждение структуры данных концепции', '3', 'class_act_restore'), 
('class_target_not_on', 'copy', 'class', 'Указанный целевой класс выключен и не может принимать новые классы', '-', '3', 'class_copy_to_class'), 
('class_target_not_abstraction', 'copy', 'class', 'Указанный целевой класс не является абстрактным', '-', '3', 'class_copy_to_class'), 
('log_link_is_log_main_link', 'delete', 'log_link', 'Указанная ссылка записи журнала определена как основная', 'Назначте другую ссылку в качестве основной ссылки записи журнала, перед удалением текущей ссылки', '3', 'log_link_del_by_entity'), 
('conception_not_math', 'copy', 'class', 'Концепции целевого и переносимого классов не совпадают', '-', '3', 'class_copy_to_class'), 
('unit_not_math', 'copy', 'class', 'Измеряемые величины целевого и переносимого классов не совпадают', '-', '3', 'class_copy_to_class'), 
('class_target_not_include_class_pattern_extensible', 'copy', 'class', 'Указанный целевой класс является не расширяемым и не может принимать расширяемые классы', '-', '3', 'class_copy_to_class'), 
('log_link_set_main_link_not_found', 'update', 'log', 'Указанная ссылка записи лога не найдена или не входит в список ссылок записи лога', '-', '1', 'log_set_main_link'), 
('class_target_cannot_include_abstraction_class', 'copy', 'class', 'Указанный целевой класс не допускает вложения абстрактных классов', '-', '3', 'class_copy_to_class'), 
('group_target_not_found', 'copy', 'class', 'Указанная целевая группа не найдена', '-', '1', 'class_copy_to_group'), 
('class_target_cannot_include_real_class', 'copy', 'class', 'Указанный целевой класс не допускает вложения вещественных классов', '-', '3', 'class_copy_to_class'), 
('none', 'copy', 'class', 'Неизвестная ошибка копирования класса', '-', '3', 'class_copy_to_class'), 
('group_target_cannot_include_class', 'copy', 'class', 'Указанная целевая группа не допускает вложения классов', '-', '3', 'class_copy_to_group'), 
('conception_not_math', 'copy', 'class', 'Концепции целевого и переносимого классов не совпадают', '-', '3', 'class_copy_to_group'), 
('class_pattern_not_base', 'copy', 'class', 'Указанный копируемый класс не является базовым', '-', '3', 'class_copy_to_group'), 
('none', 'copy', 'class', 'Неизвестная ошибка копирования класса', '-', '3', 'class_copy_to_group'), 
('group_target_in_recycle_space', 'copy', 'class', 'Указанный копируемый класс находится в корзине', '-', '3', 'class_copy_to_group'), 
('conception_ppos_and_pclass_not_match', 'insert', 'object', 'Концепции вещественного класса и целевой позиции не совпадают', '-', '3', 'object_add'), 
('class_del_not_found', 'delete', 'class', 'Указанный класс не найден', '-', '1', 'class_del'), 
('class_del_include_class_val_for_object_prop', 'delete', 'class', 'Указанный класс используется в качестве значения в объектных свойствах и не может быть удален', '-', '1', 'class_del'), 
('class_del_include_class_area_val_for_global_prop', 'delete', 'class', 'Указанный класс используется в качестве области значения глобальных объектных свойств и не может быть удален', '-', '1', 'class_del'), 
('none', 'delete', 'class', 'Неизвестная ошибка удаления класса', '-', '1', 'class_del'), 
('class_upd_not_found', 'insert', 'class_prop', 'Указанный класс не найден', '-', '1', 'class_prop_add'), 
('class_inherited_not_extensible', 'insert', 'class_prop', 'Наследуемый класс указанного класса объявлен как нерасширяемый и не допускает добавление расширенных свойств в наследующих классах', '-', '3', 'class_prop_add'), 
('prop_type_not_allow_unit', 'insert', 'class_prop', 'Указанный тип свойства не совместим с измеряемой величиной несущего класса', '-', '3', 'class_prop_add'), 
('class_prop_name_not_unique', 'insert', 'class_prop', 'Указанное наименование свойства не уникально в пределах несущего класса или недопустимо', '-', '3', 'class_prop_add'), 
('class_prop_override_not_valid', 'insert', 'class_prop', 'Объектное свойство вещественного класса не может быть переопределяемым', '-', '3', 'class_prop_add'), 
('none', 'insert', 'class_prop', 'Неизвестная ошибка добавления определяющего свойства класса', '-', '3', 'class_prop_add'), 
('prop_type_not_found', 'insert', 'class_prop', 'Указаный тип свойства класса не найден', '-', '7', 'class_prop_add'), 
('class_prop_not_found', 'delete', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_del'), 
('class_prop_is_inheritance', 'delete', 'class_prop', 'Указанное свойство наследовано от вышестоящего класса', '-', '3', 'class_prop_del'), 
('none', 'delete', 'class_prop', 'Неизвестная ошибка удаления свойства класса', '-', '3', 'class_prop_del'), 
('none', 'insert', 'global_prop', 'Неизвестная ошибка добавления глобального свойства', '-', '3', 'global_prop_add'), 
('doc_category_has_package_doc', 'update', 'doc_category', 'Указанная категория документов содержит пакеты документов, выключение режима пакетирования недоступно', '-', '3', 'doc_category_upd'), 
('doc_category_has_internal_doc', 'update', 'doc_category', 'Указанная категория документов содержит вложенные документы, включение режима пакетирования недоступно', '-', '3', 'doc_category_upd'), 
('name_not_unique', 'update', 'doc_category', 'Указанное наименование категории документов не является уникальным в текущей концепции', '-', '3', 'doc_category_upd'), 
('none', 'update', 'doc_category', 'Неизвестная ошибка изменения категории документа', '-', '3', 'doc_category_upd'), 
('doc_file_data_found_in_document', 'insert', 'doc_file', 'Загружаемый файл найден в листе файлов документа', '-', '3', 'doc_file_add'), 
('conception_actcatalog_not_set', 'insert', 'doc_file', 'В текущей концепции не определен активный каталог библиотеки документов', '-', '3', 'doc_file_add'), 
('file_data_is_null', 'insert', 'doc_file', 'Передан пустой двоичный массив не содержащий данных файла', '-', '3', 'doc_file_add'), 
('class_inherited_not_extensible', 'move', 'class', 'Наследуемый класс целевого класса объявлен как нерасширяемый и не допускает операции вставки при копировании и переносе классов', '-', '1', 'class_move_to_class'), 
('class_target_not_found', 'move', 'class', 'Указанный целевой класс не найден', '-', '1', 'class_move_to_class'), 
('class_target_not_on', 'move', 'class', 'Указанный целевой класс выключен и не может принимать новые классы', 'Попробуйте изменить состояние целевого класса на включен', '3', 'class_move_to_class'), 
('class_target_not_abstraction', 'move', 'class', 'Указанный целевой класс не является абстрактным', '-', '3', 'class_move_to_class'), 
('class_pattern_in_class_target', 'move', 'class', 'Переносимый класс находится в указанном расположении', 'Функция не допускает перенос в текущее расположение', '3', 'class_move_to_class'), 
('class_pattern_on_freeze', 'move', 'class', 'Указанный целевой класс заблокирован и не может быть перемещен', '-', '3', 'class_move_to_class'), 
('conception_not_math', 'move', 'class', 'Концепции целевого и переносимого классов не совпадают', '-', '3', 'class_move_to_class'), 
('unit_not_math', 'move', 'class', 'Измеряемые величины целевого и переносимого классов не совпадают', '-', '3', 'class_move_to_class'), 
('class_target_not_include_class_pattern_extensible', 'move', 'class', 'Указанный целевой класс является не расширяемым и не может принимать расширяемые классы', '-', '3', 'class_move_to_class'), 
('class_target_cannot_include_abstraction_class', 'move', 'class', 'Указанный целевой класс не допускает вложения абстрактных классов', '-', '3', 'class_move_to_class'), 
('class_target_cannot_include_real_class', 'move', 'class', 'Указанный целевой класс не допускает вложения вещественных классов', '-', '3', 'class_move_to_class'), 
('class_del_include_class_val_for_object_prop', 'move', 'class', 'Указанный класс имеет назначения в качестве значения объектных свойств и не может быть перемещен', '-', '3', 'class_move_to_class'), 
('class_del_include_class_area_val_for_global_prop', 'move', 'class', 'Указанный класс используется в качестве области значения глобальных объектных свойств и не может быть перемещен', '-', '3', 'class_move_to_class'), 
('none', 'move', 'class', 'Неизвестная ошибка переноса класса', '-', '3', 'class_move_to_class'), 
('class_move_not_found', 'move', 'class', 'Указанный базовый класс не найден', '-', '1', 'class_move_to_group'), 
('class_move_not_root', 'move', 'class', 'Указанный класс не является базовым', '-', '3', 'class_move_to_group'), 
('group_target_not_found', 'move', 'class', 'Целевая группа не найдена', '-', '1', 'class_move_to_group'), 
('group_target_not_include_class_move', 'move', 'class', 'Указанная целевая группа не допускает включение классов', '-', '3', 'class_move_to_group'), 
('class_move_in_group_target', 'move', 'class', 'Указанная целевая группа является текущим расположением класса', '-', '3', 'class_move_to_group'), 
('none', 'delete', 'position', 'Неизвестная ошибка удаления позиции', '-', '3', 'position_del'), 
('conception_not_math', 'move', 'class', 'Концепции целевой группы и переносимого класса не совпадают', '-', '3', 'class_move_to_group'), 
('none', 'move', 'class', 'Неизвестная ошибка переноса базового класса', '-', '3', 'class_move_to_group'), 
('conception_not_found', 'insert', 'global_prop', 'Указанная концепция не найдена', '-', '1', 'global_prop_add_as_class_prop'), 
('prop_pattern_not_found', 'insert', 'global_prop', 'Указанное свойство паттерн не найдено', '-', '3', 'global_prop_add_as_class_prop'), 
('prop_pattern_not_ready', 'insert', 'global_prop', 'Указанное свойство паттерн не готово', '-', '3', 'global_prop_add_as_class_prop'), 
('prop_type_not_found', 'insert', 'global_prop', 'Указаный тип свойства паттерна не найден', '-', '7', 'global_prop_add_as_class_prop'), 
('prop_pattern_not_ready', 'insert', 'global_prop', 'Указанное свойство паттерн не готово', '-', '3', 'global_prop_add_as_pos_temp_prop'), 
('data_prop_not_set', 'insert', 'global_prop', 'В указанном свойстве паттерне, не определена область значений свойства', '-', '3', 'global_prop_add_as_class_prop'), 
('conception_not_found', 'insert', 'global_prop', 'Указанная концепция не найдена', '-', '1', 'global_prop_add_as_pos_temp_prop'), 
('prop_pattern_not_found', 'insert', 'global_prop', 'Указанное свойство паттерн не найдено', '-', '1', 'global_prop_add_as_pos_temp_prop'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_inheriting_override_set'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_prop_inheriting_override_set'), 
('class_upd_not_on', 'update', 'class_prop', 'Активный класс указанного свойства выключен и не допускает внесение изменений', '-', '3', 'class_prop_inheriting_override_set'), 
('eclass_not_found', 'update', 'class', 'Указанный класс не найден', '-', '1', 'class_quantity_show_set'), 
('eclass_not_allow_set_format', 'update', 'class', 'Указанный класс не является абстрактным кассом и не допускает определение формата имен объектов и их параметров', '-', '3', 'class_quantity_show_set'), 
('none', 'update', 'class', 'Незвестная ошибка определения формата имен объектов класса', '-', '3', 'class_quantity_show_set'), 
('class_upd_on_freeze', 'update', 'class_prop', 'Активный класс указанного свойства заблокирован и не допускает внесение изменений', '-', '3', 'class_prop_inheriting_override_set'), 
('class_upd_not_abstraction', 'update', 'class_prop', 'Активный класс указанного свойства не является абстрактным', '-', '3', 'class_prop_inheriting_override_set'), 
('conception_not_match', 'insert', 'global_prop', 'Выбранное свойство паттерн не входит в указанную концепцию', '-', '3', 'global_prop_add_as_class_prop'), 
('class_pattern_include_class_object_val', 'move', 'class', 'Указанный переносимый класс содержит классы, назначенные в качестве объектных свойств', '-', '3', 'class_move_to_class'), 
('class_upd_not_include_child_real_class', 'update', 'class_prop', 'Активный класс указанного свойства не содержит вещественные классы', '-', '3', 'class_prop_inheriting_override_set'), 
('class_prop_override_not_valid', 'update', 'class_prop', 'Указанное свойство класса является объектным и не допускает переопределяемости в вещественных классах', '-', '3', 'class_prop_inheriting_override_set'), 
('on_override_true_not_allowed', 'update', 'class_prop', 'Указанное свойство класса не переопределяемое и не допускает переопределяемости в наследующих вещественных классах', '-', '3', 'class_prop_inheriting_override_set'), 
('none', 'update', 'class_prop', 'Неизвестная ошибка редактирования свойства', '-', '3', 'class_prop_inheriting_override_set'), 
('class_snapshot_not_found', 'rollback', 'class', 'Указанный снимок класса не найден', 'Укажите действительный снимок класса', '7', 'class_rollback'), 
('class_act_parent_not_found', 'rollback', 'class', 'Активное представление родительского класса для указанного снимка не найдено', '-', '7', 'class_rollback'), 
('class_act_parent_unit_conversion_rules_not_found', 'rollback', 'class', 'Правило пересчета активного представления родительского класса не найдено', '-', '7', 'class_rollback'), 
('class_snapshot_unit_conversion_rules_not_found', 'rollback', 'class', 'Правило пересчета указанное в снимке класса не найдено', '-', '7', 'class_rollback'), 
('inherit_class_prop_not_override', 'insert', 'class_prop_enum_val', 'Наследуемое свойство определено как не переопределяемое по значению', '-', '3', 'class_prop_enum_val_set'), 
('group_parent_not_found', 'rollback', 'class', 'Родительская группа указанного снимка класса не найдена', '-', '1', 'class_rollback'), 
('class_act_parent_not_abstraction', 'rollback', 'class', 'Активное представление родительского класса для указанного снимка не является абстрактным', 'Вещественные классы не могут содержать классы', '3', 'class_rollback'), 
('unit_not_match', 'rollback', 'class', 'Единицы измерения указанного снимка и активного представления родительского класса не совпадают', '-', '3', 'class_rollback'), 
('class_not_found', 'insert', 'class_unit_conversion_rule', 'Указанный класс не найден', '-', '1', 'class_unit_conversion_rules_add'), 
('unit_conversion_rule_not_found', 'insert', 'class_unit_conversion_rule', 'Указанное правило пересчета не найдено', '-', '7', 'class_unit_conversion_rules_add'), 
('class_is_abstraction', 'insert', 'class_unit_conversion_rule', 'Указанный класс является абстрактным не может содержать лист правил пересчета', '-', '3', 'class_unit_conversion_rules_add'), 
('conception_not_match', 'insert', 'class_unit_conversion_rule', 'Концепции класса и правила пересчета не совпадают', '-', '3', 'class_unit_conversion_rules_add'), 
('unit_is_undefined', 'insert', 'class_unit_conversion_rule', 'Указанное правило пересчета имеет неопределенную измеряемую величину и не может быть назначено в вещественном классе', '-', '3', 'class_unit_conversion_rules_add'), 
('unit_not_match', 'insert', 'class_unit_conversion_rule', 'Измеряемые величины класса и правила пересчета не совпадают', '-', '3', 'class_unit_conversion_rules_add'), 
('none', 'insert', 'class_unit_conversion_rule', 'Неизвестная ошибка назначеия правила пересчета класса', '-', '3', 'class_unit_conversion_rules_add'), 
('class_prop_not_found', 'delete', 'class_prop_enum_val', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_enum_val_del'), 
('class_carrier_not_found', 'delete', 'class_prop_enum_val', 'Класс-носитель свойства не найден', '-', '1', 'class_prop_enum_val_del'), 
('conception_not_match', 'insert', 'global_prop', 'Выбранное свойство паттерн не входит в указанную концепцию', '-', '3', 'global_prop_add_as_pos_temp_prop'), 
('inherit_class_prop_not_found', 'delete', 'class_prop_enum_val', 'Наследуемое свойство не найдено', '-', '1', 'class_prop_enum_val_del'), 
('class_carrier_not_found', 'delete', 'class_prop_link_val', 'Класс-носитель свойства не найден', '-', '1', 'class_prop_link_val_del'), 
('inherit_class_prop_not_found', 'delete', 'class_prop_object_val', 'Наследуемое свойство не найдено', '-', '1', 'class_prop_object_val_del'), 
('inherit_class_prop_not_found', 'delete', 'class_prop_link_val', 'Наследуемое свойство не найдено', '-', '1', 'class_prop_link_val_del'), 
('class_prop_not_found', 'delete', 'class_prop_link_val', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_link_val_del'), 
('inherit_class_prop_not_override', 'delete', 'class_prop_enum_val', 'Наследуемое свойство определено как не переопределяемое по значению', '-', '3', 'class_prop_enum_val_del'), 
('inherit_class_prop_not_override', 'delete', 'class_prop_link_val', 'Наследуемое свойство определено как не переопределяемое по значению', '-', '3', 'class_prop_link_val_del'), 
('class_prop_not_found', 'delete', 'class_prop_object_val', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_object_val_del'), 
('inherit_class_prop_not_override', 'delete', 'class_prop_object_val', 'Наследуемое свойство определено как не переопределяемое по значению', '-', '1', 'class_prop_object_val_del'), 
('class_edit_not_found', 'update', 'class', 'Указанный класс не найден', '-', '1', 'class_upd'), 
('class_edit_on_freeze', 'update', 'class', 'Указанный класс заблокирован и не допускает модификаций', '-', '3', 'class_upd'), 
('class_parent_not_on', 'update', 'class', 'Родительский класс указанного класса отключен и не допускает модификаций', '-', '3', 'class_upd'), 
('class_edit_is_root_not_converted_to_real', 'update', 'class', 'Указанный класс является базовым классом и не может быть преобразован в вещественный класс', '-', '3', 'class_upd'), 
('class_edit_include_child_class_not_converted_to_real', 'update', 'class', 'Указанный класс содержит вложенные классы и не может быть преобразован в вещественный класс', '-', '3', 'class_upd'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_sort_bottom'), 
('class_edit_include_child_object_not_converted_to_abstraction', 'update', 'class', 'Указанный класс наследован объектами и не может быть преобразован в абстрактный класс', '-', '3', 'class_upd'), 
('class_edit_is_real_not_extensible', 'update', 'class', 'Указанный класс является вещественным и не может быть преобразован в расширяемый класс', '-', '3', 'class_upd'), 
('class_edit_is_root_not_extensible_off', 'update', 'class', 'Указанный класс является базовым классом и не может быть преобразован в нерасширяемый класс', '-', '3', 'class_upd'), 
('class_inheriting_has_extensible_prop_not_extensible_off', 'update', 'class', 'Указанный класс содержит наследующие классы с расширенными свойствами и не может быть преобразован в нерасширяемый класс', '-', '3', 'class_upd'), 
('class_parent_not_extensible_not_extensible_on', 'update', 'class', 'Родительский класс указанного класса является нерасширяемым и не допускает вложения расширяемых классов', '-', '3', 'class_upd'), 
('class_edit_include_child_real_class_not_set_undefined_unit', 'update', 'class', 'Указанный класс содержит вещественные классы и не допускает изменение измеряемой величины на неопределенную', '-', '1', 'class_upd'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_prop_sort_bottom'), 
('class_edit_include_object_not_edit_unit', 'update', 'class', 'Указанный класс содержит объекты и не допускает изменение измеряемой величины', '-', '1', 'class_upd'), 
('class_prop_not_found_in_sort_list', 'update', 'class_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'class_prop_sort_bottom'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_sort_down'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найдено', '-', '1', 'class_prop_sort_down'), 
('class_prop_not_found_in_sort_list', 'update', 'class_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'class_prop_sort_down'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_sort_top'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_prop_sort_top'), 
('class_prop_not_found_in_sort_list', 'update', 'class_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'class_prop_sort_top'), 
('plan_not_found', 'delete', 'plan', 'Указанный план не найден', '-', '1', 'plan_del'), 
('class_parent_not_found', 'update', 'class', 'Родительский класс, указанного класса, не найден', '-', '1', 'class_upd'), 
('unit_not_found', 'update', 'class', 'Указанная  измеряемая величина не найдена', '-', '1', 'class_upd'), 
('class_edit_include_object_property_not_edit_unit', 'update', 'class', 'Указанный класс содержит объектные свойства или классы содержащие объектные свойства и не допускает изменение измеряемой величины', '-', '3', 'class_upd'), 
('class_edit_is_abstraction_not_unit_conversion_rule_set', 'update', 'class', 'Указанный класс является абстрактным и не допускает определение правил пересчета', '-', '3', 'class_upd'), 
('unit_conversion_rule_not_found', 'update', 'class', 'Указанное указанное правило пересчета не найдено', '-', '1', 'class_upd'), 
('class_prop_not_found_in_sort_list', 'update', 'class_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'class_prop_sort_up'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_prop_sort_up'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_sort_up'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_upd_not_found'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_upd_not_found'), 
('class_upd_not_found', 'update', 'class_prop', 'Активный класс указанного свойства не найден', '-', '1', 'class_prop_upd'), 
('class_prop_upd_not_found', 'update', 'class_prop', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_upd'), 
('prop_enum_not_found', 'insert', 'global_prop_area_val', 'Указанное перечисление не найдено', '-', '1', 'global_prop_area_val_add'), 
('class_edit_is_real_not_set_undefined_unit', 'update', 'class', 'Указанный класс является вещественным и не допускает изменение измеряемой величины на неопределенную', '-', '3', 'class_upd'), 
('class_edit_is_used_as_obj_prop_val_not_edit_unit', 'update', 'class', 'Указанный класс содержит классы используемые в качестве значений объектных свойств и не допускает изменение измеряемой величины', '-', '3', 'class_upd'), 
('class_edit_name_not_unique', 'update', 'class', 'Предложенное наименование класса не является уникальным в текущем расположении', '-', '3', 'class_upd'), 
('class_edit_not_edit_unit', 'update', 'class', 'Указанный класс не допускает изменение измеряемой величины', '-', '3', 'class_upd'), 
('none', 'update', 'class', 'Неизвестная ошибка редактирования класса', '-', '3', 'class_upd'), 
('unit_conversion_rule_conception_not_match', 'update', 'class', 'Концепции указанного правила пересчета и редактируемого класса не совпадают', '-', '3', 'class_upd'), 
('unit_conversion_rule_not_include_in_class_edit', 'update', 'class', 'Указанное правило пересчета не входит в список правил редактируемого класса', '-', '3', 'class_upd'), 
('unit_conversion_rule_not_on', 'update', 'class', 'Указанное указанное правило пересчета выключено', '-', '3', 'class_upd'), 
('unit_conversion_rule_unit_not_match', 'update', 'class', 'Измеряемая величина указанного правила пересчета и редактируемого класса не совпадают', '-', '3', 'class_upd'), 
('data_prop_not_set', 'insert', 'global_prop', 'В указанном свойстве паттерне, не определена область значений свойства', '-', '1', 'global_prop_add_as_pos_temp_prop'), 
('none', 'insert', 'global_prop', 'Неизвестная ошибка добавления глобального свойства', '-', '3', 'global_prop_add_as_pos_temp_prop'), 
('none', 'insert', 'global_prop', 'Неизвестная ошибка добавления глобального свойства', '-', '1', 'global_prop_add_as_class_prop'), 
('prop_type_not_found', 'insert', 'global_prop', 'Указаный тип свойства паттерна не найден', '-', '7', 'global_prop_add_as_pos_temp_prop'), 
('none', 'insert', 'global_prop_area_val', 'Неизвестная ошибка установки данных значения глобального свойства', '-', '3', 'global_prop_area_val_add'), 
('entity_not_can_link', 'insert', 'global_prop_area_val', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'global_prop_area_val_add'), 
('entity_not_found', 'insert', 'global_prop_area_val', 'Указанная сущность не найдена', '-', '1', 'global_prop_area_val_add'), 
('class_val_conception_not_match', 'insert', 'global_prop_area_val', 'Концепции глобального свойства и указанного класса значения не совпадают', '-', '3', 'global_prop_area_val_add'), 
('class_val_not_abstraction', 'insert', 'global_prop_area_val', 'Указанное класс значение не является абстрактным', '-', '3', 'global_prop_area_val_add'), 
('global_prop_is_use', 'insert', 'global_prop_area_val', 'Указанное глобальное свойство используется', 'Используемые глобальные свойства не допускают переопределения области значений', '3', 'global_prop_area_val_set'), 
('class_val_not_found', 'insert', 'global_prop_area_val', 'Указанное класс значение не найден', '-', '1', 'global_prop_area_val_add'), 
('enum_val_conception_not_match', 'insert', 'global_prop_area_val', 'Концепции глобального свойства и указанного перечисления не совпадают', '-', '3', 'global_prop_area_val_add'), 
('global_prop_not_found', 'insert', 'global_prop_area_val', 'Указанное глобальное свойство не найдено', '-', '3', 'global_prop_area_val_add'), 
('none', 'delete', 'global_prop_link_pos_temp_prop', 'Неизвестная ошибка исключения свойства шаблона из глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_exclude'), 
('doc_file_change_not_found', 'update', 'doc_file', 'Указанный файл документа не найден', '-', '1', 'doc_file_change'), 
('class_prop_type_not_object', 'insert', 'class_prop_object_val', 'Указанное свойство не является объектным', '-', '3', 'class_prop_object_val_set'), 
('class_prop_inherit_not_found', 'insert', 'class_prop_object_val', 'Наследуемое свойство активного класса родителя не найдено', '-', '1', 'class_prop_object_val_set'), 
('none', 'insert', 'con_prop_data_type', 'Неизвестная ошибка добавления типа данных в концепцию', '-', '1', 'con_prop_data_type_set'), 
('conception_not_found', 'insert', 'doc_category', 'Указанная концепция не найдена', '-', '1', 'doc_category_add'), 
('name_not_unique', 'insert', 'doc_category', 'Указанное наименование категории документов не является уникальным в текущей концепции', '-', '3', 'doc_category_add'), 
('none', 'insert', 'doc_category', 'Неизвестная ошибка создания категории документа', '-', '3', 'doc_category_add'), 
('global_prop_not_found', 'insert', 'global_prop_link_pos_temp_prop', 'Указанное глобальное свойство не найдено', '-', '1', 'global_prop_link_pos_temp_prop_include'), 
('pos_temp_prop_not_found', 'insert', 'global_prop_link_pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_not_match_name', 'insert', 'global_prop_link_pos_temp_prop', 'Наименование указанного свойства шаблона отличается от наименования глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_not_match_desc', 'insert', 'global_prop_link_pos_temp_prop', 'Описание указанного свойства шаблона отличается от описания глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_not_match_prop_type', 'insert', 'global_prop_link_pos_temp_prop', 'Тип указанного свойства шаблона отличается от типа глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_user_not_match_area_val', 'insert', 'global_prop_link_pos_temp_prop', 'Область значений указанного свойства типа пользовательское не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_enum_not_match_area_val', 'insert', 'global_prop_link_pos_temp_prop', 'Область значений указанного свойства типа перечисление не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_object_not_match_area_val', 'insert', 'global_prop_link_pos_temp_prop', 'Область значений указанного свойства типа объектное не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('prop_and_global_prop_link_not_match_area_val', 'insert', 'global_prop_link_pos_temp_prop', 'Область значений указанного свойства типа ссылка не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('none', 'insert', 'global_prop_link_pos_temp_prop', 'Неизвестная ошибка линковки глобального свойства', '-', '3', 'global_prop_link_pos_temp_prop_include'), 
('file_path_not_valid', 'insert', 'doc_file', 'Внутренняя ошибка библиотеки документов, сформированный путь сохранения данных файла недоступен', '-', '3', 'doc_file_add'), 
('file_save_unknown_error', 'insert', 'doc_file', 'Внутренняя ошибка библиотеки документов, неизвестная ошибка добавления файла', '-', '3', 'doc_file_add'), 
('none', 'insert', 'doc_file', 'Неизвестная ошибка добавления файла документа', '-', '3', 'doc_file_add'), 
('file_data_is_empty', 'update', 'doc_file', 'Передан пустой массив файла данных', '-', '3', 'doc_file_add_next'), 
('file_data_above_limit', 'update', 'doc_file', 'Размер переданного файла превышает ограничение библиотеки документов', '-', '3', 'doc_file_add_next'), 
('file_data_is_null', 'update', 'doc_file', 'Передан пустой двоичный массив не содержащий данных файла', '-', '3', 'doc_file_add_next'), 
('ppos_in_recycle_space', 'insert', 'object', 'Целевая позиция находится в корзине', '-', '3', 'object_add'), 
('pos_temp_prop_not_found', 'delete', 'global_prop_link_pos_temp_prop', 'Выбранное свойство шаблона позиций не найдено', '-', '1', 'global_prop_link_pos_temp_prop_exclude'), 
('doc_file_add_not_found', 'update', 'doc_file', 'Указанный файл документа не найден', '-', '1', 'doc_file_add_next'), 
('file_path_not_valid', 'update', 'doc_file', 'Внутренняя ошибка библиотеки документов, сформированный путь сохранения данных файла недоступен', '-', '3', 'doc_file_add_next'), 
('file_save_unknown_error', 'update', 'doc_file', 'Внутренняя ошибка библиотеки документов, неизвестная ошибка сохранения файла', '-', '3', 'doc_file_add_next'), 
('none', 'update', 'doc_file', 'Неизвестная ошибка создания документа', '-', '3', 'doc_file_add_next'), 
('class_real_val_not_found', 'insert', 'class_prop_object_val', 'Указанный класс образец для встраивания не найден', '-', '1', 'class_prop_object_val_set'), 
('conception_group_not_match', 'insert', 'group', 'Концепции копируемой и целевой групп не совпадают', '-', '1', 'group_copy'), 
('conception_not_found', 'insert', 'con_prop_data_type', 'Указанная концепция не найдена', '-', '1', 'con_prop_data_type_set'), 
('prop_data_type_alias_is_empty', 'insert', 'con_prop_data_type', 'Указанный алиас типа данных пустой или не допустим', '-', '1', 'con_prop_data_type_set'), 
('none', 'delete', 'con_prop_data_type', 'Неизвестная ошибка удаления типа данных в концепцию', '-', '1', 'con_prop_data_type_del'), 
('object_in_recycle_space', 'update', 'object', 'Указанный объект удален в корзину концепции', '-', '3', 'object_upd'), 
('con_prop_data_type_is_use', 'delete', 'con_prop_data_type', 'Указанный тип данных используется в выбранной концепции', '-', '3', 'con_prop_data_type_del'), 
('none', 'insert', 'conception', 'Неизвестная ошибка добавления концепции', '-', '3', 'conception_add'), 
('none', 'delete', 'conception', 'Неизвестная ошибка удаления концепции', '-', '3', 'conception_del'), 
('conception_not_found', 'delete', 'conception', 'Указанная концепция не найдена', '-', '1', 'conception_del'), 
('conception_not_found', 'update', 'conception', 'Указанная концепция не найдена', '-', '1', 'conception_restore'), 
('none', 'update', 'conception', 'Неизвестная ошибка восстановления концепции', '-', '3', 'conception_restore'), 
('none', 'update', 'conception', 'Неизвестная ошибка обновления концепции', '-', '3', 'conception_upd'), 
('conception_not_found', 'update', 'conception', 'Указанная концепция не найдена', '-', '1', 'conception_upd'), 
('conception_name_is_not_unique', 'update', 'conception', 'Указанное наименование концепции не является уникальным', '-', '3', 'conception_upd'), 
('conception_name_is_not_unique', 'insert', 'conception', 'Указанное наименование концепции не является уникальным', '-', '3', 'conception_add'), 
('none', 'update', 'object', 'Неизвестная ошибка изменения объекта', '-', '3', 'object_upd'), 
('object_not_found', 'update', 'object', 'Указанный объект не найден', '-', '1', 'object_upd'), 
('object_on_freeze', 'update', 'object', 'Указанный объект заблокирован', '-', '3', 'object_upd'), 
('class_unit_conversion_rules_not_volidation', 'update', 'object', 'Указано недопустимое правило пересчета', 'Указаное правило пересчета не назначено классу объекта или объект не имеет активного представления класса', '3', 'object_upd'), 
('unit_conversion_rule_not_found', 'update', 'object', 'Указанное правило пересчета не найдено', '-', '1', 'object_upd'), 
('rule_quantity_not_fractional_violated', 'update', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'object_upd'), 
('rulel1_class_on_pos_temp_not_allowed', 'insert', 'object', 'Классу объекта не назначено разрешение уровня 1 для шаблона указанной позиции', '-', '3', 'object_add'), 
('global_prop_not_found', 'delete', 'global_prop_area_val', 'Указанное глобальное свойство не найдено', '-', '1', 'global_prop_area_val_del'), 
('none', 'delete', 'global_prop_area_val', 'Неизвестная ошибка удаления глобального свойства', '-', '3', 'global_prop_area_val_del'), 
('none', 'update', 'global_prop', 'Неизвестная ошибка редактирования глобального свойства', '-', '3', 'global_prop_upd'), 
('rulel2_class_on_position_not_allowed', 'insert', 'object', 'Перечень правил вложенности позиции уровня 2 класс на позицию не содержит разрешения для указанного вещественного класса', '-', '3', 'object_add'), 
('prop_type_not_found', 'update', 'global_prop', 'Указаный тип данных свойства не найден', '-', '1', 'global_prop_upd'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '3', 'object_add'), 
('con_prop_data_type_not_found', 'delete', 'con_prop_data_type', 'Указанный тип данных не назначен для выбранной концепции', '-', '7', 'con_prop_data_type_del'), 
('none', 'insert', 'object', 'Неизвестная ошибка добавления объекта', '-', '3', 'object_add'), 
('unit_conversion_rule_not_found', 'insert', 'object', 'Выбранное правило пересчета не найдено', '-', '3', 'object_add'), 
('conception_name_is_empty', 'insert', 'conception', 'Выбранное наименование слишком короткое', '-', '3', 'conception_add'), 
('rule_quantity_on_single_violated', 'update', 'object', 'Указанное количество объектов нарушает требования правила единичного учета', '-', '3', 'object_upd'), 
('object_pattern_not_found', 'copy', 'object', 'Копируемый объект не найден', '-', '3', 'object_copy'), 
('unit_conversion_rule_not_found', 'copy', 'object', 'Правило пересчета копируемого объекта не найдено', '-', '3', 'object_copy'), 
('rule_quantity_round_violated', 'update', 'object', 'Указаное значение колличества объекта превышает заданную точность округления', 'Данные могут быть усечены', '3', 'object_upd'), 
('global_prop_not_found', 'delete', 'global_prop', 'Указанное глобальное свойство не найдено', '-', '1', 'global_prop_del'), 
('class_prop_obj_val_class_not_found', 'update', 'object', 'Данные значения объектного свойства не найдены', 'Возможно повреждение метаданных объекта', '7', 'object_upd'), 
('object_cquantity_out_of_min', 'update', 'object', 'Указаное значение колличества объекта ниже заданного ограничения по минимуму', '-', '3', 'object_upd'), 
('object_cquantity_out_of_max', 'update', 'object', 'Указаное значение колличества объекта выше заданного ограничения по максимуму', '-', '3', 'object_upd'), 
('object_carrier_not_found', 'update', 'object', 'Объект носитель не найден', '-', '1', 'object_upd'), 
('entity_target_not_carrier_object', 'copy', 'object', 'Указанная сущность не допускает размещение объектов', '-', '3', 'object_copy'), 
('entity_instance_not_found', 'copy', 'object', 'Указанный экземпляр сущности не найден', '-', '1', 'object_copy'), 
('conception_not_match', 'copy', 'object', 'Концепции копируемого объекта и сущности носителя не совпадают', '-', '3', 'object_copy'), 
('entity_carrier_in_recycle_space', 'copy', 'object', 'Указанный экземпляр сущности носителя удален в корзину концепции', '-', '3', 'object_copy'), 
('object_pattern_in_recycle_space', 'copy', 'object', 'Копируемый объект вудален в корзину концепции', '-', '3', 'object_copy'), 
('pos_prototype_position_carrier_not_allow_include_object', 'copy', 'object', 'Прототип указанной позиции носителя не допускает размещение объектов', '-', '3', 'object_copy'), 
('rulel1_class_on_pos_temp_not_allowed', 'copy', 'object', 'Классу объекта не назначено разрешение уровня 1 для шаблона указанной позиции', '-', '3', 'object_copy'), 
('rulel2_class_on_position_not_allowed', 'copy', 'object', '"Перечень правил вложенности позиции уровня 2 класс на позицию не содержит разрешения для вещественного класса копируемого"', '-', '3', 'object_copy'), 
('class_object_pattern_not_found', 'copy', 'object', 'Класс копируемого объекта не найден', '-', '7', 'object_copy'), 
('class_upd_not_on', 'update', 'class_prop', 'Активный класс указанного свойства выключен и не допускает внесение изменений', '-', '3', 'class_prop_upd'), 
('class_upd_on_freeze', 'update', 'class_prop', 'Активный класс указанного свойства заблокирован и не допускает внесение изменений', '-', '3', 'class_prop_upd'), 
('prop_is_global_not_upd_global_data', 'update', 'class_prop', 'Указанное свойство класса является глобальным и не доспукает изменения параметров определения: наименование, описание, тип свойства, тип данных', '-', '3', 'class_prop_upd'), 
('prop_type_not_allow_unit', 'update', 'class_prop', 'Указанный тип свойства и измеряемая величина класса носителя не совместимы', '-', '3', 'class_prop_upd'), 
('class_prop_on_inherit_not_valid', 'update', 'class_prop', 'Указанное свойство класса является оределяющим и не имеет источников наследования значения', '-', '3', 'class_prop_upd'), 
('class_prop_name_not_unique', 'update', 'class_prop', 'Указанное наименование свойства не уникально в пределах несущего класса или недопустимо', '-', '3', 'class_prop_upd'), 
('prop_type_not_found', 'update', 'class_prop', 'Указаный тип свойства класса не найден', '-', '7', 'class_prop_upd'), 
('class_prop_override_not_valid', 'update', 'class_prop', 'Объектное свойство вещественного класса не может быть переопределяемым', '-', '3', 'class_prop_upd'), 
('none', 'update', 'class_prop', 'Неизвестная ошибка редактирования определяющего свойства класса', '-', '3', 'class_prop_upd'), 
('class_prop_upd_not_allowed', 'update', 'class_prop', 'Предложенные изменения свойства класса не допустимы для наследованного свойства (типа свойства, типа данных свойства, наименования или описания', '-', '3', 'class_prop_upd'), 
('class_prop_inherited_not_found', 'update', 'class_prop', 'Наследуемое свойство редактируемого свойства класса не найдено', '-', '3', 'class_prop_upd'), 
('none', 'insert', 'object', 'Неизвестная ошибка добавления объекта', '-', '3', 'object_add_by_single_unit'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Выбранное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'object_add'), 
('pclass_not_found', 'insert', 'object', 'Указанный вещественный класс не найден', '-', '3', 'object_add_by_single_unit'), 
('pclass_not_real', 'insert', 'object', 'Указанный класс не является вещественным', '-', '3', 'object_add_by_single_unit'), 
('pclass_not_on', 'insert', 'object', 'Указанный класс выключен', 'Выключенный классы не могут наследоваться новыми объектами', '3', 'object_add_by_single_unit'), 
('pclass_in_recycle_space', 'insert', 'object', 'Указанный вещественный класс удален в корзину', '-', '3', 'object_add_by_single_unit'), 
('none', 'delete', 'global_prop', 'Неизвестная ошибка удаления глобального свойства', '-', '3', 'global_prop_del'), 
('global_prop_not_found', 'delete', 'global_prop_link_class_prop', 'Указанное глобальное свойство не найдено', '-', '1', 'global_prop_link_class_prop_exclude'), 
('file_data_is_empty', 'insert', 'doc_file', 'Передан пустой массив файла данных', '-', '3', 'doc_file_add'), 
('file_data_above_limit', 'insert', 'doc_file', 'Размер переданного файла превышает ограничение библиотеки документов', '-', '3', 'doc_file_add'), 
('conception_not_found', 'insert', 'group', 'Указанная концепция не найдена', '-', '1', 'group_add'), 
('plan_name_is_empty', 'insert', 'plan', 'Наименование не может быть менее минимального количества символов', '-', '3', 'plan_add'), 
('global_prop_is_use', 'delete', 'global_prop', 'Указанное глобальное свойство используется', 'Используемые глобальные свойства не допускают удаления', '3', 'global_prop_del'), 
('group_name_not_unique', 'insert', 'group', 'Указанное наименование группы не является уникальным в пределах выбранного расположения', '-', '3', 'group_add'), 
('group_parent_not_found', 'insert', 'group', 'Указанная родительская группа не найдена', '-', '1', 'group_add'), 
('group_parent_on_class', 'insert', 'group', 'Указанная родительская группа не допускает размещения групп', '-', '3', 'group_add'), 
('group_parent_in_recycle_space', 'insert', 'group', 'Указанная родительская группа удалена в корзину', '-', '3', 'group_add'), 
('conception_not_match', 'insert', 'group', 'Указанная концепция не совпадает с концепцией родительской группы', '-', '3', 'group_add'), 
('none', 'insert', 'group', 'Неизвестная ошибка добавления группы', '-', '3', 'group_add'), 
('none', 'insert', 'group', 'Неизвестная ошибка копирования группы', '-', '1', 'group_copy'), 
('group_path_not_correct', 'insert', 'group', 'Целевая группа размещена в копируемой группе', 'Цыклические ссылки не допускаются', '1', 'group_copy'), 
('doc_file_data_found_in_document', 'update', 'doc_file', 'Загружаемый файл найден в пакете документов', '-', '3', 'doc_file_change'), 
('conception_actcatalog_not_set', 'update', 'doc_file', 'В текущей концепции не определен активный каталог библиотеки документов', '-', '3', 'doc_file_change'), 
('file_data_is_null', 'update', 'doc_file', 'Передан пустой двоичный массив не содержащий данных файла', '-', '3', 'doc_file_change'), 
('file_path_not_valid', 'update', 'doc_file', 'Внутренняя ошибка библиотеки документов, сформированный путь сохранения данных файла недоступен', '-', '3', 'doc_file_change'), 
('file_save_unknown_error', 'update', 'doc_file', 'Внутренняя ошибка библиотеки документов, неизвестная ошибка сохранения файла', '-', '3', 'doc_file_change'), 
('none', 'update', 'doc_file', 'Неизвестная ошибка создания документа', '-', '3', 'doc_file_change'), 
('prop_carrier_type_not_object', 'copy', 'object', 'Указанное целевое свойство не является объектным', '-', '3', 'object_copy'), 
('pos_temp_prop_obj_val_not_found', 'copy', 'object', 'Данные значения объектного свойства позиции не найдены', '-', '3', 'object_copy'), 
('pos_temp_prop_obj_val_value_not_set', 'copy', 'object', 'Данные значения объектного свойства свойства позиции не установлены', '-', '3', 'object_copy'), 
('object_carrier_include_branch_object_pattern', 'copy', 'object', 'Копируемый объект содержит указанный объект носитель', '-', '3', 'object_copy'), 
('class_prop_obj_val_value_not_set', 'copy', 'object', 'Данные значения объектного свойства объекта носителя не установлены', '-', '3', 'object_copy'), 
('class_val_not_found', 'copy', 'object', 'Класс значение объектного свойства не найден', '-', '3', 'object_copy'), 
('none', 'delete', 'doc_file', 'Неизвестная ошибка создания документа', '-', '3', 'doc_file_del'), 
('class_prop_obj_val_not_found', 'copy', 'object', 'Данные значения объектного свойства объекта носителя не найдены', '-', '7', 'object_copy'), 
('doc_file_not_found', 'update', 'doc_file', 'Указанный файл документа не найден', '-', '1', 'doc_file_upd'), 
('none', 'update', 'doc_file', 'Неизвестная ошибка создания документа', '-', '3', 'doc_file_upd'), 
('document_not_found', 'insert', 'doc_link', 'Указанный документ не найден', '-', '1', 'doc_link_add'), 
('doc_link_already_set', 'insert', 'doc_link', 'Документ имеет установленную ссылку на указанную сущность БД', '-', '3', 'doc_link_add'), 
('entity_not_found', 'insert', 'doc_link', 'Указанная ссылочная сущность не найдена', '-', '1', 'doc_link_add'), 
('entity_not_can_link', 'insert', 'doc_link', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'doc_link_add'), 
('entity_instance_not_found', 'insert', 'doc_link', 'Указанный экземпляр ссылочной сущности не найден', '-', '1', 'doc_link_add'), 
('conception_not_match', 'insert', 'doc_link', 'Концепция документа и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'doc_link_add'), 
('group_name_is_empty', 'insert', 'group', 'Выбранное наименование слишком короткое', '-', '3', 'group_add'), 
('entity_instance_id_not_valid', 'insert', 'doc_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'doc_link_add'), 
('none', 'insert', 'doc_link', 'Неизвестная ошибка присвоения значения свойства ссылки', '-', '3', 'doc_link_add'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылки на документ', '-', '3', 'doc_link_del'), 
('document_not_found', 'delete', 'doc_link', 'Ссылочный документ не найден', '-', '1', 'doc_link_del'), 
('document_not_found', 'delete', 'doc_link', 'Ссылочный документ не найден', '-', '1', 'doc_link_del_all'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылки на документ', '-', '3', 'doc_link_del_all'), 
('class_prop_obj_val_not_found', 'insert', 'object', 'Данные значения объектного свойства не определены в снимке класса объекта носителя', '-', '3', 'object_prop_object_val_add'), 
('class_prop_obj_val_value_not_set', 'insert', 'object', 'В данных значения объектного свойства не установлен класс-значение', '-', '3', 'object_prop_object_val_add'), 
('class_prop_obj_val_value_not_set', 'insert', 'object', 'В данных значения объектного свойства не установлен класс-значение', '-', '3', 'object_prop_object_val_add_new'), 
('class_val_not_found', 'insert', 'object', 'Активное представление класса-значения не найдено', '-', '1', 'object_prop_object_val_add'), 
('class_val_not_found', 'insert', 'object', 'Активное представление класса-значения не найдено', '-', '1', 'object_prop_object_val_add_new'), 
('object_embed_class_snapshot_not_found', 'insert', 'object', 'Снимок класса встраиваемого объекта не найден', '-', '7', 'object_prop_object_val_add'), 
('object_embed_class_not_include_branch_class_val', 'insert', 'object', 'Класс встраиваемого объекта не наследует от класса значения объектного свойства', '-', '3', 'object_prop_object_val_add'), 
('conversion_rule_not_found', 'insert', 'object', 'Правило пересчета встраиваемого объекта не найдено', '-', '1', 'object_prop_object_val_add'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '1', 'object_prop_object_val_add'), 
('class_prop_not_found', 'delete', 'global_prop_link_class_prop', 'Указанное свойство класса не найдено', '-', '1', 'global_prop_link_class_prop_exclude'), 
('embed_object_bquantity_limit_violated', 'insert', 'object', 'Указаное количество встраиваемого объекта превышает количество указанного объекта или является отрицательной величиной', '-', '1', 'object_prop_object_val_add'), 
('emembed_object_quantity_above_max', 'insert', 'object', 'Общее количество встраиваемых объектов превышает установленный лимит на встраивание', '-', '1', 'object_prop_object_val_add'), 
('none', 'insert', 'object', 'Неизвестная ошибка встраивания объекта', '-', '1', 'object_prop_object_val_add'), 
('none', 'insert', 'object', 'Неизвестная ошибка встраивания объекта', '-', '3', 'object_prop_object_val_add_new'), 
('class_real_not_found', 'insert', 'object', 'Активное представление указанного вещественного класса не найдено', '-', '3', 'object_prop_object_val_add_new'), 
('class_not_real', 'insert', 'object', 'Указанный класс не является вещественным', '-', '3', 'object_prop_object_val_add_new'), 
('none', 'delete', 'global_prop_link_class_prop', 'Неизвестная ошибка исключения свойства класса из глобального свойства', '-', '3', 'global_prop_link_class_prop_exclude'), 
('pclass_not_on', 'insert', 'object', 'Указанный класс выключен', '-', '3', 'object_prop_object_val_add_new'), 
('class_real_in_recycle_space', 'insert', 'object', 'Активное представление указанного вещественного класса удалено в корзину', '-', '3', 'object_prop_object_val_add_new'), 
('conception_class_real_and_object_carrier_not_match', 'insert', 'object', 'Концепции объекта носителя и вещественного класса встраиваемого объекта не совпадают', '-', '3', 'object_prop_object_val_add_new'), 
('class_real_not_include_branch_class_val', 'insert', 'object', 'Указанный вещественный класс не входит в ветвь класса значения объектного свойства', '-', '3', 'object_prop_object_val_add_new'), 
('class_real_include_noready_class_prop', 'insert', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'object_prop_object_val_add_new'), 
('class_real_noready_name_format', 'insert', 'object', 'Шаблон наименования объектов выбранного вещественного класса не готов к созданию объектов', '-', '3', 'object_prop_object_val_add_new'), 
('conversion_rule_not_assigned', 'insert', 'object', 'Указаное правило пересчета не допустимо в выбранном вещественном классе', '-', '3', 'object_prop_object_val_add_new'), 
('conversion_rule_conception_not_math', 'insert', 'object', 'Концепции объекта носителя и указаного правила пересчета не совпадают', '-', '3', 'object_prop_object_val_add_new'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '3', 'object_prop_object_val_add_new'), 
('emembed_object_quantity_above_max', 'insert', 'object', 'Общее количество встраиваемых объектов превышает установленный лимит на встраивание', '-', '3', 'object_prop_object_val_add_new'), 
('rule_quantity_violated', 'insert', 'object', 'Указанное количество объектов меньше нуля', '-', '3', 'object_prop_object_val_add_new'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '1', 'object_prop_object_val_add'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'object_prop_object_val_add_new'), 
('conversion_rule_not_found', 'insert', 'object', 'Указаное правило пересчета не найдено', '-', '1', 'object_prop_object_val_add_new'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указаное значение колличества объекта превышает заданную точность округления', '-', '1', 'object_prop_object_val_add'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указаное значение колличества объекта превышает заданную точность округления', '-', '3', 'object_prop_object_val_add_new'), 
('doc_category_not_found', 'delete', 'doc_category', 'Указанная категория документов не найдено', '-', '1', 'doc_category_del'), 
('position_carrier_not_found', 'insert', 'object', 'Указанная целевая позиция не найдена', '-', '3', 'position_prop_object_val_add'), 
('position_carrier_not_found', 'insert', 'object', 'Указанная целевая позиция не найдена', '-', '3', 'position_prop_object_val_add_new'), 
('parent_position_in_recycle_space', 'insert', 'object', 'Целевая позиция удалена в корзину', '-', '3', 'position_prop_object_val_add'), 
('parent_position_in_recycle_space', 'insert', 'object', 'Целевая позиция удалена в корзину', '-', '3', 'position_prop_object_val_add_new'), 
('pos_temp_prop_carrier_not_found', 'insert', 'object', 'Указанное свойство целевой позиции не найдено', '-', '3', 'position_prop_object_val_add'), 
('pos_temp_prop_carrier_not_found', 'insert', 'object', 'Указанное свойство целевой позиции не найдено', '-', '3', 'position_prop_object_val_add_new'), 
('pos_temp_prop_carrier_type_not_object', 'insert', 'object', 'Указанное свойство целевой позиции не является объектным', '-', '3', 'position_prop_object_val_add_new'), 
('pos_temp_prop_carrier_type_not_object', 'insert', 'object', 'Указанное свойство целевой позиции не является объектным', '-', '3', 'position_prop_object_val_add'), 
('object_val_not_found', 'insert', 'object', 'Указанный объект значение свойства не найден', '-', '1', 'position_prop_object_val_add'), 
('object_conception_not_math', 'insert', 'object', 'Концепции объекта носителя и объекта значения не совпадают', '-', '1', 'position_prop_object_val_add'), 
('pos_temp_prop_obj_val_not_found', 'insert', 'object', 'Данные значения объектного свойства позиции не определены', '-', '1', 'position_prop_object_val_add'), 
('pos_temp_prop_obj_val_value_not_set', 'insert', 'object', 'Данные значения объектного свойства не установлены', '-', '1', 'position_prop_object_val_add'), 
('object_embed_class_not_include_branch_class_val', 'insert', 'object', 'Класс встраиваемого объекта не входит в ветвь класса значения объектного свойства', '-', '3', 'position_prop_object_val_add'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '3', 'position_prop_object_val_add'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила к порядку округления', '-', '3', 'position_prop_object_val_add'), 
('embed_object_bquantity_limit_violated', 'insert', 'object', 'Указаное количество встраиваемого объекта превышает количество указанного объекта или является отрицательной величиной', '-', '3', 'position_prop_object_val_add'), 
('emembed_object_quantity_above_max', 'insert', 'object', 'Общее количество встраиваемых объектов превышает установленный лимит на встраивание', '-', '3', 'position_prop_object_val_add'), 
('none', 'insert', 'object', 'Неизвестная ошибка встраивания объекта', '-', '3', 'position_prop_object_val_add'), 
('none', 'insert', 'object', 'Неизвестная ошибка встраивания объекта', '-', '3', 'position_prop_object_val_add_new'), 
('doc_category_is_use', 'delete', 'doc_category', 'Указанная категория документов используется, удаление недоступно', '-', '3', 'doc_category_del'), 
('pos_temp_prop_obj_val_not_found', 'insert', 'object', 'Данные значения объектного свойствапозиции не определены', '-', '3', 'position_prop_object_val_add_new'), 
('pos_temp_prop_obj_val_value_not_set', 'insert', 'object', 'Данные значения объектного свойствапозиции не установлены', '-', '3', 'position_prop_object_val_add_new'), 
('conversion_rule_not_found', 'insert', 'object', 'Указаное правило пересчета не найдено', '-', '1', 'position_prop_object_val_add'), 
('class_not_real', 'insert', 'object', 'Указанный класс не является вещественным', '-', '3', 'position_prop_object_val_add_new'), 
('pclass_not_on', 'insert', 'object', 'Указанный класс выключен и не допускает создание объектов', '-', '3', 'position_prop_object_val_add_new'), 
('class_real_in_recycle_space', 'insert', 'object', 'Активное представление указанного вещественного класса находится в корзине концепции', '-', '3', 'position_prop_object_val_add_new'), 
('class_val_not_found', 'insert', 'object', 'Активное представление класса-значения не найдено', '-', '1', 'position_prop_object_val_add'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'position_prop_object_val_add'), 
('class_real_not_found', 'insert', 'object', 'Активное представление указанного вещественного класса не найдено', '-', '3', 'position_prop_object_val_add_new'), 
('object_embed_class_snapshot_not_found', 'insert', 'object', 'Снимок класса встраиваемого объекта не найден', '-', '1', 'position_prop_object_val_add'), 
('class_prop_user_val_out_of_max', 'insert', 'class_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('class_prop_user_val_out_of_min', 'insert', 'class_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('conception_class_real_and_position_carrier_not_match', 'insert', 'object', 'Концепции объекта носителя и вещественного класса встраиваемого объекта не совпадают', '-', '3', 'position_prop_object_val_add_new'), 
('class_real_not_include_branch_class_val', 'insert', 'object', 'Указанный вещественный класс не входит в ветвь класса значения объектного свойства', '-', '3', 'position_prop_object_val_add_new'), 
('class_real_include_noready_class_prop', 'insert', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'position_prop_object_val_add_new'), 
('class_real_noready_name_format', 'insert', 'object', 'Шаблон наименования объектов выбранного вещественного класса не готов к созданию объектов', '-', '3', 'position_prop_object_val_add_new'), 
('conversion_rule_not_assigned', 'insert', 'object', 'Указаное правило пересчета не допустимо в выбранном вещественном классе', '-', '3', 'position_prop_object_val_add_new'), 
('conversion_rule_conception_not_math', 'insert', 'object', 'Концепции объекта носителя и указаного правила пересчета не совпадают', '-', '3', 'position_prop_object_val_add_new'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '3', 'position_prop_object_val_add_new'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила к порядку округления', '-', '3', 'position_prop_object_val_add_new'), 
('rule_quantity_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила к количеству объектов', '-', '3', 'position_prop_object_val_add_new'), 
('emembed_object_quantity_above_max', 'insert', 'object', 'Общее количество встраиваемых объектов превышает установленный лимит на встраивание', '-', '3', 'position_prop_object_val_add_new'), 
('class_val_not_found', 'insert', 'object', 'Активное представление класса-значения не найдено', '-', '3', 'position_prop_object_val_add_new'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указаное правило пересчета не допускает дробных значений колличества объекта', '-', '3', 'position_prop_object_val_add_new'), 
('none', 'delete', 'doc_category', 'Неизвестная ошибка удаления категории документов', '-', '3', 'doc_category_del'), 
('dobject_not_found', 'delete', 'object', 'Указанный объект не найден', '-', '1', 'object_del'), 
('dobject_on_freeze', 'delete', 'object', 'Указанный объект заблокирован', '-', '3', 'object_del'), 
('none', 'delete', 'object', 'Неизвестная ошибка удаления объекта', '-', '3', 'object_del'), 
('pos_recycle_not_found', 'delete', 'object', 'Корзина концепции не найдена', 'Возможно, концепция повреждена', '1', 'object_del'), 
('none', 'delete', 'object', 'Неизвестная ошибка удаления объекта', '-', '3', 'object_destroy'), 
('dobject_not_found', 'delete', 'object', 'Указанный объект не найден', '-', '3', 'object_destroy'), 
('dobject_on_freeze', 'delete', 'object', 'Указанный объект заблокирован', '-', '3', 'object_destroy'), 
('object_cast_not_found', 'cast', 'object', 'Указанный объект не найден', '-', '1', 'object_cast'), 
('object_cast_is_freeze', 'cast', 'object', 'Указанный объект заблокирован', '-', '3', 'object_cast'), 
('object_cast_in_recycle_space', 'cast', 'object', 'Указанный объект удален в корзину', '-', '3', 'object_cast'), 
('class_current_not_found', 'cast', 'object', 'Снимок класса редактируемого объекта не найден', '-', '7', 'object_cast'), 
('class_real_include_noready_class_prop', 'cast', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'object_cast'), 
('class_real_noready_name_format', 'cast', 'object', 'Шаблон наименования объектов выбранного вещественного класса не готов к созданию объектов', '-', '3', 'object_cast'), 
('object_cast_contains_extra_internal_objects', 'cast', 'object', 'Указаный объект имеет объектные свойства, содержашие встроенные объекты не допустимые в целевом снимке класса', '-', '3', 'object_cast'), 
('none', 'cast', 'object', 'Неизвестная ошибка приведения объекта', '-', '3', 'object_cast'), 
('eclass_prop_not_found', 'delete', 'class_prop_user_val', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_user_val_del'), 
('eclass_prop_type_not_user', 'delete', 'class_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'class_prop_user_val_del'), 
('inherit_class_prop_not_found', 'delete', 'class_prop_user_val', 'Наследуемое свойство не найдено', 'Возможно повреждение метаданных концепции', '7', 'class_prop_user_val_del'), 
('conversion_rule_not_found', 'insert', 'object', 'Указаное правило пересчета не найдено', '-', '1', 'position_prop_object_val_add_new'), 
('inherit_class_prop_not_override', 'delete', 'class_prop_user_val', 'Указанное свойство объявлено как не переопределяемое по значению', '-', '3', 'class_prop_user_val_del'), 
('none', 'delete', 'class_prop_user_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'class_prop_user_val_del'), 
('eclass_carrier_not_found', 'delete', 'class_prop_user_val', 'Указанный класс носитель свойства не найден', 'Возможно повреждение метаданных концепции', '1', 'class_prop_user_val_del'), 
('inherit_class_prop_not_found', 'insert', 'class_prop_user_val', 'Наследуемое свойство указанного свойства не найдено', 'Возможно повреждение метаданных концепции', '1', 'class_prop_user_big_val_set'), 
('inherit_class_prop_not_override', 'insert', 'class_prop_user_val', 'Наследуемое свойство не является переопределяемым по значеию', 'Непереопределяемое наследуемое свойство не допускает изменение значения в наследующих классах', '3', 'class_prop_user_big_val_set'), 
('class_prop_val_spec_not_found', 'insert', 'class_prop_user_val', 'Спецификаторы значения указанного свойства не найдены', 'Возможно повреждение метаданных концепции', '7', 'class_prop_user_big_val_set'), 
('global_prop_not_found', 'insert', 'global_prop_link_class_prop', 'Указанное глобальное свойство не найдено', '-', '1', 'global_prop_link_class_prop_include'), 
('class_prop_user_val_not_found', 'insert', 'class_prop_user_val', 'Данные значения пользовательского свойства не найдены', '-', '7', 'class_prop_user_big_val_set'), 
('max_val_spec_state_cannot_change', 'insert', 'class_prop_user_val', 'Ограничение максимального значения  не может изменятся в наледующем свойстве', '-', '3', 'class_prop_user_big_val_set'), 
('min_val_spec_state_cannot_change', 'insert', 'class_prop_user_val', 'Ограничение минимального значения  не может изменятся в наледующем свойстве', '-', '3', 'class_prop_user_big_val_set'), 
('max_val_spec_state_out_of_min', 'insert', 'class_prop_user_val', 'Ограничение максимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('max_val_spec_state_out_of_max', 'insert', 'class_prop_user_val', 'Ограничение максимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('min_val_spec_state_out_of_min', 'insert', 'class_prop_user_val', 'Ограничение минимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('min_val_spec_state_out_of_max', 'insert', 'class_prop_user_val', 'Ограничение минимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('class_prop_user_val_out_of_min', 'insert', 'class_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('class_prop_user_val_out_of_max', 'insert', 'class_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'class_prop_user_big_val_set'), 
('none', 'insert', 'class_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'class_prop_user_big_val_set'), 
('none', 'insert', 'class_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'class_prop_user_small_val_set'), 
('eclass_prop_not_found', 'insert', 'class_prop_user_val', 'Указанное свойство класса не найдено', '-', '3', 'class_prop_user_small_val_set'), 
('eclass_prop_not_prop_user', 'insert', 'class_prop_user_val', 'Указанное свойство класса не является пользовательским', '-', '3', 'class_prop_user_small_val_set'), 
('class_prop_val_spec_not_found', 'insert', 'class_prop_user_val', 'Спецификаторы значения указанного свойства не найдены', '-', '3', 'class_prop_user_small_val_set'), 
('class_prop_user_val_not_found', 'insert', 'class_prop_user_val', 'Данные значения пользовательского свойства не найдены', '-', '3', 'class_prop_user_small_val_set'), 
('min_val_spec_state_cannot_change', 'insert', 'class_prop_user_val', 'Ограничение минимального значения  не может изменятся в наледующем свойстве', '-', '3', 'class_prop_user_small_val_set'), 
('max_val_spec_state_cannot_change', 'insert', 'class_prop_user_val', 'Ограничение максимального значения  не может изменятся в наледующем свойстве', '-', '3', 'class_prop_user_small_val_set'), 
('round_val_spec_state_cannot_change', 'insert', 'class_prop_user_val', 'Точность округления значения  не может изменятся в наледующем свойстве', '-', '3', 'class_prop_user_small_val_set'), 
('max_val_spec_state_out_of_min', 'insert', 'class_prop_user_val', 'Ограничение максимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('max_val_spec_state_out_of_max', 'insert', 'class_prop_user_val', 'Ограничение максимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('min_val_spec_state_out_of_min', 'insert', 'class_prop_user_val', 'Ограничение минимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('min_val_spec_state_out_of_max', 'insert', 'class_prop_user_val', 'Ограничение минимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('class_prop_not_found', 'insert', 'class_prop_link_val', 'Указанное свойство класса не найдено', '-', '7', 'class_prop_link_val_set'), 
('class_prop_not_link_type', 'insert', 'class_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'class_prop_link_val_set'), 
('conception_not_match', 'insert', 'class_prop_link_val', 'Концепция редактируемого свойства и указанного экземпляра сущности не совпадают', '-', '3', 'class_prop_link_val_set'), 
('entity_instance_is_circular_link', 'insert', 'class_prop_link_val', 'Указанный экземпляр сущности является носителем редактирумого свойства и образует циклическую ссылку', '-', '3', 'class_prop_link_val_set'), 
('entity_instance_not_found', 'insert', 'class_prop_link_val', 'Указанный экземпляр сущности не найден', '-', '1', 'class_prop_link_val_set'), 
('entity_not_can_link', 'insert', 'class_prop_link_val', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'class_prop_link_val_set'), 
('entity_not_found', 'insert', 'class_prop_link_val', 'Указанная сущность не найдена', '-', '1', 'class_prop_link_val_set'), 
('entity_not_match', 'insert', 'class_prop_link_val', 'Сущности редактируемого и наследуемого свойств не совпадают', '-', '3', 'class_prop_link_val_set'), 
('inherit_class_prop_not_found', 'insert', 'class_prop_link_val', 'Наследуемое свойство не определено', '-', '3', 'class_prop_link_val_set'), 
('inherit_class_prop_not_override', 'insert', 'class_prop_link_val', 'Наследуемое свойство определено как не переопределяемое по значению', '-', '3', 'class_prop_link_val_set'), 
('inherit_class_prop_val_not_set', 'insert', 'class_prop_link_val', 'Данные значения не определены в наследуемом свойстве', '-', '3', 'class_prop_link_val_set'), 
('none', 'insert', 'class_prop_link_val', 'Неизвестная ошибка присвоения значения свойства ссылки', '-', '3', 'class_prop_link_val_set'), 
('class_prop_not_enum_type', 'insert', 'class_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'class_prop_enum_val_set'), 
('class_prop_not_found', 'insert', 'class_prop_enum_val', 'Указанное свойство класса не найдено', '-', '7', 'class_prop_enum_val_set'), 
('conception_not_match', 'insert', 'class_prop_enum_val', 'Концепции указанного перечисления и редактируемого свойства не совпадают', '-', '3', 'class_prop_enum_val_set'), 
('inherit_class_prop_not_found', 'insert', 'class_prop_enum_val', 'Наследуемое свойство не определено', '-', '3', 'class_prop_enum_val_set'), 
('inherit_class_prop_val_not_set', 'insert', 'class_prop_enum_val', 'Перечисление не назначено в наследуемом свойстве', '-', '3', 'class_prop_enum_val_set'), 
('none', 'insert', 'class_prop_enum_val', 'Неизвестная ошибка присвоения значения свойства перечисления', '-', '3', 'class_prop_enum_val_set'), 
('prop_enum_not_found', 'insert', 'class_prop_enum_val', 'Указанное перечисление не найдено', '-', '1', 'class_prop_enum_val_set'), 
('prop_enum_not_match', 'insert', 'class_prop_enum_val', 'Перечисления редактируемого и наследуемого свойств не совпадают', '-', '3', 'class_prop_enum_val_set'), 
('prop_enum_use_area_out_of_range', 'insert', 'class_prop_enum_val', 'Область применения перечисления не охватывает объекты и классы', '-', '3', 'class_prop_enum_val_set'), 
('prop_enum_val_not_found', 'insert', 'class_prop_enum_val', 'Указанный элемент перечисления не найден', '-', '1', 'class_prop_enum_val_set'), 
('prop_enum_val_out_of_range', 'insert', 'class_prop_enum_val', 'Указанный элемент перечисления не входит в назначенное перечисление', '-', '3', 'class_prop_enum_val_set'), 
('class_prop_inherit_not_override', 'insert', 'class_prop_object_val', 'Наследуемое свойство активного класса не является переопределяемым', '-', '3', 'class_prop_object_val_set'), 
('class_prop_object_val', 'insert', 'class_prop_object_val', 'Указанный класс значение свойства выключен и не допускает использования', '-', '3', 'class_prop_object_val_set'), 
('class_real_val_include_noready_class_prop', 'insert', 'class_prop_object_val', 'Указанный класс образец содержит свойства не готовые к созданию объектов', '-', '3', 'class_prop_object_val_set'), 
('class_real_val_noready_name_format', 'insert', 'class_prop_object_val', 'Указанный класс образец содержит формат имени не готовый к созданию объектов', '-', '3', 'class_prop_object_val_set'), 
('class_real_val_not_include_branch_class_val', 'insert', 'class_prop_object_val', 'Указанный класс образец не входит в ветвь класса значения свойства', '-', '3', 'class_prop_object_val_set'), 
('class_real_val_not_on', 'insert', 'class_prop_object_val', 'Указанный класс образец отключен', '-', '3', 'class_prop_object_val_set'), 
('class_real_val_not_real', 'insert', 'class_prop_object_val', 'Указанный класс образец не является вещественным', '-', '3', 'class_prop_object_val_set'), 
('class_val_conception_not_match', 'insert', 'class_prop_object_val', 'Концепции свойства и класса значения не совпадают', '-', '3', 'class_prop_object_val_set'), 
('class_val_in_recycle_space', 'insert', 'class_prop_object_val', 'Указанный класс значение свойства принадлежит пространству корзины концепции', '-', '3', 'class_prop_object_val_set'), 
('class_val_include_branch_class_carrier', 'insert', 'class_prop_object_val', 'Класс значение свойства входит в ветвь класса носителя свойства', '-', '3', 'class_prop_object_val_set'), 
('class_val_not_abstraction', 'insert', 'class_prop_object_val', 'Указанный класс значениt свойства не является абстрактным', '-', '3', 'class_prop_object_val_set'), 
('class_val_not_found', 'insert', 'class_prop_object_val', 'Указанный класс значение свойства не найдено', '-', '1', 'class_prop_object_val_set'), 
('embed_limit_max_not_valid', 'insert', 'class_prop_object_val', 'Недопустимое значение ограничения максимального количества встраиваемых объектов в режиме встраивания по максимуму', '-', '3', 'class_prop_object_val_set'), 
('embed_limit_min_not_valid', 'insert', 'class_prop_object_val', 'Недопустимое значение ограничения минимального количества встраиваемых объектов в режиме встраивания по минимуму', '-', '3', 'class_prop_object_val_set'), 
('embed_mode_not_valid', 'insert', 'class_prop_object_val', 'Недопустимое значение режима встраивания объектов', '-', '3', 'class_prop_object_val_set'), 
('inherited_object_data_class_val_not_set', 'insert', 'class_prop_object_val', 'Данные значения наследуемого свойства класса не установлены', '-', '3', 'class_prop_object_val_set'), 
('inherited_object_data_not_set', 'insert', 'class_prop_object_val', 'Данные значения наследуемого свойства класса не определены', '-', '3', 'class_prop_object_val_set'), 
('none', 'insert', 'class_prop_object_val', 'Неизвестная ошибка установки данных значения объектного свойства', '-', '3', 'class_prop_object_val_set'), 
('rule_quantity_not_fractional_violated', 'insert', 'class_prop_object_val', 'Указанное количество объекта нарушает требования правила запрета дробной части', '-', '3', 'class_prop_object_val_set'), 
('rule_quantity_on_single_embed_single_violated', 'insert', 'class_prop_object_val', 'Режим встраивания одним объектом с указанным количеством нарушает требования правила единичного учета', '-', '3', 'class_prop_object_val_set'), 
('rule_quantity_on_single_violated', 'insert', 'class_prop_object_val', 'Сопоставленное по MIN/MAX количество объекта нарушает требования правила единичного учета', '-', '3', 'class_prop_object_val_set'), 
('unit_conversion_rule_not_found', 'insert', 'class_prop_object_val', 'Указанное правило пересчета не найдено', '-', '1', 'class_prop_object_val_set'), 
('class_prop_not_found', 'insert', 'global_prop_link_class_prop', 'Указанное свойство класса не найдено', '-', '1', 'global_prop_link_class_prop_include'), 
('class_prop_not_definition', 'insert', 'global_prop_link_class_prop', 'Указанное свойство класса не является определяющим', '-', '3', 'global_prop_link_class_prop_include'), 
('count_plans_exceeded_limit', 'insert', 'plan', 'Количество вложенных планов превысило общее ограничение родительского плана', '-', '3', 'plan_add'), 
('global_prop_different_names', 'insert', 'global_prop_link_class_prop', 'Указанное свойство класса содержит различающиеся наименования в коллекции снимков класса', '-', '3', 'global_prop_link_class_prop_include'), 
('global_prop_different_descs', 'insert', 'global_prop_link_class_prop', 'Указанное свойство класса содержит различающиеся описания свойства в коллекции снимков класса', '-', '3', 'global_prop_link_class_prop_include'), 
('global_prop_different_prop_types', 'insert', 'global_prop_link_class_prop', 'Указанное свойство класса содержит различающиеся типы данных свойства в коллекции снимков класса', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_not_match_name', 'insert', 'global_prop_link_class_prop', 'Наименование указанного свойства класса отличается от наименования глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_not_match_desc', 'insert', 'global_prop_link_class_prop', 'Описание указанного свойства класса отличается от описания глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_not_match_prop_type', 'insert', 'global_prop_link_class_prop', 'Тип указанного свойства класса отличается от типа глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_user_not_match_area_val', 'insert', 'global_prop_link_class_prop', 'Область значений указанного свойства типа пользовательское не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_object_not_match_area_val', 'insert', 'global_prop_link_class_prop', 'Область значений указанного свойства типа объектное не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_link_not_match_area_val', 'insert', 'global_prop_link_class_prop', 'Область значений указанного свойства типа ссылка не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('none', 'insert', 'global_prop_link_class_prop', 'Неизвестная ошибка линковки глобального свойства концепции', '-', '3', 'global_prop_link_class_prop_include'), 
('prop_and_global_prop_enum_not_match_area_val', 'insert', 'global_prop_link_class_prop', 'Область значений указанного свойства типа перечисление не соотвествует области значений глобального свойства', '-', '3', 'global_prop_link_class_prop_include'), 
('global_prop_upd_not_found', 'update', 'global_prop', 'Указанное глобальное свойство концепции не найдено', '-', '1', 'global_prop_upd'), 
('group_pattern_not_found', 'insert', 'group', 'Указанная копируемая группа не найдена', '-', '1', 'group_copy'), 
('group_pattern_in_recycle_space', 'insert', 'group', 'Указанная копируемая группа удалена в корзину', '-', '3', 'group_copy'), 
('group_parent_not_found', 'insert', 'group', 'Целевая группа не найдена', '-', '1', 'group_copy'), 
('group_parent_not_include_child_group', 'insert', 'group', 'Целевая группа не допускает вложения групп', '-', '1', 'group_copy'), 
('file_data_above_limit', 'update', 'doc_file', 'Размер переданного файла превышает ограничение библиотеки документов', '-', '3', 'doc_file_change'), 
('file_data_is_empty', 'update', 'doc_file', 'Передан пустой массив файла данных', '-', '3', 'doc_file_change'), 
('doc_file_del_not_found', 'delete', 'doc_file', 'Указанный файл документа не найден', '-', '1', 'doc_file_del'), 
('doc_category_not_found', 'insert', 'document', 'Указанная категория документов не найдена', '-', '1', 'document_add'), 
('doc_category_is_off', 'insert', 'document', 'Указанная категория документов отключена и не может быть назначена новым документам', '-', '3', 'document_add'), 
('doc_category_not_on_grouping', 'insert', 'document', 'Указанная категория документа не допускает включение в пакет документов', '-', '3', 'document_add'), 
('doc_parent_not_found', 'insert', 'document', 'Указанный пакет документов не найден', '-', '1', 'document_add'), 
('doc_parent_category_not_found', 'insert', 'document', 'Категория указанного пакета документов не найдена', '-', '1', 'document_add'), 
('doc_parent_category_not_package', 'insert', 'document', 'Категория указанного родительского документа не допускает включение пакета документов', '-', '3', 'document_add'), 
('document_has_no_valid_links', 'insert', 'document', 'Создаваемый документ не имеет действительных ссылок и родительских документов', '-', '3', 'document_add'), 
('entity_not_can_link', 'insert', 'document', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'document_add'), 
('entity_instance_not_found', 'insert', 'document', 'Указанный экземпляр сущности не найдена', '-', '1', 'document_add'), 
('conception_doc_parent_and_entity_not_match', 'insert', 'document', 'Концепции ссылочной сущности и родительского документа не совпадают', '-', '3', 'document_add'), 
('entity_instance_not_assigned', 'insert', 'document', 'Экземпляр ссылочной сущности не назначен', '-', '1', 'document_add'), 
('conception_entity_and_doc_category_not_match', 'insert', 'document', 'Концепции ссылочной сущности и указанной категории документов не совпадают', '-', '3', 'document_add'), 
('conception_actcatalog_not_set', 'insert', 'document', 'В текущей концепции не определен активный каталог библиотеки документов', '-', '3', 'document_add'), 
('cur_actcatalog_file_limit_not_set', 'insert', 'document', 'В текущей концепции не определен лимит файлов активного каталога библиотеки документов', '-', '3', 'document_add'), 
('file_data_is_null', 'insert', 'document', 'Передан пустой двоичный массив не содержащий данных файла', '-', '3', 'document_add'), 
('file_path_not_valid', 'insert', 'document', 'Внутренняя ошибка библиотеки документов, сформированный путь сохранения данных файла недоступен', '-', '3', 'document_add'), 
('file_save_unknown_error', 'insert', 'document', 'Внутренняя ошибка библиотеки документов, неизвестная ошибка сохранения файла', '-', '3', 'document_add'), 
('none', 'insert', 'document', 'Неизвестная ошибка создания документа', '-', '3', 'document_add'), 
('doc_del_not_found', 'delete', 'document', 'Указанный документ не найден', '-', '1', 'document_del'), 
('none', 'delete', 'document', 'Неизвестная ошибка удаления документа', '-', '3', 'document_del'), 
('none', 'delete', 'document', 'Неизвестная ошибка удаления документа', '-', '3', 'document_del_all'), 
('doc_del_not_found', 'delete', 'document', 'Указанный документ не найден', '-', '1', 'document_del_all'), 
('none', 'update', 'document', 'Неизвестная ошибка исключения документа', '-', '3', 'document_exclude_from_pack'), 
('doc_exc_has_no_links', 'update', 'document', 'Указанный документ не имеет ссылок, используйте метод удалить', '-', '3', 'document_exclude_from_pack'), 
('doc_exc_not_found', 'update', 'document', 'Указанный документ не найден', '-', '1', 'document_exclude_from_pack'), 
('doc_inc_not_found', 'update', 'document', 'Документ, указанный для включения в пакет, не найден', '-', '1', 'document_include_in_pack'), 
('doc_pack_not_found', 'update', 'document', 'Указанный пакет документов не найден', '-', '1', 'document_include_in_pack'), 
('doc_inc_category_not_on_grouping', 'update', 'document', 'Категория указанного документа не допускает группировку в пакет', '-', '3', 'document_include_in_pack'), 
('doc_parent_category_not_package', 'update', 'document', 'Категория указанного родительского документа не допускает включение пакета документов', '-', '3', 'document_include_in_pack'), 
('none', 'update', 'document', 'Неизвестная ошибка включения документа в  пакет', '-', '3', 'document_include_in_pack'), 
('none', 'update', 'document', 'Неизвестная ошибка обновления атрибутов документа', '-', '3', 'document_upd'), 
('doc_upd_not_found', 'update', 'document', 'Указанный документ не найден', '-', '1', 'document_upd'), 
('doc_category_not_found', 'update', 'document', 'Категория указанного документа не найден', '-', '1', 'document_upd'), 
('doc_category_new_not_found', 'update', 'document', 'Указанная категория документов не найдена', '-', '1', 'document_upd'), 
('conception_document_and_doc_category_not_match', 'update', 'document', 'Концепции категории документа и документа не совпадают', '-', '3', 'document_upd'), 
('doc_category_is_off', 'update', 'document', 'Указанная категория документов отключена и не может быть назначена новым документам', '-', '3', 'document_upd'), 
('doc_category_new_is_on_grouping', 'update', 'document', 'Указанная категория документа не допускает включение в пакет документов', '-', '3', 'document_upd'), 
('doc_category_new_is_not_on_grouping', 'update', 'document', 'Указанная категория документа не допускает формирование пакета документов', '-', '3', 'document_upd'), 
('group_del_include_class_val', 'delete', 'group', 'Указанная группа содержит классы назначенные в качестве значения объектных свойтсв', '-', '3', 'group_del'), 
('none', 'delete', 'group', 'Неизвестная ошибка удаления группы', '-', '3', 'group_del'), 
('none', 'move', 'group', 'Неизвестная ошибка перемещения группы', '-', '3', 'group_move'), 
('group_moved_not_found', 'move', 'group', 'Указанная группа не найдена', '-', '1', 'group_move'), 
('group_moved_is_recycle', 'move', 'group', 'Указанная группа удалена в корзину', '-', '3', 'group_move'), 
('group_target_not_found', 'move', 'group', 'Целевая группа не найдена', '-', '1', 'group_move'), 
('conception_not_match', 'move', 'group', 'Концепции переносимой и целевой групп не совпадают', '-', '3', 'group_move'), 
('group_target_in_recycle_space', 'move', 'group', 'Целевая группа удалена в корзину', '-', '3', 'group_move'), 
('group_target_not_include_child_group', 'move', 'group', 'Целевая группа не допускает размещение групп', '-', '3', 'group_move'), 
('group_moved_name_not_unique', 'move', 'group', 'Наименование переносимой группы не уникально в целевом расположении', '-', '3', 'group_move'), 
('group_moved_target_path_not_correct', 'move', 'group', 'Целевая группа размещена в переносимой группе', 'Циклические ссылки не допускаются', '3', 'group_move'), 
('egroup_not_found', 'update', 'group', 'Указанная группа не найдена', '-', '1', 'group_upd'), 
('egroup_not_off_class_include_act_class', 'update', 'group', 'Указанная группа содержит вложенные классы и не допускает выключение режима размещения классов', '-', '3', 'group_upd'), 
('egroup_not_on_class_include_child_group', 'update', 'group', 'Указанная группа содержит вложенные группы и не допускает включение режима размещения классов', '-', '3', 'group_upd'), 
('egroup_is_recycle', 'update', 'group', 'Указанная группа является корзиной концепции', '-', '3', 'group_upd'), 
('egroup_in_recycle_space', 'update', 'group', 'Указанная группа удалена в корзину', '-', '3', 'group_upd'), 
('egroup_name_not_unique', 'update', 'group', 'Наименование группы не уникально в текущем расположении', '-', '3', 'group_upd'), 
('none', 'update', 'group', 'Неизвестная ошибка изменения группы', '-', '3', 'group_upd'), 
('object_merging_array_is_empty', 'update', 'object', 'Передан пустой массив идентификаторов объединяемых объектов', '-', '3', 'object_merging'), 
('object_merging_unit_not_support_merging', 'update', 'object', 'Измеряемая величина объекта носителя суммы не допускает слияния объектов', '-', '3', 'object_merging'), 
('first_object_merging_not_found', 'update', 'object', 'Первый объект, носитель суммы объектов не найден', '-', '1', 'object_merging'), 
('object_merging_not_found', 'update', 'object', 'Один последующих из объектов подлежащих слиянию не нейден', '-', '1', 'object_merging'), 
('object_location_not_math', 'update', 'object', 'Расположение объектов подлежащих слиянию не совпадает', '-', '3', 'object_merging'), 
('object_class_snapshot_not_math', 'update', 'object', 'Снимки классов объектов подлежащих слиянию не совпадают', 'Объединять можно только объекты с одинаковыми снимками', '3', 'object_merging'), 
('object_merging_unit_not_support_merging_not_math_conversion_rule', 'update', 'object', 'Измеряемая величина объекта носителя суммы не допускает слияния объектов с различающимися правилами пересчета', '-', '3', 'object_merging'), 
('none', 'update', 'object', 'Неизвестная ошибка слияния объектов', '-', '3', 'object_merging'), 
('none', 'move', 'object', 'Неизвестная ошибка перемещения объекта', '-', '3', 'object_move'), 
('object_moving_bquantity_limit_violated', 'move', 'object', 'Указаное количество переносимого объекта превышает количество указанного объекта или является отрицательной величиной', '-', '3', 'object_move'), 
('rulel2_class_on_position_not_allowed', 'move', 'object', 'Перечень правил вложенности уровня 2 класс на позицию для целевой позиции не содержит разрешения для класса указанного объекта', '-', '3', 'object_move'), 
('rulel1_class_on_pos_temp_not_allowed', 'move', 'object', 'Классу объекта не назначено разрешение уровня 1 для шаблона указанной позиции', '-', '3', 'object_move'), 
('proto_position_target_not_include_object', 'move', 'object', 'Прототип шаблона целевой позиции не допускает размещения объектов', '-', '3', 'object_move'), 
('object_conception_not_math', 'move', 'object', 'Концепции переносимого объекта и целевой позиции не совпадают', '-', '3', 'object_move'), 
('position_target_not_found', 'move', 'object', 'Указанная целевая позиция не найдена', '-', '3', 'object_move'), 
('object_moving_not_found', 'move', 'object', 'Переносимый объект не найден', '-', '1', 'object_move'), 
('object_moving_on_freeze', 'move', 'object', 'Переносимый объект заблокирован', '-', '3', 'object_move'), 
('object_moving_class_snapshot_not_found', 'move', 'object', 'Снимок класса переносимого объекта не найден', 'Возможно повреждение метаданных концепции', '1', 'object_move'), 
('object_carrier_not_found', 'delete', 'object_prop_enum_val', 'Объект носитель свойства не найден', '-', '1', 'object_prop_enum_val_del'), 
('plan_not_found', 'insert', 'plan_given_range_plan', 'Указанный план не найден', '-', '1', 'plan_given_range_plan_add'), 
('none', 'delete', 'object_prop_enum_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'object_prop_enum_val_del'), 
('none', 'delete', 'object_prop_enum_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'object_prop_enum_val_objects_del'), 
('position_carrier_not_found', 'delete', 'object_prop_enum_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_enum_val_objects_del'), 
('class_prop_not_enum_type', 'delete', 'object_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'object_prop_enum_val_objects_del'), 
('class_prop_not_found', 'delete', 'object_prop_enum_val', 'Указанное свойство класса не найдено', '-', '1', 'object_prop_enum_val_objects_del'), 
('class_prop_not_enum_type', 'delete', 'object_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'object_prop_enum_val_del'), 
('eclass_prop_not_has_object_prop_override', 'delete', 'object_prop_enum_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_enum_val_objects_del'), 
('position_carrier_not_on_object', 'delete', 'object_prop_enum_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_enum_val_objects_del'), 
('log_category_not_found', 'insert', 'log', 'Указанная категория записей журнала не найдена', '-', '1', 'log_add'), 
('log_category_is_off', 'insert', 'log', 'Указанная категория записей журнала отключена и не может быть назначена новым записям', '-', '3', 'log_add'), 
('entity_not_found', 'insert', 'log', 'Указанная сущность не найдена', '-', '1', 'log_add'), 
('entity_not_can_link', 'insert', 'log', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'log_add'), 
('entity_instance_not_found', 'insert', 'log', 'Указанный экземпляр сущности не найден', '-', '1', 'log_add'), 
('conception_log_parent_and_entity_not_match', 'insert', 'log', 'Концепции ссылочной сущности и родительского запис журналаа не совпадают', '-', '3', 'log_add'), 
('entity_instance_not_assigned', 'insert', 'log', 'Указанный экземпляр ссылочной сущности не может быть назначен', '-', '1', 'log_add'), 
('log_class_body_is_empty', 'insert', 'log', 'Класс записи журнала не предоставлен', '-', '3', 'log_add'), 
('none', 'insert', 'log', 'Неизвестная ошибка создания записи журнала', '-', '3', 'log_add'), 
('conception_not_found', 'insert', 'log_category', 'Указанная концепция не найдена', '-', '7', 'log_category_add'), 
('name_not_unique', 'insert', 'log_category', 'Указанное наименование категории записей журнала не является уникальным в текущей концепции', '-', '3', 'log_category_add'), 
('position_carrier_not_found', 'insert', 'object_prop_enum_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_enum_val_objects_set'), 
('conception_not_found', 'insert', 'plan', 'Указанная концепция не найдена', '-', '1', 'plan_add'), 
('position_carrier_not_on_object', 'insert', 'object_prop_enum_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_enum_val_objects_set'), 
('position_carrier_in_recycle', 'insert', 'object_prop_enum_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_enum_val_objects_set'), 
('position_carrier_in_recycle', 'delete', 'object_prop_enum_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_enum_val_objects_del'), 
('class_prop_not_found', 'insert', 'object_prop_enum_val', 'Указанное свойство класса не найдено', '-', '1', 'object_prop_enum_val_objects_set'), 
('eclass_prop_not_has_object_prop_override', 'insert', 'object_prop_enum_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_enum_val_objects_set'), 
('class_prop_not_enum_type', 'insert', 'object_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'object_prop_enum_val_objects_set'), 
('class_prop_enum_val_not_found', 'insert', 'object_prop_enum_val', 'Данные значения свойства класса не найдены', '-', '7', 'object_prop_enum_val_objects_set'), 
('none', 'insert', 'log_category', 'Неизвестная ошибка создания категории записей журнала', '-', '3', 'log_category_add'), 
('prop_enum_not_match', 'insert', 'object_prop_enum_val', 'Перечисление значения свойства класса и перечисления указанного элемента не совпадают', '-', '3', 'object_prop_enum_val_objects_set'), 
('none', 'insert', 'object_prop_enum_val', 'Неизвестная ошибка присвоения значения свойства перечисления', '-', '3', 'object_prop_enum_val_objects_set'), 
('class_prop_not_override', 'delete', 'object_prop_enum_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_enum_val_del'), 
('log_category_not_found', 'delete', 'log_category', 'Указанная категория записей журнала не найдена', '-', '1', 'log_category_del'), 
('log_category_is_use', 'delete', 'log_category', 'Указанная категория записей журнала используется', '-', '3', 'log_category_del'), 
('none', 'delete', 'log_category', 'Неизвестная ошибка удаления категории записей журнала', '-', '3', 'log_category_del'), 
('log_category_not_found', 'update', 'log_category', 'Указанная категория записей журнала не найдена', '-', '1', 'log_category_upd'), 
('log_category_is_use', 'update', 'log_category', 'Указанная категория записей журнала используется', '-', '3', 'log_category_upd'), 
('level_less_zero', 'update', 'log_category', 'Указанный уровень категории записей журнала меньше нуля', '-', '3', 'log_category_upd'), 
('name_not_unique', 'update', 'log_category', 'Указанное наименование категории документов не является уникальным в текущей концепции', '-', '3', 'log_category_upd'), 
('none', 'update', 'log_category', 'Неизвестная ошибка изменения категории документа', '-', '3', 'log_category_upd'), 
('log_message_is_empty', 'insert', 'log', 'Выбранное сообщение слишком короткое', '-', '3', 'log_add'), 
('log_title_is_empty', 'insert', 'log', 'Выбранное описание слишком короткое', '-', '3', 'log_add'), 
('name_is_empty', 'insert', 'log_category', 'Выбранное наименование слишком короткое', '-', '3', 'log_category_add'), 
('name_is_empty', 'update', 'log_category', 'Выбранное наименование слишком короткое', '-', '3', 'log_category_upd'), 
('none', 'delete', 'log', 'Неизвестная ошибка удаления записи журнала', '-', '3', 'log_del'), 
('log_del_not_found', 'delete', 'log', 'Указанная запись журнала не найдена', '-', '1', 'log_del'), 
('none', 'insert', 'log_link', 'Неизвестная ошибка создания ссылки для записи журнала', '-', '3', 'log_link_add'), 
('log_not_found', 'insert', 'log_link', 'Указанная запись журнала не найдена', '-', '1', 'log_link_add'), 
('log_link_already_set', 'insert', 'log_link', 'Запись журнала имеет установленную ссылку на указанную сущность БД', '-', '3', 'log_link_add'), 
('entity_not_found', 'insert', 'log_link', 'Указанная ссылочная сущность не найдена', '-', '1', 'log_link_add'), 
('entity_instance_not_found', 'insert', 'log_link', 'Указанный экземпляр ссылочной сущности не найден', '-', '1', 'log_link_add'), 
('entity_not_can_link', 'insert', 'log_link', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'log_link_add'), 
('conception_not_match', 'insert', 'log_link', 'Концепция записи журнала и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'log_link_add'), 
('entity_instance_id_not_valid', 'insert', 'log_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'log_link_add'), 
('none', 'delete', 'log_link', 'Неизвестная ошибка удаления ссылки записи журнала', '-', '3', 'log_link_del'), 
('none', 'update', 'log', 'Неизвестная ошибка обновления записи журнала', '-', '3', 'log_upd'), 
('log_upd_not_found', 'update', 'log', 'Указанная запись журнала не найдена', '-', '1', 'log_upd'), 
('log_category_not_found', 'update', 'log', 'Указанная категория записей журнала не найдена', '-', '1', 'log_upd'), 
('log_category_is_off', 'update', 'log', 'Указанная категория записей журнала отключена', '-', '3', 'log_upd'), 
('conception_log_and_log_category_not_match', 'update', 'log', 'Концепции категории записей и запbси журнала не совпадают', '-', '3', 'log_upd'), 
('log_class_body_is_empty', 'update', 'log', 'Класс записи журнала не предоставлен', '-', '3', 'log_upd'), 
('range_max_invalid_value', 'insert', 'plan', 'Общее ограничение плановых диапазонов не может быть нулевым значением', '-', '3', 'plan_add'), 
('plan_name_not_unique', 'insert', 'plan', 'Наименование нарушает уникальность в пределах выбранного расположения плана', '-', '3', 'plan_add'), 
('plan_parent_not_found', 'insert', 'plan', 'Указанный родительский план не найден', '-', '1', 'plan_add'), 
('plan_parent_has_given_range', 'insert', 'plan', 'Родительский план имеет назначенные диапазоны', '-', '3', 'plan_add'), 
('conception_not_match', 'insert', 'plan', 'Указанная концепция не совпадает с концепцией родительского плана', '-', '3', 'plan_add'), 
('none', 'insert', 'plan', 'Неизвестная ошибка добавления плана', '-', '3', 'plan_add'), 
('log_link_not_found', 'delete', 'log_link', 'Указанная ссылка записи журнала не найдена', '-', '1', 'log_link_del'), 
('none', 'delete', 'plan', 'Неизвестная ошибка удаления плана', '-', '3', 'plan_del'), 
('plan_is_on_freeze', 'delete', 'plan', 'Указанный план защищен от удаления', '-', '3', 'plan_del'), 
('object_carrier_not_found', 'insert', 'object_prop_enum_val', 'Объект носитель указанного свойства класса не найден', '-', '7', 'object_prop_enum_val_set'), 
('class_prop_not_enum_type', 'insert', 'object_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'object_prop_enum_val_set'), 
('class_prop_enum_val_not_found', 'insert', 'object_prop_enum_val', 'Данные значения свойства класса не найдены', '-', '7', 'object_prop_enum_val_set'), 
('prop_enum_not_match', 'insert', 'object_prop_enum_val', 'Перечисление значения свойства класса и перечисления указанного элемента не совпадают', '-', '3', 'object_prop_enum_val_set'), 
('prop_enum_val_not_found', 'insert', 'object_prop_enum_val', 'Указанный элемент перечисления не найден', '-', '7', 'object_prop_enum_val_objects_set'), 
('prop_enum_val_not_found', 'insert', 'object_prop_enum_val', 'Указанный элемент перечисления не найден', '-', '7', 'object_prop_enum_val_set'), 
('object_carrier_not_found', 'delete', 'object_prop_link_val', 'Объект носитель указанного свойства класса не найден', '-', '1', 'object_prop_link_val_del'), 
('class_prop_not_found', 'insert', 'object_prop_enum_val', 'Указанное свойство объекта не найдено', '-', '7', 'object_prop_enum_val_set'), 
('class_prop_not_found', 'delete', 'object_prop_link_val', 'Указанное свойство объекта не найдено', '-', '7', 'object_prop_link_val_del'), 
('class_prop_not_link_type', 'delete', 'object_prop_link_val', 'Указанное свойство объекта не является ссылкой', '-', '3', 'object_prop_link_val_del'), 
('none', 'insert', 'object_prop_enum_val', 'Неизвестная ошибка присвоения значения свойства', '-', '3', 'object_prop_enum_val_set'), 
('position_carrier_not_found', 'delete', 'object_prop_link_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_link_val_objects_del'), 
('position_carrier_not_on_object', 'delete', 'object_prop_link_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_link_val_objects_del'), 
('position_carrier_in_recycle', 'delete', 'object_prop_link_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_link_val_objects_del'), 
('class_prop_not_link_type', 'delete', 'object_prop_link_val', 'Указанное свойство объекта не является ссылкой', '-', '3', 'object_prop_link_val_objects_del'), 
('eclass_prop_not_has_object_prop_override', 'delete', 'object_prop_link_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_link_val_objects_del'), 
('none', 'delete', 'object_prop_link_val', 'Неизвестная ошибка удаления значения свойства', '-', '1', 'object_prop_link_val_del'), 
('none', 'delete', 'object_prop_link_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'object_prop_link_val_objects_del'), 
('none', 'insert', 'object_prop_link_val', 'Неизвестная ошибка присвоения значения свойства', '-', '3', 'object_prop_link_val_objects_set'), 
('conception_not_match', 'insert', 'object_prop_link_val', 'Концепции объекта и указанного экземпляра сущности не совпадают', '-', '3', 'object_prop_link_val_objects_set'), 
('class_prop_not_found', 'delete', 'object_prop_link_val', 'Указанное свойство объекта не найдено', '-', '7', 'object_prop_link_val_objects_del'), 
('eclass_prop_not_has_object_prop_override', 'insert', 'object_prop_link_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_link_val_objects_set'), 
('class_prop_not_link_type', 'insert', 'object_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'object_prop_link_val_objects_set'), 
('class_prop_not_found', 'insert', 'object_prop_link_val', 'Указанное свойство класса не найдено', '-', '1', 'object_prop_link_val_objects_set'), 
('position_carrier_in_recycle', 'insert', 'object_prop_link_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_link_val_objects_set'), 
('position_carrier_not_on_object', 'insert', 'object_prop_link_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_link_val_objects_set'), 
('position_carrier_not_found', 'insert', 'object_prop_link_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_link_val_objects_set'), 
('class_prop_link_val_not_found', 'insert', 'object_prop_link_val', 'Данные значения свойства класса не найдены', '-', '7', 'object_prop_link_val_objects_set'), 
('entity_instance_not_found', 'insert', 'object_prop_link_val', 'Указанный экземпляр сущности не найден', '-', '3', 'object_prop_link_val_objects_set'), 
('class_prop_not_override', 'insert', 'object_prop_enum_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_enum_val_set'), 
('class_prop_not_override', 'delete', 'object_prop_link_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_link_val_del'), 
('plan_range_not_found', 'insert', 'plan_given_range_plan', 'Указанный плановый диапазон не найден', '-', '1', 'plan_given_range_plan_add'), 
('plan_range_not_include_lower', 'insert', 'plan_given_range_plan', 'В переданном диапазоне исключена нижняя граница', '-', '3', 'plan_given_range_plan_add'), 
('plan_range_include_upper', 'insert', 'plan_given_range_plan', 'В переданный диапазон включена верхняя граница', '-', '3', 'plan_given_range_plan_add'), 
('plan_given_range_not_include_in_plan_range', 'insert', 'plan_given_range_plan', 'Переданный назначенный диапазон не входит в указанный плановый диапазон', '-', '3', 'plan_given_range_plan_add'), 
('plan_given_range_crossing_in_plan_range', 'insert', 'plan_given_range_plan', 'Переданный назначенный диапазон пересекается с назначенными диапазонами указанного планового диапазона', '-', '3', 'plan_given_range_plan_add'), 
('none', 'insert', 'plan_given_range_plan', 'Неизвестная ошибка добавления назначенного диапазона', '-', '3', 'plan_given_range_plan_add'), 
('none', 'delete', 'plan_given_range_plan', 'Неизвестная ошибка удаления планового диапазона', '-', '3', 'plan_given_range_plan_del'), 
('plan_given_range_not_found', 'delete', 'plan_given_range_plan', 'Указанный выделенный диапазон не найден', '-', '1', 'plan_given_range_plan_del'), 
('plan_given_range_plan_not_found', 'insert', 'plan_given_range_plan_link', 'Указанный выделенный диапазон не найден', '-', '1', 'plan_given_range_plan_link_add'), 
('doc_link_already_set', 'insert', 'plan_given_range_plan_link', 'Выделенный диапазон имеет установленную ссылку на указанную сущность БД', '-', '3', 'plan_given_range_plan_link_add'), 
('entity_not_found', 'insert', 'plan_given_range_plan_link', 'Указанная ссылочная сущность не найдена', '-', '1', 'plan_given_range_plan_link_add'), 
('entity_instance_not_found', 'insert', 'plan_given_range_plan_link', 'Указанный экземпляр ссылочной сущности не найден', '-', '1', 'plan_given_range_plan_link_add'), 
('entity_not_can_link', 'insert', 'plan_given_range_plan_link', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'plan_given_range_plan_link_add'), 
('conception_not_match', 'insert', 'plan_given_range_plan_link', 'Концепция выделенного диапазона плана и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'plan_given_range_plan_link_add'), 
('entity_instance_id_not_valid', 'insert', 'plan_given_range_plan_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'plan_given_range_plan_link_add'), 
('plan_given_range_plan_not_found', 'delete', 'plan_given_range_plan_link', 'Указанный выделенный диапазон плана не найден', '-', '1', 'plan_given_range_plan_link_del'), 
('class_prop_not_found', 'insert', 'object_prop_link_val', 'Указанное свойство класса не найдено', '-', '1', 'object_prop_link_val_set'), 
('object_carrier_not_found', 'insert', 'object_prop_link_val', 'Объект носитель свойства не найден', '-', '1', 'object_prop_link_val_set'), 
('class_prop_not_link_type', 'insert', 'object_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'object_prop_link_val_set'), 
('none', 'delete', 'plan_given_range_plan_link', 'Неизвестная ошибка удаления ссылки выделенного диапазона плана', '-', '3', 'plan_given_range_plan_link_del'), 
('class_prop_link_val_not_found', 'insert', 'object_prop_link_val', 'Данные значения свойства класса не найдены', '-', '7', 'object_prop_link_val_set'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылки выделенного диапазона плана', '-', '3', 'plan_given_range_plan_link_del_all'), 
('entity_instance_not_found', 'insert', 'object_prop_link_val', 'Указанный экземпляр сущности не найден', '-', '1', 'object_prop_link_val_set'), 
('entity_instance_is_circular_link', 'insert', 'object_prop_link_val', 'Указанный экземпляр сущности является носителем редактирумого свойства и образует циклическую ссылку', '-', '1', 'object_prop_link_val_set'), 
('conception_not_match', 'insert', 'object_prop_link_val', 'Концепции объекта и указанного экземпляра сущности не совпадают', '-', '1', 'object_prop_link_val_set'), 
('none', 'insert', 'object_prop_link_val', 'Неизвестная ошибка присвоения значения свойства', '-', '3', 'object_prop_link_val_set'), 
('plan_given_range_not_found', 'update', 'plan_given_range_plan', 'Указанный выделенный диапазон не найден', '-', '1', 'plan_given_range_plan_upd'), 
('plan_range_include_upper', 'update', 'plan_given_range_plan', 'В переданный диапазон включена верхняя граница', '-', '3', 'plan_given_range_plan_upd'), 
('plan_range_not_include_lower', 'update', 'plan_given_range_plan', 'В переданном диапазоне исключена нижняя граница', '-', '3', 'plan_given_range_plan_upd'), 
('plan_given_range_not_include_in_plan_range', 'update', 'plan_given_range_plan', 'Переданный назначенный диапазон не входит в указанный плановый диапазон', '-', '3', 'plan_given_range_plan_upd'), 
('plan_given_range_crossing_in_plan_range', 'update', 'plan_given_range_plan', 'Переданный назначенный диапазон пересекается с назначенными диапазонами указанного планового диапазона', '-', '3', 'plan_given_range_plan_upd'), 
('none', 'update', 'plan_given_range_plan', 'Неизвестная ошибка добавления назначенного диапазона', '-', '3', 'plan_given_range_plan_upd'), 
('position_carrier_not_found', 'insert', 'object', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_object_val_objects_set_new'), 
('position_carrier_not_on_object', 'insert', 'object', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_object_val_objects_set_new'), 
('none', 'insert', 'plan_link', 'Неизвестная ошибка добавления ссылки к плану', '-', '3', 'plan_link_add'), 
('position_carrier_on_recycle', 'insert', 'object', 'Указанная позиция носитель удалена в корзиину', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_prop_obj_val_not_found', 'insert', 'object', 'Данные значения объектного свойства не найдены', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_prop_obj_val_value_not_set', 'insert', 'object', 'Данные значения объектного свойства не установлены', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_val_not_found', 'insert', 'object', 'Активное представление класса значения не найдено', '-', '7', 'object_prop_object_val_objects_set_new'), 
('class_real_not_found', 'insert', 'object', 'Активное представление указанного вещественного класса не не найдено', '-', '7', 'object_prop_object_val_objects_set_new'), 
('class_not_real', 'insert', 'object', 'Указанный класс не является вещественным', '-', '3', 'object_prop_object_val_objects_set_new'), 
('pclass_not_on', 'insert', 'object', 'Указанный вещественный класс выключен', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_real_in_recycle_space', 'insert', 'object', 'Активное представление указанного вещественного класса удалено в корзину', '-', '3', 'object_prop_object_val_objects_set_new'), 
('conception_class_real_and_object_carrier_not_match', 'insert', 'object', 'Концепции объекта носителя и вещественного класса встраиваемого объекта не совпадают', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_real_not_include_branch_class_val', 'insert', 'object', 'Указанный вещественный класс не входит в ветвь класса значения объектного свойства', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_real_include_noready_class_prop', 'insert', 'object', 'Свойства выбранного вещественного класса не готовы к созданию объектов', '-', '3', 'object_prop_object_val_objects_set_new'), 
('class_real_noready_name_format', 'insert', 'object', 'Шаблон наименования объектов выбранного вещественного класса не готов к созданию объектов', '-', '3', 'object_prop_object_val_objects_set_new'), 
('conversion_rule_not_assigned', 'insert', 'object', 'Указаное правило пересчета не допустимо в выбранном вещественном классе', '-', '3', 'object_prop_object_val_objects_set_new'), 
('conversion_rule_not_found', 'insert', 'object', 'Указаное правило пересчета не найдено', '-', '1', 'object_prop_object_val_objects_set_new'), 
('conversion_rule_conception_not_math', 'insert', 'object', 'Концепции объекта носителя и указаного правила пересчета не совпадают', '-', '3', 'object_prop_object_val_objects_set_new'), 
('rule_quantity_on_single_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила единичного учета', '-', '3', 'object_prop_object_val_objects_set_new'), 
('rule_quantity_not_fractional_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила запрета дробной части', '-', '3', 'object_prop_object_val_objects_set_new'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила к порядку округления', '-', '3', 'object_prop_object_val_objects_set_new'), 
('rule_quantity_violated', 'insert', 'object', 'Указанное количество объекта нарушает требования правила к количеству объектов', '-', '3', 'object_prop_object_val_objects_set_new'), 
('emembed_object_quantity_above_max', 'insert', 'object', 'Общее количество встраиваемых объектов превышает установленный лимит на встраивание', '-', '3', 'object_prop_object_val_objects_set_new'), 
('none', 'insert', 'object', 'Неизвестная ошибка встраивания объекта', '-', '3', 'object_prop_object_val_objects_set_new'), 
('doc_link_already_set', 'insert', 'plan_link', 'План имеет установленную ссылку на указанную сущность БД', '-', '3', 'plan_link_add'), 
('entity_not_can_link', 'insert', 'plan_link', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'plan_link_add'), 
('conception_not_match', 'insert', 'plan_link', 'Концепции плана и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'plan_link_add'), 
('entity_instance_id_not_valid', 'insert', 'plan_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'plan_link_add'), 
('plan_not_found', 'insert', 'plan_link', 'Указанный план не найден', '-', '1', 'plan_link_add'), 
('entity_not_found', 'insert', 'plan_link', 'Указанная ссылочная сущность не найдена', '-', '1', 'plan_link_add'), 
('entity_instance_not_found', 'insert', 'plan_link', 'Указанный экземпляр ссылочной сущности не найден', '-', '1', 'plan_link_add'), 
('plan_not_found', 'delete', 'plan_link', 'Указанный план не найден', '-', '1', 'plan_link_del'), 
('none', 'delete', 'plan_link', 'Неизвестная ошибка удаления ссылки плана', '-', '3', 'plan_link_del'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылки плана', '-', '3', 'plan_link_del_all'), 
('plan_not_found', 'delete', 'doc_link', 'Указанный план не найден', '-', '1', 'plan_link_del_all'), 
('plan_not_found', 'insert', 'plan_range', 'Указанный план не найден', '-', '1', 'plan_range_add'), 
('plan_parent_not_found', 'insert', 'plan_range', 'Родительский план указанного плана не', '-', '1', 'plan_range_add'), 
('plan_range_not_include_lower', 'insert', 'plan_range', 'В переданном диапазоне исключена нижняя граница', '-', '3', 'plan_range_add'), 
('plan_range_include_upper', 'insert', 'plan_range', 'В переданный диапазон включена верхняя граница', '-', '3', 'plan_range_add'), 
('count_range_plans_exceeded_limit', 'insert', 'plan_range', 'Достигнут предел для количества разрешенных плановых диапазонов плана', '-', '3', 'plan_range_add'), 
('none', 'insert', 'class_prop', 'Неизвестная ошибка добавления определяющего свойства класса', '-', '3', 'class_prop_add_as_global_prop'), 
('plan_range_not_include_in_plan_parent_plan_range', 'insert', 'plan_range', 'Переданный плановый диапазон не входит ни в один плановый диапазон родительского плана', '-', '3', 'plan_range_add'), 
('plan_range_crossing_in_plan_range', 'insert', 'plan_range', 'Переданный плановый диапазон пересекается с плановыми диапазонами родительского плана', '-', '3', 'plan_range_add'), 
('none', 'insert', 'plan_range', 'Неизвестная ошибка добавления планового диапазона', '-', '3', 'plan_range_add'), 
('plan_range_not_found', 'delete', 'plan_range', 'Указанный плановый диапазон не найден', '-', '1', 'plan_range_del'), 
('plan_range_inc_nesting_plan_range', 'delete', 'plan_range', 'Указанный плановый диапазон содержит вложенные плановые диапазоны подчиненного плана', '-', '3', 'plan_range_del'), 
('plan_range_inc_nesting_plan_given_range', 'delete', 'plan_range', 'Указанный плановый диапазон содержит выделенные диапазоны текущего плана', '-', '3', 'plan_range_del'), 
('none', 'delete', 'plan_range', 'Неизвестная ошибка удаления планового диапазона', '-', '3', 'plan_range_del'), 
('plan_range_not_found', 'insert', 'plan_range_link', 'Указанный плановый диапазон не найден', '-', '1', 'plan_range_link_add'), 
('entity_not_found', 'insert', 'plan_range_link', 'Указанная ссылочная сущность не найдена', '-', '1', 'plan_range_link_add'), 
('entity_instance_not_found', 'insert', 'plan_range_link', 'Указанный экземпляр ссылочной сущности не найден', '-', '1', 'plan_range_link_add'), 
('doc_link_already_set', 'insert', 'plan_range_link', 'Плановый диапазон имеет установленную ссылку на указанную сущность БД', '-', '3', 'plan_range_link_add'), 
('entity_not_can_link', 'insert', 'plan_range_link', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'plan_range_link_add'), 
('entity_not_can_link', 'insert', 'plan_range_link', 'Концепция планового диапазона и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'conception_not_match'), 
('entity_instance_id_not_valid', 'insert', 'plan_range_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'conception_not_match'), 
('none', 'insert', 'plan_range_link', 'Неизвестная ошибка добавление ссылки к плановому диапазону', '-', '3', 'conception_not_match'), 
('none', 'insert', 'plan_range_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'plan_range_link_add'), 
('conception_not_match', 'insert', 'plan_range_link', 'Концепция планового диапазона и указанного экземпляра ссылочной сущности не совпадают', '-', '3', 'plan_range_link_add'), 
('entity_instance_id_not_valid', 'insert', 'plan_range_link', 'Указан недопустимый идентификатор экземпляра ссылочной сущности', '-', '3', 'plan_range_link_add'), 
('plan_range_not_found', 'delete', 'plan_range_link', 'Указанный план не найден', '-', '1', 'plan_range_link_del'), 
('none', 'delete', 'plan_range_link', 'Неизвестная ошибка удаления ссылки плана', '-', '3', 'plan_range_link_del'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылок планового диапазона', '-', '3', 'plan_range_link_del_all'), 
('plan_range_not_found', 'delete', 'doc_link', 'Указанный плановый диапазон не найден', '-', '1', 'plan_range_link_del_all'), 
('plan_range_not_found', 'update', 'plan_range', 'Указанный плановый диапазон не найден', '-', '1', 'plan_range_upd'), 
('plan_not_found', 'update', 'plan_range', 'Указанный план не найден', '-', '1', 'plan_range_upd'), 
('plan_parent_not_found', 'update', 'plan_range', 'Родительский план указанного плана не найден', '-', '1', 'plan_range_upd'), 
('plan_range_not_include_lower', 'update', 'plan_range', 'В переданном диапазоне исключена нижняя граница', '-', '3', 'plan_range_upd'), 
('plan_range_include_upper', 'update', 'plan_range', 'В переданный диапазон включена верхняя граница', '-', '3', 'plan_range_upd'), 
('count_range_plans_exceeded_limit', 'update', 'plan_range', 'Достигнут предел для количества разрешенных плановых диапазонов плана', '-', '3', 'plan_range_upd'), 
('plan_range_not_include_in_plan_parent_plan_range', 'update', 'plan_range', 'Переданный плановый диапазон не входит ни в один плановый диапазон родительского плана', '-', '3', 'plan_range_upd'), 
('plan_range_crossing_in_plan_range', 'update', 'plan_range', 'Переданный плановый диапазон пересекается с плановыми диапазонами родительского плана', '-', '3', 'plan_range_upd'), 
('none', 'update', 'plan_range', 'Неизвестная ошибка добавления планового диапазона', '-', '3', 'plan_range_upd'), 
('range_max_invalid_value', 'update', 'plan', 'Общее ограничение плановых диапазонов не может быть нулевым значением', '-', '3', 'plan_upd'), 
('count_plans_exceeded_limit', 'update', 'plan', 'Превышено общее ограничение вложенных планов', '-', '3', 'plan_upd'), 
('count_range_plans_exceeded_limit', 'update', 'plan', 'Превышено общее ограничение плановых диапазонов', '-', '3', 'plan_upd'), 
('plan_range_is_crossing', 'update', 'plan', 'Редактируемый план содержит пересекающиеся плановые диапазоны и не может быть переведен в режим непересакающихся диапазонов', '-', '3', 'plan_upd'), 
('plan_name_is_empty', 'update', 'plan', 'Наименование не может быть менее минимального количества символов', '-', '3', 'plan_upd'), 
('plan_name_not_unique', 'update', 'plan', 'Наименование нарушает уникальность в пределах выбранного расположения плана', '-', '3', 'plan_upd'), 
('none', 'update', 'plan', 'Неизвестная ошибка изменения плана', '-', '3', 'plan_upd'), 
('plan_not_found', 'update', 'plan', 'Указанный план не найден', '-', '1', 'plan_upd'), 
('none', 'insert', 'pos_temp', 'Неизвестная ошибка добавления шаблона позиции', '-', '3', 'pos_temp_add'), 
('none', 'copy', 'pos_temp', 'Неизвестная ошибка копирования шаблона позиции', '-', '3', 'pos_temp_copy'), 
('none', 'delete', 'pos_temp', 'Неизвестная ошибка удаления шаблона позиции', '-', '3', 'pos_temp_del'), 
('tpos_not_found', 'insert', 'pos_temp', 'Указанный несущий шаблон не найден', '-', '1', 'pos_temp_nested_include'), 
('tpos_nested_not_found', 'insert', 'pos_temp', 'Указанный встраиваемый шаблон не найден', '-', '1', 'pos_temp_nested_include'), 
('tpos_is_service', 'insert', 'pos_temp', 'Указанный несущий шаблон является сервисным и не доускает создание правил', '-', '3', 'pos_temp_nested_include'), 
('tpos_nested_is_service', 'insert', 'pos_temp', 'Указанный встраиваемый шаблон является сервисным и не доускает создание правил', '-', '3', 'pos_temp_nested_include'), 
('conception_not_match', 'insert', 'pos_temp', 'Концепции несущего и встраиваемого шаблонов не совпадают', '-', '3', 'pos_temp_nested_include'), 
('pos_temp_nsting_rule_limit_value_not_allowed', 'insert', 'pos_temp', 'Лимит на количество встраиваемых позиций не может быть отрицательной величиной', '-', '3', 'pos_temp_nested_include'), 
('pos_temp_nsting_rule_limit_not_allowed', 'insert', 'pos_temp', 'Фактическое колличество вложенных позиций, созданных в рамках предложенных отношений  превышает заданный лимит на количество встраиваемых позиций', '-', '3', 'pos_temp_nested_include'), 
('none', 'insert', 'pos_temp', 'Неизвестная ошибка создания правила встраивания позиций', '-', '3', 'pos_temp_nested_include'), 
('pos_temp_nsting_rule_broken', 'insert', 'pos_temp', 'Предложенное отношение шаблонов нарушает правила вложения прототипов', '-', '4', 'pos_temp_nested_include'), 
('conception_not_found', 'insert', 'pos_temp', 'Выбранная концепция не найдена', '-', '7', 'pos_temp_add'), 
('prototype_is_service', 'insert', 'pos_temp', 'Выбранный прототип является сервисным', 'Сервисные прототипы не могут использоваться при создании пользовательских шаблонов позиций', '3', 'pos_temp_add'), 
('prototype_not_found', 'insert', 'pos_temp', 'Выбранный прототип не найден', '-', '7', 'pos_temp_add'), 
('tpos_not_found', 'delete', 'pos_temp', 'Выбранный шаблон позиции не найден', '-', '1', 'pos_temp_del'), 
('tpos_has_position_inheriting', 'delete', 'pos_temp', 'Выбранный шаблон позиции используется', '-', '3', 'pos_temp_del'), 
('tpos_pattern_is_service', 'copy', 'pos_temp', 'Выбранный шаблон позиции является сервисным', '-', '3', 'pos_temp_copy'), 
('pos_temp_upd_not_found', 'insert', 'pos_temp_prop', 'Указанный шаблон не найден', '-', '1', 'pos_temp_prop_add'), 
('pos_temp_not_on', 'insert', 'pos_temp_prop', 'Указанный шаблон отключен и не может быть изменен', '-', '3', 'pos_temp_prop_add'), 
('pos_temp_is_service', 'insert', 'pos_temp_prop', 'Указанный шаблон является сервисным и не может быть изменен', '-', '3', 'pos_temp_prop_add'), 
('pos_temp_prop_name_not_unique', 'insert', 'pos_temp_prop', 'Указанное наименование свойства не уникально в пределах несущего шаблона или не допустимо', '-', '3', 'pos_temp_prop_add'), 
('prop_type_not_found', 'insert', 'pos_temp_prop', 'Указаный тип свойства не найден', '-', '7', 'pos_temp_prop_add'), 
('none', 'insert', 'pos_temp_prop', 'Неизвестная ошибка добавления определяющего свойства класса', '-', '3', 'pos_temp_prop_add'), 
('pos_temp_prop_upd_not_found', 'delete', 'pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_del'), 
('pos_temp_upd_not_found', 'delete', 'pos_temp_prop', 'Шаблон, содержащий указанное свойство, не найдено', '-', '1', 'pos_temp_prop_del'), 
('pos_temp_upd_not_on', 'delete', 'pos_temp_prop', 'Шаблон содержащий указанное свойство отключен и не может быть изменен', '-', '3', 'pos_temp_prop_del'), 
('pos_temp_upd_is_service', 'delete', 'pos_temp_prop', 'Шаблон содержащий указанное свойство является сервисным и не может быть изменен', '-', '3', 'pos_temp_prop_del'), 
('none', 'delete', 'pos_temp_prop', 'Неизвестная ошибка добавления определяющего свойства класса', '-', '3', 'pos_temp_prop_del'), 
('pos_temp_prop_not_found', 'insert', 'pos_temp_prop_enum_val', 'Указанное свойство шаблона не найдено', '-', '7', 'pos_temp_prop_enum_val_set'), 
('pos_temp_carrier_not_found', 'insert', 'pos_temp_prop_enum_val', 'Шаблон носитель указанного свойства не найден', '-', '1', 'pos_temp_prop_enum_val_set'), 
('prop_enum_not_found', 'insert', 'pos_temp_prop_enum_val', 'Указанное перечисление не найдено', '-', '1', 'pos_temp_prop_enum_val_set'), 
('prop_enum_val_not_found', 'insert', 'pos_temp_prop_enum_val', 'Указанный элемент перечисления не найден', '-', '1', 'pos_temp_prop_enum_val_set'), 
('pos_temp_prop_not_enum_type', 'insert', 'pos_temp_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'pos_temp_prop_enum_val_set'), 
('pos_temp_has_position_not_upd_prop_data_area', 'insert', 'pos_temp_prop_enum_val', 'Шаблон, содержащий указанное свойство, имеет позиции и не допускает изменения области определения данных значения свойства: перечисление', '-', '3', 'pos_temp_prop_enum_val_set'), 
('conception_not_match', 'insert', 'pos_temp_prop_enum_val', 'Концепции указанного перечисления и редактируемого свойства не совпадают', '-', '3', 'pos_temp_prop_enum_val_set'), 
('prop_enum_use_area_out_of_range', 'insert', 'pos_temp_prop_enum_val', 'Область применения перечисления не охватывает позиции и шаблоны', '-', '3', 'pos_temp_prop_enum_val_set'), 
('prop_enum_val_out_of_range', 'insert', 'pos_temp_prop_enum_val', 'Указанный элемент перечисления не входит в назначенное перечисление', '-', '3', 'pos_temp_prop_enum_val_set'), 
('none', 'insert', 'pos_temp_prop_enum_val', 'Неизвестная ошибка присвоения значения свойства перечисления', '-', '3', 'pos_temp_prop_enum_val_set'), 
('pos_temp_prop_not_found', 'delete', 'pos_temp_prop_link_val', 'Указанное свойство класса не найдено', '-', '1', 'pos_temp_prop_link_val_del'), 
('pos_temp_carrier_not_found', 'delete', 'pos_temp_prop_link_val', 'Указанный класс носитель свойства не найден', '-', '1', 'pos_temp_prop_link_val_del'), 
('pos_temp_prop_not_link_type', 'delete', 'pos_temp_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'pos_temp_prop_link_val_del'), 
('none', 'delete', 'pos_temp_prop_link_val', 'Неизвестная ошибка удаления значения свойства шаблона', '-', '3', 'pos_temp_prop_link_val_del'), 
('pos_temp_prop_not_found', 'insert', 'pos_temp_prop_link_val', 'Указанное свойство шаблона не найдено', '-', '7', 'pos_temp_prop_link_val_set'), 
('pos_temp_carrier_not_found', 'insert', 'pos_temp_prop_link_val', 'Шаблон носитель указанного свойства не найден', '-', '1', 'pos_temp_prop_link_val_set'), 
('entity_not_found', 'insert', 'pos_temp_prop_link_val', 'Указанная сущность не найдена', '-', '1', 'pos_temp_prop_link_val_set'), 
('entity_instance_not_found', 'insert', 'pos_temp_prop_link_val', 'Указанный экземпляр сущности не найден', '-', '1', 'pos_temp_prop_link_val_set'), 
('pos_temp_prop_not_link_type', 'insert', 'pos_temp_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'pos_temp_prop_link_val_set'), 
('entity_not_can_link', 'insert', 'pos_temp_prop_link_val', 'Указанная сущность не допускает ссылочного связывания', '-', '3', 'pos_temp_prop_link_val_set'), 
('pos_temp_has_position_not_upd_prop_data_area', 'insert', 'pos_temp_prop_link_val', 'Шаблон, содержащий указанное свойство, имеет позиции и не допускает изменения области определения данных значения свойства: тип ссылочной сущности', '-', '3', 'pos_temp_prop_link_val_set'), 
('entity_instance_is_circular_link', 'insert', 'pos_temp_prop_link_val', 'Указанный экземпляр сущности является носителем редактирумого свойства и образует циклическую ссылку', '-', '3', 'pos_temp_prop_link_val_set'), 
('conception_not_match', 'insert', 'pos_temp_prop_link_val', 'Концепция редактируемого свойства и указанного экземпляра сущности не совпадают', '-', '3', 'pos_temp_prop_link_val_set'), 
('none', 'insert', 'pos_temp_prop_link_val', 'Неизвестная ошибка присвоения значения свойства ссылки', '-', '3', 'pos_temp_prop_link_val_set'), 
('pos_is_lockdel', 'update', 'position', 'Выбранная позиция заблокирована', '-', '1', 'position_upd'), 
('pos_temp_prop_type_not_object', 'insert', 'pos_temp_prop_object_val', 'Указанное свойство не является объектным', '-', '3', 'pos_temp_prop_object_val_set'), 
('pos_temp_has_position_not_upd_prop_data_area', 'insert', 'pos_temp_prop_object_val', 'Шаблон, содержащий указанное свойство, имеет позиции и не допуcкает изменения области определения данных значения свойства: класс значение свойство не является объектным', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_val_not_abstraction', 'insert', 'pos_temp_prop_object_val', 'Указанный класс значение свойства не является абстрактным', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_val_not_found', 'insert', 'pos_temp_prop_object_val', 'Указанный класс значение свойства не найдено', '-', '1', 'pos_temp_prop_object_val_set'), 
('class_val_conception_not_match', 'insert', 'pos_temp_prop_object_val', 'Концепции свойства и класса значения не совпадают', '-', '3', 'pos_temp_prop_object_val_set'), 
('bquantity_max_less_min', 'insert', 'pos_temp_prop_object_val', 'В параметрах значения объектного свойства отношение минимального, максимального количества объектов определено некорректно', '-', '3', 'pos_temp_prop_object_val_set'), 
('embed_mode_not_valid', 'insert', 'pos_temp_prop_object_val', 'Недопустимое значение режима встраивания объектов', '-', '3', 'pos_temp_prop_object_val_set'), 
('embed_limit_max_not_valid', 'insert', 'pos_temp_prop_object_val', 'Недопустимое значение ограничения максимального количества встраиваемых объектов в режиме встраивания по максимуму', '-', '3', 'pos_temp_prop_object_val_set'), 
('embed_limit_min_not_valid', 'insert', 'pos_temp_prop_object_val', 'Недопустимое значение ограничения минимального количества встраиваемых объектов в режиме встраивания по минимуму', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_real_val_not_found', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец для встраивания не найден', '-', '1', 'pos_temp_prop_object_val_set'), 
('class_real_val_not_real', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец не является вещественным', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_real_val_not_on', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец отключен', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_real_val_include_noready_class_prop', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец содержит свойства не готовые к созданию объектов', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_real_val_noready_name_format', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец содержит формат имени, не готовый к созданию объектов', '-', '3', 'pos_temp_prop_object_val_set'), 
('class_real_val_not_include_branch_class_val', 'insert', 'pos_temp_prop_object_val', 'Указанный класс образец не входит в ветвь класса значения свойства', '-', '3', 'pos_temp_prop_object_val_set'), 
('unit_conversion_rule_not_found', 'insert', 'pos_temp_prop_object_val', 'Указанное правило пересчета не найдено', '-', '1', 'pos_temp_prop_object_val_set'), 
('rule_quantity_on_single_violated', 'insert', 'pos_temp_prop_object_val', 'Сопоставленное по MIN/MAX количество объекта нарушает требования правила единичного учета', '-', '3', 'pos_temp_prop_object_val_set'), 
('rule_quantity_on_single_embed_single_violated', 'insert', 'pos_temp_prop_object_val', 'Режим встраивания одним объектом с указанным количеством нарушает требования правила единичного учета', '-', '3', 'pos_temp_prop_object_val_set'), 
('rule_quantity_not_fractional_violated', 'insert', 'pos_temp_prop_object_val', 'Указанное количество объекта нарушает требования правила запрета дробной части', '-', '3', 'pos_temp_prop_object_val_set'), 
('none', 'insert', 'pos_temp_prop_object_val', 'Неизвестная ошибка установки данных значения объектного свойства', '-', '3', 'pos_temp_prop_object_val_set'), 
('pos_temp_prop_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_sort_down'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Активный класс указанного свойства не найден', '-', '1', 'pos_temp_prop_sort_down'), 
('pos_temp_prop_not_found_in_sort_list', 'update', 'pos_temp_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'pos_temp_prop_sort_down'), 
('pos_temp_prop_not_found_in_sort_list', 'update', 'pos_temp_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'pos_temp_prop_sort_top'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Активный класс указанного свойства не найден', '-', '1', 'pos_temp_prop_sort_top'), 
('pos_temp_prop_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона не нейдено', '-', '1', 'pos_temp_prop_sort_top'), 
('pos_temp_prop_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_sort_up'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Активный класс указанного свойства не найден', '-', '1', 'pos_temp_prop_sort_up'), 
('pos_temp_prop_not_found_in_sort_list', 'update', 'pos_temp_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'pos_temp_prop_sort_up'), 
('pos_temp_prop_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_upd'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Шаблон, содержащий указанное свойство, не найден', '-', '1', 'pos_temp_prop_upd'), 
('pos_temp_upd_not_on', 'update', 'pos_temp_prop', 'Шаблон, содержащий указанное свойство, отключен и не может быть изменен', '-', '3', 'pos_temp_prop_upd'), 
('pos_temp_upd_is_service', 'update', 'pos_temp_prop', 'Шаблон, содержащий указанное свойство, является сервисным и не может быть изменен', '-', '3', 'pos_temp_prop_upd'), 
('pos_temp_upd_has_position_not_upd_prop_data', 'update', 'pos_temp_prop', 'Шаблон, содержащий указанное свойство, имеет позиции и не допускает изменения параметров определения: тип свойства, тип данных', '-', '3', 'pos_temp_prop_upd'), 
('prop_is_global_not_upd_global_data', 'update', 'pos_temp_prop', 'Указанное свойство шаблона является глобальным и не допускает изменения параметров определения: наименование, описание, тип свойства, тип данных', '-', '3', 'pos_temp_prop_upd'), 
('pos_temp_prop_upd_name_not_unique', 'update', 'pos_temp_prop', 'Указанное наименование свойства не уникально в пределах несущего шаблона или не допустимо', '-', '3', 'pos_temp_prop_upd'), 
('prop_type_not_found', 'update', 'pos_temp_prop', 'Указаный тип свойства не найден', '-', '7', 'pos_temp_prop_upd'), 
('none', 'update', 'pos_temp_prop', 'Неизвестная ошибка добавления определяющего свойства класса', '-', '3', 'pos_temp_prop_upd'), 
('none', 'update', 'pos_temp', 'Неизвестная ошибка обновления шаблона позиции', '-', '3', 'pos_temp_upd'), 
('pos_name_is_not_unique', 'insert', 'position', 'Наименование нарушает уникальность в пределах выбранного расположения позиции', '-', '3', 'position_add'), 
('pos_pos_temp_nesting_limit_violated', 'insert', 'position', 'Предлагаемое отношение шаблонов позиций нарушает ограничение на колличество позиций выбранного шаблона', '-', '6', 'position_add'), 
('none', 'insert', 'position', 'Неизвестная ошибка добавления позиции', '-', '3', 'position_add'), 
('pos_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_changelock'), 
('pos_has_freeze_object', 'update', 'position', 'Указанная позиция или дочерние позиции содержит замороженные объекты', '-', '3', 'position_changelock'), 
('none', 'update', 'position', 'Неизвестная ошибка изменения блокировки позиции позиции', '-', '3', 'position_changelock'), 
('tpos_pattern_not_found', 'copy', 'position', 'Шаблон копируемой позиции не найден', '-', '1', 'position_copy'), 
('tpos_target_not_found', 'copy', 'position', 'Шаблон целевой позиции не найден', '-', '1', 'position_copy'), 
('position_carrier_not_found', 'insert', 'object_prop_user_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_user_big_val_objects_set'), 
('position_carrier_not_found', 'delete', 'object_prop_enum_val', 'Объект, содержащий указанное свойство, не найден', '-', '1', 'position_prop_enum_val_del'), 
('position_prop_not_found', 'delete', 'object_prop_enum_val', 'Указанное свойство объекта не найдено', '-', '1', 'position_prop_enum_val_del'), 
('ppos_not_found', 'copy', 'position', 'Целевая позиция не найдена', '-', '1', 'position_copy'), 
('pos_pattern_not_found', 'copy', 'position', 'Копируемая позиция не найдена', '-', '1', 'position_copy'), 
('iid_parent_out_of_range', 'insert', 'position', 'Идентификатор целевой позиции за пределом допустимых значений', 'iid_parent имет отрицетельное значение или вышел за диапазон типа', '9', 'position_add'), 
('pos_pattern_enters_pos_target', 'copy', 'position', 'Копируемая позиция входит в выбранное расположение', 'Циклические ссылки запрещены', '4', 'position_copy'), 
('ppos_not_found', 'insert', 'position', 'Целевая позиция не найдена', '-', '1', 'position_add'), 
('pos_pattern_in_recycle', 'copy', 'position', 'Копируемая позиция находится в корзине', '-', '3', 'position_copy'), 
('ppos_in_recycle', 'insert', 'position', 'Целевая позиция находится в корзине', '-', '4', 'position_add'), 
('tpos_is_service', 'update', 'pos_temp', 'Выбранный шаблон позиции является сервисным', '-', '3', 'pos_temp_upd'), 
('pos_target_in_recycle', 'copy', 'position', 'Целевая позиция находится в корзине', 'Копирование в сервисные позиции не допускается', '1', 'position_copy'), 
('tpos_name_not_unique', 'update', 'pos_temp', 'Наименование шаблона позиции используется', '-', '2', 'pos_temp_upd'), 
('pos_recycle_not_found', 'insert', 'position', 'Корзина концепции не найдена', '-', '1', 'position_add'), 
('conception_not_match', 'insert', 'position', 'Шаблоны родительской и создаваемой позиций принадлеать разным концепциям', '-', '3', 'position_add'), 
('tpos_not_found', 'update', 'pos_temp', 'Выбранный шаблон позиции не найден', '-', '1', 'pos_temp_upd'), 
('none', 'move', 'position', 'Неизвестная ошибка переноса позиции', '-', '3', 'position_move'), 
('pos_name_is_empty', 'insert', 'position', 'Выбранное наименование слишком короткое', '-', '3', 'position_add'), 
('tpos_name_is_empty', 'update', 'pos_temp', 'Выбранное наименование слишком короткое', '-', '3', 'pos_temp_upd'), 
('position_prop_not_enum_type', 'delete', 'object_prop_enum_val', 'Указанное свойство объекта не является перечислением', '-', '3', 'position_prop_enum_val_del'), 
('position_carrier_not_on_object', 'insert', 'object_prop_user_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_user_big_val_objects_set'), 
('position_carrier_on_recycle', 'insert', 'object_prop_user_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_user_big_val_objects_set'), 
('class_prop_not_found', 'insert', 'object_prop_user_val', 'Указанное свойство объекта не найдено', '-', '1', 'object_prop_user_big_val_objects_set'), 
('class_prop_type_not_user', 'insert', 'object_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'object_prop_user_big_val_objects_set'), 
('class_prop_not_override', 'insert', 'object_prop_user_val', 'Указанное свойство наследовано от выше стоящего класса как не переопределяемое по значению в объекте', '-', '3', 'object_prop_user_big_val_objects_set'), 
('class_prop_not_prop_user', 'insert', 'class_prop_user_val', 'Указанное свойство класса не является пользовательским', '-', '3', 'class_prop_user_big_val_set'), 
('object_prop_user_val_out_of_min', 'insert', 'object_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'object_prop_user_big_val_objects_set'), 
('object_prop_user_val_out_of_max', 'insert', 'object_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'object_prop_user_big_val_objects_set'), 
('none', 'insert', 'object_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'object_prop_user_big_val_objects_set'), 
('class_prop_big_val_not_found', 'insert', 'object_prop_user_val', 'Данные значения пользовательского свойства объекта не найдены', '-', '7', 'object_prop_user_big_val_objects_set'), 
('class_prop_not_has_object_prop_override', 'insert', 'object_prop_user_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах, переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_user_big_val_objects_set'), 
('class_prop_not_found', 'insert', 'class_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'class_prop_user_big_val_set'), 
('none', 'delete', 'object_prop_enum_val', 'Неизвестная ошибка удаления данных значения свойства объекта', '-', '3', 'position_prop_enum_val_del'), 
('position_prop_not_override', 'delete', 'object_prop_enum_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'position_prop_enum_val_del'), 
('position_carrier_not_found', 'insert', 'position_prop_enum_val', 'Позиция носитель указанного свойства шаблона не найдена', '-', '7', 'position_prop_enum_val_set'), 
('pos_temp_prop_not_found', 'insert', 'position_prop_enum_val', 'Указанное свойство шаблона не найдена', '-', '7', 'position_prop_enum_val_set'), 
('pos_temp_prop_not_enum_type', 'insert', 'position_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'position_prop_enum_val_set'), 
('pos_temp_prop_enum_val_not_found', 'insert', 'position_prop_enum_val', 'Данные значения свойства шаблона не найдены', '-', '1', 'position_prop_enum_val_set'), 
('pos_temp_prop_not_override', 'insert', 'position_prop_enum_val', 'Свойство шаблона объявлено как не переопределяемое по значению в позициях', '-', '3', 'position_prop_enum_val_set'), 
('prop_enum_val_not_found', 'insert', 'position_prop_enum_val', 'Указанный элемент перечисления не найден', '-', '1', 'position_prop_enum_val_set'), 
('prop_enum_not_match', 'insert', 'position_prop_enum_val', 'Перечисление значения свойства шаблона и перечисления указанного элемента не совпадают', '-', '3', 'position_prop_enum_val_set'), 
('none', 'insert', 'position_prop_enum_val', 'Неизвестная ошибка присвоения значения свойства перечисления', '-', '3', 'position_prop_enum_val_set'), 
('position_carrier_not_found', 'delete', 'position_prop_link_val', 'Позиция, содержащая указанное свойство, не найдена', '-', '1', 'position_prop_link_val_del'), 
('pos_temp_prop_not_found', 'delete', 'position_prop_link_val', 'Указанное свойство позиции не найдено', '-', '1', 'position_prop_link_val_del'), 
('pos_temp_prop_not_link_type', 'delete', 'position_prop_link_val', 'Указанное свойство шаблона не является перечислением', '-', '3', 'position_prop_link_val_del'), 
('pos_temp_prop_not_override', 'delete', 'position_prop_link_val', 'Свойство шаблона объявлено как не переопределяемое по значению в позициях', '-', '3', 'position_prop_link_val_del'), 
('none', 'delete', 'position_prop_link_val', 'Неизвестная ошибка удаления данных значения свойства позиции', '-', '3', 'position_prop_link_val_del'), 
('position_prop_not_found', 'insert', 'position_prop_link_val', 'Указанное свойство класса не найдено', '-', '7', 'position_prop_link_val_set'), 
('position_carrier_not_found', 'insert', 'position_prop_link_val', 'Объект носитель указанного свойства класса не найден', '-', '7', 'position_prop_link_val_set'), 
('position_prop_not_link_type', 'insert', 'position_prop_link_val', 'Указанное свойство не является ссылкой', '-', '3', 'position_prop_link_val_set'), 
('pos_temp_prop_link_val_not_found', 'insert', 'position_prop_link_val', 'Данные значения свойства класса не найдены', '-', '1', 'position_prop_link_val_set'), 
('pos_temp_prop_not_override', 'insert', 'position_prop_link_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'position_prop_link_val_set'), 
('entity_instance_not_found', 'insert', 'position_prop_link_val', 'Указанный экземпляр сущности не найден', '-', '1', 'position_prop_link_val_set'), 
('conception_not_match', 'insert', 'position_prop_link_val', 'Концепции объекта и указанного экземпляра сущности не совпадают', '-', '3', 'position_prop_link_val_set'), 
('none', 'insert', 'position_prop_link_val', 'Неизвестная ошибка присвоения значения свойства ссылки', '-', '3', 'position_prop_link_val_set'), 
('class_prop_type_not_user', 'insert', 'object_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'object_prop_user_big_val_set'), 
('object_prop_user_val_out_of_min', 'insert', 'object_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'object_prop_user_big_val_set'), 
('object_prop_user_val_out_of_max', 'insert', 'object_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'object_prop_user_big_val_set'), 
('class_prop_not_override', 'insert', 'object_prop_user_val', 'Указанное свойство является не переопределяемым', '-', '3', 'object_prop_user_big_val_set'), 
('object_not_found', 'insert', 'object_prop_user_val', 'Указанный объект не найден', '-', '1', 'object_prop_user_big_val_set'), 
('position_carrier_not_found', 'delete', 'position_prop_user_val', 'Позиция носитель свойства не найдена', '-', '1', 'position_prop_user_val_del'), 
('pos_temp_prop_not_found', 'delete', 'position_prop_user_val', 'Указанное свойство шаблона не найдено', '-', '1', 'position_prop_user_val_del'), 
('pos_temp_prop_not_user_type', 'delete', 'position_prop_user_val', 'Указанное свойство шаблона не является перечислением', '-', '3', 'position_prop_user_val_del'), 
('pos_temp_prop_not_override', 'delete', 'position_prop_user_val', 'Свойство шаблона объявлено как не переопределяемое по значению в позициях', '-', '3', 'position_prop_user_val_del'), 
('eposition_upd_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_sort_bottom'), 
('item_upper_not_found_is_upper_limit', 'update', 'position', 'Указанный элемент в крайней верхней позиции', '-', '3', 'position_sort_bottom'), 
('eposition_upd_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_sort_down'), 
('item_upper_not_found_is_lower_limit', 'update', 'position', 'Указанный элемент в крайней нижней позиции', '-', '3', 'position_sort_down'), 
('item_upper_not_found_is_upper_limit', 'update', 'position', 'Указанный элемент в крайней верхней позиции', '-', '3', 'position_sort_top'), 
('eposition_upd_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_sort_top'), 
('none', 'update', 'position', 'Неизвестная ошибка удаления позиции', '-', '3', 'position_upd'), 
('pos_name_is_not_unique', 'update', 'position', 'Наименование нарушает уникальность в пределах выбранного расположения позиции', '-', '3', 'position_upd'), 
('conception_not_found', 'insert', 'prop_enum', 'Указанная концепция не найдена', '-', '7', 'prop_enum_add'), 
('use_area_not_valid', 'insert', 'prop_enum', 'Переданное значение области применения концепции не найдено', '-', '3', 'prop_enum_add'), 
('data_type_not_valid', 'insert', 'prop_enum', 'Указанный тип данных не допустим для перечислений', '-', '3', 'prop_enum_add'), 
('enum_name_not_unique', 'insert', 'prop_enum', 'Указанное наименование перечисления не является уникальным в текущей концепции', '-', '3', 'prop_enum_add'), 
('none', 'insert', 'prop_enum', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_add'), 
('prop_enum_not_found', 'copy', 'prop_enum', 'Указанное перечисление не найдено', '-', '1', 'prop_enum_copy_to'), 
('prop_enum_copy_to_current_location', 'copy', 'prop_enum', 'Для копирования указано текущее расположение перечисления', '-', '3', 'prop_enum_copy_to'), 
('enum_name_not_unique', 'copy', 'prop_enum', 'Наименование копируемого перечисления занято в целевой концепции', '-', '3', 'prop_enum_copy_to'), 
('none', 'copy', 'prop_enum', 'Неизвестная ошибка при копировании перечисления', '-', '3', 'prop_enum_copy_to'), 
('conception_not_found', 'copy', 'prop_enum', 'Целевая концепция не найдена', '-', '1', 'prop_enum_copy_to'), 
('conception_not_match', 'delete', 'prop_enum', 'Концепция удаляемого перечисления и переданного контрольного значения не совпадают', '-', '3', 'prop_enum_del'), 
('enum_delete_not_allowed', 'delete', 'prop_enum', 'Указанное перечисление используется, удаление недопустимо', '-', '3', 'prop_enum_del'), 
('none', 'delete', 'prop_enum', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_del'), 
('none', 'update', 'prop_enum', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_upd'), 
('conception_not_match', 'update', 'prop_enum', 'Концепция редактируемого перечисления и переданного контрольного значения не совпадают', '-', '3', 'prop_enum_upd'), 
('data_type_change_not_allowed', 'update', 'prop_enum', 'Редактируемое перечисление содержит перечисляемые элементы, изменение типа данных недопустимо', '-', '3', 'prop_enum_upd'), 
('pos_is_pos_recycle', 'update', 'position', 'Выбранная позиция является корзиной', '-', '3', 'position_upd'), 
('pos_not_found', 'update', 'position', 'Выбранная позиция не найдена', '-', '1', 'position_upd'), 
('pos_in_pos_recycle_space', 'update', 'position', 'Выбранная позиция находится в корзине', '-', '3', 'position_upd'), 
('pos_recycle_not_found', 'update', 'position', 'Корзина концепции не найдена', '-', '1', 'position_upd'), 
('pos_name_is_empty', 'update', 'position', 'Выбранное наименование слишком короткое', '-', '3', 'position_upd'), 
('enum_name_is_empty', 'insert', 'prop_enum', 'Выбранное наименование слишком короткое', '-', '3', 'prop_enum_add'), 
('enum_change_not_allowed', 'update', 'prop_enum', 'Редактируемое перечисление используется, изменение недопустимо', '-', '3', 'prop_enum_upd'), 
('use_area_not_valid', 'update', 'prop_enum', 'Переданное значение области применения концепции не найдено', '-', '3', 'prop_enum_upd'), 
('data_type_not_valid', 'update', 'prop_enum', 'Указанный тип данных не допустим для перечислений', '-', '3', 'prop_enum_upd'), 
('enum_name_not_unique', 'update', 'prop_enum', 'Указанное наименование перечисления не является уникальным в текущей концепции', '-', '3', 'prop_enum_upd'), 
('prop_enum_not_found', 'insert', 'prop_enum_val', 'Указанное перечисление не найдено', '-', '7', 'prop_enum_val_add'), 
('enum_val_varchar_not_unique', 'insert', 'prop_enum_val', 'Переданное строковое значение не является уникальным для указанного перечисления', '-', '3', 'prop_enum_val_add'), 
('enum_val_varchar_out_max', 'insert', 'prop_enum_val', 'Переданное строковое значение больше минимально допустимого количества символов', '-', '3', 'prop_enum_val_add'), 
('enum_val_varchar_out_min', 'insert', 'prop_enum_val', 'Переданное строковое значение меньше минимально допустимого количества символов', '-', '3', 'prop_enum_val_add'), 
('enum_val_numeric_not_unique', 'insert', 'prop_enum_val', 'Переданное числовое значение не является уникальным для указанного перечисления', '-', '3', 'prop_enum_val_add'), 
('none', 'insert', 'prop_enum_val', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_val_add'), 
('prop_enum_not_found', 'delete', 'prop_enum_val', 'Указанное значение перечисления не найдено', '-', '7', 'prop_enum_val_del'), 
('none', 'delete', 'prop_enum_val', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_val_del'), 
('pos_temp_not_found', 'delete', 'pos_temp', 'Указанный шаблон позиции не найден', '-', '1', 'pos_temp_nested_exclude'), 
('pos_temp_is_service', 'delete', 'pos_temp', 'Указанный шаблон позиции является сервисным', '-', '3', 'pos_temp_nested_exclude'), 
('pos_temp_nested_rule_is_use', 'delete', 'pos_temp', 'Указанное правило вложенности белого списка шаблона позиций используется', '-', '3', 'pos_temp_nested_exclude'), 
('pos_temp_is_use', 'delete', 'pos_temp', 'Запрещено удалять или изменять правила вложенности для используемых шаблоном', '-', '3', 'pos_temp_nested_exclude_all'), 
('prop_enum_val_upd_not_found', 'update', 'prop_enum_val', 'Указанное свойство шаблона не найдено', '-', '1', 'prop_enum_val_sort_bottom'), 
('prop_enum_upd_not_found', 'update', 'prop_enum_val', 'Активный класс указанного свойства не найден', '-', '1', 'prop_enum_val_sort_bottom'), 
('prop_enum_data_type_not_allowed', 'update', 'prop_enum_val', 'Тип данных перечисления не допускает выполнение методов сортировки', '-', '3', 'prop_enum_val_sort_bottom'), 
('prop_enum_val_not_found_in_sort_list', 'update', 'prop_enum_val', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'prop_enum_val_sort_down'), 
('prop_enum_data_type_not_allowed', 'update', 'prop_enum_val', 'Тип данных перечисления не допускает выполнение методов сортировки', '-', '3', 'prop_enum_val_sort_down'), 
('prop_enum_val_upd_not_found', 'update', 'prop_enum_val', 'Указанное свойство шаблона не найдено', '-', '1', 'prop_enum_val_sort_down'), 
('prop_enum_upd_not_found', 'update', 'prop_enum_val', 'Активный класс указанного свойства не найден', '-', '1', 'prop_enum_val_sort_down'), 
('prop_enum_val_upd_not_found', 'update', 'prop_enum_val', 'Указанное значение перечисления не найдено', '-', '1', 'prop_enum_val_sort_top'), 
('prop_enum_upd_not_found', 'update', 'prop_enum_val', 'Указанное перечисление не найдено', '-', '1', 'prop_enum_val_sort_top'), 
('prop_enum_data_type_not_allowed', 'update', 'prop_enum_val', 'Тип данных перечисления не допускает выполнение методов сортировки', '-', '3', 'prop_enum_val_sort_top'), 
('prop_enum_data_type_not_allowed', 'update', 'prop_enum_val', 'Тип данных перечисления не допускает выполнение методов сортировки', '-', '3', 'prop_enum_val_sort_up'), 
('prop_enum_val_not_found_in_sort_list', 'update', 'prop_enum_val', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'prop_enum_val_sort_up'), 
('prop_enum_upd_not_found', 'update', 'prop_enum_val', 'Активный класс указанного свойства не найден', '-', '1', 'prop_enum_val_sort_up'), 
('prop_enum_val_upd_not_found', 'update', 'prop_enum_val', 'Указанное свойство шаблона не найдено', '-', '1', 'prop_enum_val_sort_up'), 
('prop_enum_not_found', 'update', 'prop_enum_val', 'Указанное значение перечисления не найдено', '-', '7', 'prop_enum_val_upd'), 
('prop_enum_val_is_use', 'update', 'prop_enum_val', 'Указанное значение перечисления используется', '-', '3', 'prop_enum_val_upd'), 
('enum_val_varchar_out_min', 'update', 'prop_enum_val', 'Переданное строковое значение меньше минимально допустимого количества символов', '-', '3', 'prop_enum_val_upd'), 
('enum_val_varchar_out_max', 'update', 'prop_enum_val', 'Переданное строковое значение больше минимально допустимого количества символов', '-', '3', 'prop_enum_val_upd'), 
('enum_val_varchar_not_unique', 'update', 'prop_enum_val', 'Переданное строковое значение не является уникальным для указанного перечисления', '-', '3', 'prop_enum_val_upd'), 
('enum_val_numeric_not_unique', 'update', 'prop_enum_val', 'Переданное числовое значение не является уникальным для указанного перечисления', '-', '3', 'prop_enum_val_upd'), 
('none', 'update', 'prop_enum_val', 'Неизвестная ошибка при изменении перечисления', '-', '3', 'prop_enum_val_upd'), 
('class_rule_not_found', 'insert', 'rulel1_class_on_pos_temp', 'Указанный класс не найден', '-', '7', 'rulel1_class_on_pos_temp_add'), 
('pos_temp_rule_not_found', 'insert', 'rulel1_class_on_pos_temp', 'Указанный шаблон позиции не найден', '-', '7', 'rulel1_class_on_pos_temp_add'), 
('pos_prototype_rule_not_found', 'insert', 'rulel1_class_on_pos_temp', 'Указанный прототип шаблона позиции не найден', '-', '7', 'rulel1_class_on_pos_temp_add'), 
('pos_prototype_rule_not_on_obj', 'insert', 'rulel1_class_on_pos_temp', 'Прототип шаблона позиции не допускает вложения объектов', '-', '3', 'rulel1_class_on_pos_temp_add'), 
('conception_not_match', 'insert', 'rulel1_class_on_pos_temp', 'Концепция класса и шаблона позиции не совпадают', '-', '3', 'rulel1_class_on_pos_temp_add'), 
('class_in_recycle_space', 'insert', 'rulel1_class_on_pos_temp', 'Указанная группа входит в пространство корзины', '-', '3', 'rulel1_class_on_pos_temp_add'), 
('class_include_in_rule_list', 'insert', 'rulel1_class_on_pos_temp', 'Определяемое правило найдено в таблице разрешений шаблона позиций', '-', '3', 'rulel1_class_on_pos_temp_add'), 
('none', 'insert', 'rulel1_class_on_pos_temp', 'Неизвестная ошибка добавления правила', '-', '3', 'rulel1_class_on_pos_temp_add'), 
('rule1_not_found', 'delete', 'rulel1_class_on_pos_temp', 'Указанное правило вложенности объектов не найдено', '-', '7', 'rulel1_class_on_pos_temp_del'), 
('none', 'delete', 'rulel1_class_on_pos_temp', 'Неизвестная ошибка удаления правила', '-', '7', 'rulel1_class_on_pos_temp_del'), 
('group_rule_not_found', 'insert', 'rulel1_group_on_pos_temp', 'Указанная группа не найдена', '-', '7', 'rulel1_group_on_pos_temp_add'), 
('pos_temp_rule_not_found', 'insert', 'rulel1_group_on_pos_temp', 'Указанный шаблон позиции не найден', '-', '7', 'rulel1_group_on_pos_temp_add'), 
('pos_prototype_rule_not_found', 'insert', 'rulel1_group_on_pos_temp', 'Указанный прототип шаблона позиции не найден', '-', '7', 'rulel1_group_on_pos_temp_add'), 
('conception_not_match', 'insert', 'rulel1_group_on_pos_temp', 'Концепция группы и шаблона позиции не совпадают', '-', '3', 'rulel1_group_on_pos_temp_add'), 
('pos_prototype_rule_not_on_obj', 'insert', 'rulel1_group_on_pos_temp', 'Прототип шаблона позиции не допускает вложения объектов', '-', '3', 'rulel1_group_on_pos_temp_add'), 
('group_in_recycle_space', 'insert', 'rulel1_group_on_pos_temp', 'Указанная группа входит в пространство корзины', '-', '3', 'rulel1_group_on_pos_temp_add'), 
('group_include_in_rule_list', 'insert', 'rulel1_group_on_pos_temp', 'Определяемое правило найдено в таблице разрешений шаблона позиций', '-', '3', 'rulel1_group_on_pos_temp_add'), 
('none', 'insert', 'rulel1_group_on_pos_temp', 'Неизвестная ошибка добавления правила', '-', '3', 'rulel1_group_on_pos_temp_add'), 
('rule1_not_found', 'delete', 'rulel1_group_on_pos_temp', 'Указанное правило вложенности объектов не найдено', '-', '7', 'rulel1_group_on_pos_temp_del'), 
('none', 'delete', 'rulel1_group_on_pos_temp', 'Неизвестная ошибка удаления правила', '-', '3', 'rulel1_group_on_pos_temp_del'), 
('object_not_found', 'insert', 'object_prop_user_val', 'Указанный объект не найден', '-', '1', 'object_prop_user_small_val_set'), 
('class_prop_not_found', 'insert', 'object_prop_user_val', 'Указанное свойство объекта не найдено', '-', '1', 'object_prop_user_small_val_set'), 
('class_prop_not_override', 'insert', 'object_prop_user_val', 'Указанное свойство наследовано от выше стоящего класса как не переопределяемое по значению в объекте', '-', '1', 'object_prop_user_small_val_set'), 
('class_prop_type_not_user', 'insert', 'object_prop_user_val', 'Указанное свойство не является пользовательским', '-', '1', 'object_prop_user_small_val_set'), 
('unit_not_found', 'insert', 'unit_conversion_rule', 'Измеряемая величина не найдена', '-', '1', 'unit_conversion_rule_add'), 
('conception_not_found', 'insert', 'unit_conversion_rule', 'Указанная концепция не найдена', '-', '1', 'unit_conversion_rule_add'), 
('unit_is_undefined', 'insert', 'unit_conversion_rule', 'Неопределенная величина не допускает создания правил пересчета', '-', '3', 'unit_conversion_rule_add'), 
('unit_conversion_rule_mc_is_null', 'insert', 'unit_conversion_rule', 'Коэффициент пересчета mc не может быть отрицательной величиной', '-', '3', 'unit_conversion_rule_add'), 
('unit_conversion_rule_round_is_null', 'insert', 'unit_conversion_rule', 'Масштаб округления не может быть отрицательной величиной', '-', '3', 'unit_conversion_rule_add'), 
('unit_conversion_rule_is_single_or_not_fractional', 'insert', 'unit_conversion_rule', 'Недопустимое значение round для правила пересчета не допускающего дробных значений или правил учета объектных агрегатов', '-', '3', 'unit_conversion_rule_add'), 
('none', 'insert', 'unit_conversion_rule', 'Неизвестная ошибка добавления правила пересчета', '-', '3', 'unit_conversion_rule_add'), 
('none', 'delete', 'unit_conversion_rule', 'Неизвестная ошибка удаления правила пересчета', '-', '3', 'unit_conversion_rule_del'), 
('unit_not_found', 'update', 'unit_conversion_rule', 'Измеряемая величина выбранного правила не найдена', '-', '1', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_mc_is_null', 'update', 'unit_conversion_rule', 'Коэффициент пересчета mc не может быть отрицательной величиной', '-', '3', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_round_is_null', 'update', 'unit_conversion_rule', 'Масштаб округления не может быть отрицательной величиной', '-', '3', 'unit_conversion_rule_upd'), 
('class_prop_small_val_not_found', 'insert', 'object_prop_user_val', 'Данные значения пользовательского свойства объекта не найдены', '-', '7', 'object_prop_user_small_val_set'), 
('unit_conversion_rule_is_single_or_not_fractional', 'update', 'unit_conversion_rule', 'Недопустимое значение round для правила пересчета не допускающего дробных значений или правил учета объектных агрегатов', '-', '3', 'unit_conversion_rule_upd'), 
('object_prop_user_val_out_of_max', 'insert', 'object_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'object_prop_user_small_val_set'), 
('rolname_role_user_not_found', 'insert', 'role_user', 'Системная роль роли пользователя не найдена', '-', '1', 'user_role_user_grant'), 
('unit_conversion_rule_is_use_in_class', 'update', 'unit_conversion_rule', 'Указанное правило пересчета  используется в классах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_is_use_in_class', 'delete', 'unit_conversion_rule', 'Указанное правило пересчета  используется в классах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_del'), 
('unit_conversion_rule_is_base', 'update', 'unit_conversion_rule', 'Указанное правило пересчета  является базовым', 'Базовые правила пересчета не могут быть удалены или модифицированы. При необходимости их изменения можно создать дополнительное правило с неабходимыми параметрами.', '3', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_not_found', 'delete', 'unit_conversion_rule', 'Указанное правило пересчета не найдено', '-', '1', 'unit_conversion_rule_del'), 
('unit_conversion_rule_not_found', 'update', 'unit_conversion_rule', 'Указанное правило пересчета не найдено', '-', '1', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_from_aggobject_is_single_only', 'insert', 'unit_conversion_rule', 'Недопустимое значение on_single для правила пересчета объектных агрегатов', 'Правила учета объектных агрегатов не могут иметь значения количества отличные от одной единицы', '3', 'unit_conversion_rule_add'), 
('unit_conversion_rule_is_single_only', 'insert', 'unit_conversion_rule', 'Недопустимое значение mc для единичного правила пересчета', 'Правила единичного учета не могут иметь значения количества отличные от одной единицы', '3', 'unit_conversion_rule_add'), 
('none', 'update', 'unit_conversion_rule', 'Неизвестная ошибка изменения правила пересчета', '-', '3', 'unit_conversion_rule_upd'), 
('session_user_not_admin', 'insert', 'user', 'Создание/редактирование учетных записей доступно только пользователям группы администраторы', '-', '3', 'user_add'), 
('session_user_not_rolsuper', 'insert', 'user', 'Создание/редактирование учетных записей доступно только суперпользователям группы администраторы', '-', '3', 'user_add'), 
('none', 'insert', 'user', 'Неизвестная ошибка добавления пользователя', '-', '3', 'user_add'), 
('none', 'delete', 'user', 'Неизвестная ошибка удаления пользователя', '-', '3', 'user_del'), 
('session_user_not_admin', 'delete', 'user', 'Удаление учетных записей доступно только пользователям группы администраторы', '-', '3', 'user_del'), 
('user_login_has_member', 'delete', 'user', 'Указанный пользователь имеет включенных членов группы', '-', '3', 'user_del'), 
('user_login_not_found', 'delete', 'user', 'Указанный пользователь не найден', '-', '1', 'user_del'), 
('usr_login_not_found', 'update', 'user', 'Указанный пользователь не найден', '-', '1', 'user_pwd_reset'), 
('newpwd_do_not_match', 'update', 'user', 'Новые значения паролей не совпадают', '-', '3', 'user_pwd_reset'), 
('session_user_not_member_of_bdu_administrators', 'update', 'user', 'Сброс пароля запрещен, обратитесь к администратору', '-', '3', 'user_pwd_reset'), 
('none', 'update', 'user', 'Неизвестная ошибка изменения пароля', '-', '3', 'user_pwd_reset'), 
('newpwd_do_not_match', 'update', 'user', 'Новые значения паролей не совпадают', '-', '3', 'user_pwd_set'), 
('oldpwd_not_valide', 'update', 'user', 'Текущий пароль указан неверно', '-', '3', 'user_pwd_set'), 
('none', 'update', 'user', 'Неизвестная ошибка изменения пароля', '-', '3', 'user_pwd_set'), 
('role_user_not_found', 'insert', 'role_user', 'Роль пользователя не найдена', '-', '1', 'user_role_base_grant'), 
('role_base_not_found', 'insert', 'role_user', 'Базовая роль не найдена', '-', '1', 'user_role_base_grant'), 
('rolname_role_user_not_found', 'insert', 'role_user', 'Системная роль роли пользователя не найдена', '-', '1', 'user_role_base_grant'), 
('rolname_role_base_not_found', 'insert', 'role_user', 'Системная роль базовой роли пользователя не найдена', '-', '1', 'user_role_base_grant'), 
('session_user_not_admin', 'insert', 'role_user', 'Назначение прав учетным записям пользователей доступно только пользователям группы администраторы', '-', '3', 'user_role_base_grant'), 
('role_base_grant_to_role_user', 'insert', 'role_user', 'Базовая роль предоставлена для роли другого пользователя', '-', '3', 'user_role_base_grant'), 
('none', 'insert', 'role_user', 'Неизвестная ошибка назначения базовой роли', '-', '3', 'user_role_base_grant'), 
('none', 'insert', 'role_user', 'Неизвестная ошибка исключения пользователя из роли', '-', '3', 'user_role_base_revoke'), 
('session_user_not_admin', 'insert', 'role_user', 'Назначение прав учетным записям пользователей доступно только пользователям группы администраторы', '-', '3', 'user_role_base_revoke'), 
('role_base_revoke_to_role_user', 'insert', 'role_user', 'Базовая роль не предоставлена для роли этого пользователя', '-', '3', 'user_role_base_revoke'), 
('user_not_found', 'insert', 'role_user', 'Пользователь не найден', '-', '1', 'user_role_base_revoke'), 
('role_user_not_found', 'insert', 'role_user', 'Роль пользователя не найдена', '-', '1', 'user_role_base_revoke'), 
('rolname_user_not_found', 'insert', 'role_user', 'Системная роль пользователя не найдена', '-', '1', 'user_role_base_revoke'), 
('rolname_role_user_not_found', 'insert', 'role_user', 'Системная роль роли пользователя не найдена', '-', '1', 'user_role_base_revoke'), 
('session_user_not_admin', 'insert', 'role_user', 'Создание/редактирование учетных записей доступно только пользователям группы администраторы', '-', '3', 'user_role_user_add'), 
('role_system_name_not_unique', 'insert', 'role_user', 'Указанное системное имя роли не является уникальным', '-', '3', 'user_role_user_add'), 
('role_user_name_not_unique', 'insert', 'role_user', 'Указанное пользовательское имя роли не является уникальным', '-', '3', 'user_role_user_add'), 
('none', 'delete', 'role_user', 'Неизвестная ошибка удаления роли пользователя', '-', '3', 'user_role_user_del'), 
('session_user_not_admin', 'delete', 'role_user', 'Управление учетными записями доступно только пользователям группы администраторы', '-', '3', 'user_role_user_del'), 
('role_user_has_member', 'delete', 'role_user', 'Указанная роль пользователя имеет активных членов', '-', '3', 'user_role_user_del'), 
('role_user_not_found', 'delete', 'role_user', 'Указанная роль пользователя не найдена', '-', '1', 'user_role_user_del'), 
('user_not_found', 'insert', 'role_user', 'Пользователь не найден', '-', '1', 'user_role_user_grant'), 
('role_user_not_found', 'insert', 'role_user', 'Роль пользователя не найдена', '-', '1', 'user_role_user_grant'), 
('rolname_user_not_found', 'insert', 'role_user', 'Системная роль пользователя не найдена', '-', '1', 'user_role_user_grant'), 
('usr_login_not_found', 'update', 'user', 'Указанный пользователь не найден', '-', '1', 'user_pwd_set'), 
('none', 'insert', 'role_user', 'Неизвестная ошибка добавления роли пользователя', '-', '3', 'user_role_user_add'), 
('object_prop_user_val_out_of_min', 'insert', 'object_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'object_prop_user_small_val_set'), 
('position_carrier_not_found', 'insert', 'object_prop_user_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_user_small_val_objects_set'), 
('position_carrier_not_on_object', 'insert', 'object_prop_user_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_user_small_val_objects_set'), 
('position_carrier_on_recycle', 'insert', 'object_prop_user_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_user_small_val_objects_set'), 
('class_prop_type_not_user', 'insert', 'object_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'object_prop_user_small_val_objects_set'), 
('class_prop_not_found', 'insert', 'object_prop_user_val', 'Указанное свойство объекта не найдено', '-', '1', 'object_prop_user_small_val_objects_set'), 
('class_prop_not_override', 'insert', 'object_prop_user_val', 'Указанное свойство наследовано от выше стоящего класса как не переопределяемое по значению в объекте', '-', '3', 'object_prop_user_small_val_objects_set'), 
('class_prop_small_val_not_found', 'insert', 'object_prop_user_val', 'Данные значения пользовательского свойства объекта не найдены', '-', '7', 'object_prop_user_small_val_objects_set'), 
('object_prop_user_val_out_of_max', 'insert', 'object_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'object_prop_user_small_val_objects_set'), 
('object_prop_user_val_out_of_min', 'insert', 'object_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'object_prop_user_small_val_objects_set'), 
('none', 'insert', 'object_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'object_prop_user_small_val_objects_set'), 
('none', 'insert', 'object_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'object_prop_user_small_val_set'), 
('class_prop_override_not_valid', 'insert', 'class_prop', 'Объектное свойство вещественного класса не может быть переопределяемым', '-', '3', 'class_prop_add_as_global_prop'), 
('class_prop_not_has_object_prop_override', 'insert', 'object_prop_user_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах, переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_user_small_val_objects_set'), 
('object_carrier_not_found', 'delete', 'object_prop_user_val', 'Объект содержащий указанное свойство не найден', '-', '1', 'object_prop_user_val_del'), 
('class_prop_not_found', 'delete', 'object_prop_user_val', 'Указанное свойство объекта не найдено', '-', '1', 'object_prop_user_val_del'), 
('class_prop_not_user_type', 'delete', 'object_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'object_prop_user_val_del'), 
('class_prop_not_override', 'delete', 'object_prop_user_val', 'Указанное свойство наследовано от выше стоящего класса как не переопределяемое по значению в объекте', '-', '3', 'object_prop_user_val_del'), 
('none', 'delete', 'object_prop_user_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'object_prop_user_val_del'), 
('role_user_grant_to_user', 'insert', 'role_user', 'Роль пользователя предоставлена другому пользователю', '-', '3', 'user_role_user_grant'), 
('session_user_not_admin', 'insert', 'role_user', 'Назначение прав учетным записям пользователей доступно только пользователям группы администраторы', '-', '3', 'user_role_user_grant'), 
('none', 'insert', 'role_user', 'Неизвестная ошибка включения пользователя в роль', '-', '3', 'user_role_user_grant'), 
('none', 'insert', 'role_user', 'Неизвестная ошибка исключения пользователя из роли', '-', '3', 'user_role_user_revoke'), 
('pos_is_recycle', 'delete', 'position', 'Выбранная позиция является корзиной', '-', '3', 'position_del'), 
('session_user_not_admin', 'insert', 'role_user', 'Назначение прав учетным записям пользователей доступно только пользователям группы администраторы', '-', '3', 'user_role_user_revoke'), 
('role_user_revoke_to_user', 'insert', 'role_user', 'Роль пользователя не предоставлена этому пользователю', '-', '3', 'user_role_user_revoke'), 
('user_not_found', 'insert', 'role_user', 'Пользователь не найден', '-', '1', 'user_role_user_revoke'), 
('role_user_not_found', 'insert', 'role_user', 'Роль пользователя не найдена', '-', '1', 'user_role_user_revoke'), 
('rolname_user_not_found', 'insert', 'role_user', 'Системная роль пользователя не найдена', '-', '1', 'user_role_user_revoke'), 
('rolname_role_user_not_found', 'insert', 'role_user', 'Системная роль роли пользователя не найдена', '-', '1', 'user_role_user_revoke'), 
('role_user_not_found', 'update', 'role_user', 'Роль пользователя не найдена', '-', '1', 'user_role_user_upd'), 
('session_user_not_admin', 'update', 'role_user', 'Создание/редактирование ролей пользователей доступно только пользователям группы администраторы', '-', '3', 'user_role_user_upd'), 
('role_user_newname_not_unique', 'update', 'role_user', 'Указанное отображаемое имя роли пользователя не является уникальным', '-', '3', 'user_role_user_upd'), 
('role_user_newnamesys_not_unique', 'update', 'role_user', 'Указанное системное имя роли пользователя не является уникальным', '-', '3', 'user_role_user_upd'), 
('none', 'update', 'role_user', 'Неизвестная ошибка обновления роли пользователя', '-', '3', 'user_role_user_upd'), 
('none', 'update', 'user', 'Неизвестная ошибка обновления пользователя', '-', '3', 'user_upd'), 
('session_user_not_admin_and_not_self_update', 'update', 'user', 'Создание/редактирование учетных записей доступно только пользователям группы администраторы', '-', '3', 'user_upd'), 
('session_user_not_rolsuper', 'update', 'user', 'Создание/редактирование учетных записей доступно только суперпользователям группы администраторы', '-', '3', 'user_upd'), 
('user_login_not_found', 'update', 'user', 'Пользователь не найден', '-', '1', 'user_upd'), 
('barcode_manufacturer_not_volidation', 'update', 'class', 'Передан недействительный штрих-код производителя', '-', '1', 'class_upd'), 
('bquantity_max_less_min', 'insert', 'class_prop_object_val', 'В параметрах значения объектного свойства отношение минимального, максимального количества объектов определено не корректно', '-', '3', 'class_prop_object_val_set'), 
('class_carrier_include_branch_class_val', 'insert', 'class_prop_object_val', 'Класс-носитель свойства входит в ветвь класса значения свойства', '-', '3', 'class_prop_object_val_set'), 
('class_carrier_not_found', 'insert', 'class_prop_enum_val', 'Класс-носитель указанного свойства не найден', '-', '1', 'class_prop_enum_val_set'), 
('class_carrier_not_found', 'insert', 'class_prop_link_val', 'Класс-носитель указанного свойства не найден', '-', '1', 'class_prop_link_val_set'), 
('class_carrier_not_found', 'insert', 'class_prop_user_val', 'Класс-носитель указанного свойства не найден', 'Возможно повреждение метаданных концепции', '1', 'class_prop_user_big_val_set'), 
('class_carrier_not_found', 'insert', 'class_prop_user_val', 'Класс-носитель указанного свойства не найден', '-', '3', 'class_prop_user_small_val_set'), 
('class_cast_not_found', 'cast', 'object', 'Целевой снимок класса не найден', '-', '7', 'object_cast'), 
('class_del_on_freeze', 'delete', 'class', 'Указанный класс заблокирован и не может быть удален', '-', '1', 'class_del'), 
('class_inherited_not_extensible', 'copy', 'class', 'Наследуемый класс целевого класса объявлен как нерасширяемый и не допускает операции вставки при копировании и переносе классов', '-', '3', 'class_copy_to_class'), 
('class_parent_in_recycle_space', 'insert', 'class', 'Указанный родительский класс расположен в корзине концепции', '-', '3', 'class_add'), 
('class_parent_include_abstraction_class_not_converted_to_real', 'update', 'class', 'Родительский класс, указанного класса , содержит абстрактные классы и не допускает вложения вещественных классов', '-', '3', 'class_upd'), 
('class_parent_include_real_class_not_converted_to_abstraction', 'update', 'class', 'Родительский класс, указанного класса, содержит вещественные классы и не допускает вложения абстрактных классов', '-', '3', 'class_upd'), 
('class_parent_not_extensible', 'insert', 'class', 'Родительский класс объявлен как нерасширяемый и не допускает объявления расширяемых классов', 'Создаваемый класс должен быть объявлен как не расширяемый', '3', 'class_add'), 
('usr_newlogin_not_unique', 'update', 'user', 'Указанный новый логин пользователя используется', '-', '3', 'user_upd'), 
('class_parent_not_include_real_class', 'insert', 'class', 'Указанный родительский класс содержит абстрактные классы и не допускает вложения вещественных классов', '-', '3', 'class_add'), 
('class_parent_unit_is_undefined', 'insert', 'class', 'Указанный родительский класс имеет неопределенную измеряемую величиину и не допускает вложения вещественных классов', 'Вещественные классы не могут наследовать неопределенную измеряемую величину. Необходимо определить измеряемую величину в абстрактном родительском классе', '3', 'class_add'), 
('class_parent_unit_is_undefined', 'copy', 'class', 'Указанный родительский класс имеет неопределенную измеряемую величиину и не допускает вложения вещественных классов', '-', '3', 'class_copy_to_class'), 
('class_pattern_in_recycle_space', 'copy', 'class', 'Указанная целевая группа находится в корзине', '-', '3', 'class_copy_to_group'), 
('class_pattern_include_class_target', 'copy', 'class', 'Указанный копируемый класс включает класс-цель', '-', '3', 'class_copy_to_class'), 
('class_pattern_include_class_target', 'move', 'class', 'Указанный переносимый класс содержит класс-цель', 'Функция не допускает циклического вложения классов', '3', 'class_move_to_class'), 
('class_pattern_not_found', 'copy', 'class', 'Указанный копируемый класс не найден', '-', '3', 'class_copy_to_class'), 
('class_pattern_not_found', 'copy', 'class', 'Указанный копируемый класс не найден', '-', '7', 'class_copy_to_group'), 
('class_pattern_not_found', 'move', 'class', 'Указанный переносимый класс не найден', '-', '7', 'class_move_to_class'), 
('class_prop_not_override', 'delete', 'object_prop_enum_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_enum_val_objects_del'), 
('class_prop_not_override', 'insert', 'object_prop_enum_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_enum_val_objects_set'), 
('class_prop_not_override', 'delete', 'object_prop_link_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_link_val_objects_del'), 
('class_prop_not_override', 'insert', 'object_prop_link_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_link_val_objects_set'), 
('class_prop_not_override', 'insert', 'object_prop_link_val', 'Свойство объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_link_val_set'), 
('class_prop_not_found', 'delete', 'object_prop_user_val', 'Указанное свойство объекта не найдено', '-', '1', 'object_prop_user_val_objects_del'), 
('class_prop_not_override', 'delete', 'object_prop_user_val', 'Свойсвтво объекта объявлено как не переопределяемое по значению в объектах', '-', '3', 'object_prop_user_val_objects_del'), 
('class_prop_not_user_type', 'delete', 'object_prop_user_val', 'Указанное свойство объекта не является пользовательским', '-', '3', 'object_prop_user_val_objects_del'), 
('eclass_prop_not_has_object_prop_override', 'delete', 'object_prop_user_val', 'Указанное свойство не имеет наследующих свойств в вещественных классах переопределяемых по значению в объектах указанной позиции', '-', '3', 'object_prop_user_val_objects_del'), 
('none', 'delete', 'object_prop_user_val', 'Неизвестная ошибка удаления значения свойства', '-', '3', 'object_prop_user_val_objects_del'), 
('position_carrier_in_recycle', 'delete', 'object_prop_user_val', 'Указанная позиция носитель удалена в корзину', '-', '3', 'object_prop_user_val_objects_del'), 
('position_carrier_not_found', 'delete', 'object_prop_user_val', 'Указанная позиция носитель не найдена', '-', '1', 'object_prop_user_val_objects_del'), 
('position_carrier_not_on_object', 'delete', 'object_prop_user_val', 'Указанная позиция носитель не допускает размещения объектов', '-', '3', 'object_prop_user_val_objects_del'), 
('pos_temp_prop_not_found', 'insert', 'pos_temp_prop_object_val', 'Указанное свойство не найдено', '-', '1', 'pos_temp_prop_object_val_set'), 
('pos_temp_carrier_not_found', 'delete', 'pos_temp_prop_enum_val', 'Шаблон носитель свойства не найден', '-', '1', 'pos_temp_prop_enum_val_del'), 
('class_prop_not_found', 'delete', 'object_prop_enum_val', 'Указанное свойство не найдено', '-', '7', 'object_prop_enum_val_del'), 
('none', 'delete', 'pos_temp_prop_enum_val', 'Неизвестная ошибка удаления значения свойства', '-', '1', 'pos_temp_prop_enum_val_del'), 
('pos_temp_prop_not_enum_type', 'delete', 'pos_temp_prop_enum_val', 'Указанное свойство не является перечислением', '-', '3', 'pos_temp_prop_enum_val_del'), 
('pos_temp_prop_not_found', 'delete', 'pos_temp_prop_enum_val', 'Неизвестная ошибка удаления значения свойства', '-', '1', 'pos_temp_prop_enum_val_del'), 
('pos_temp_prop_not_found', 'delete', 'pos_temp_prop_object_val', 'Указанное свойство не найдено', '-', '1', 'pos_temp_prop_object_val_del'), 
('doc_category_not_found', 'update', 'doc_category', 'Указанная категория документов не найдена', '-', '1', 'doc_category_upd'), 
('entity_not_found', 'insert', 'document', 'Указанная сущность не найдена', '-', '1', 'document_add'), 
('pos_temp_prop_not_found', 'insert', 'pos_temp_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_carrier_not_found', 'insert', 'pos_temp_prop_user_val', 'Шаблон-носитель указанного свойства не найден', '-', '1', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_prop_not_prop_user', 'insert', 'pos_temp_prop_user_val', 'Указанное свойство класса не является пользовательским', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_prop_val_spec_not_found', 'insert', 'pos_temp_prop_user_val', 'Спецификаторы значения указанного свойства не найдены', '-', '7', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_prop_user_val_not_found', 'insert', 'pos_temp_prop_user_val', 'Данные значения пользовательского свойства не найдены', '-', '7', 'pos_temp_prop_user_big_val_set'), 
('max_val_spec_state_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Ограничение максимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('tppos_temp_not_found', 'insert', 'position', 'Шаблон родительской позиции не найден', '-', '7', 'position_add'), 
('none', 'copy', 'position', 'Неизвестная ошибка копирования позиции', '-', '3', 'position_copy'), 
('pos_recycle_not_found', 'copy', 'position', 'Корзина концепции не найдена', '-', '1', 'position_copy'), 
('pos_recycle_not_found', 'move', 'position', 'Корзина концепции не найдена', '-', '1', 'position_move'), 
('max_val_spec_state_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Ограничение максимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('min_val_spec_state_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Ограничение минимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('min_val_spec_state_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Ограничение минимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_prop_user_val_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('pos_temp_prop_user_val_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('none', 'insert', 'pos_temp_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('none', 'insert', 'pos_temp_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_carrier_not_found', 'insert', 'pos_temp_prop_user_val', 'Шаблон-носитель указанного свойства не найден', '-', '1', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_not_found', 'insert', 'pos_temp_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_not_prop_user', 'insert', 'pos_temp_prop_user_val', 'Указанное свойство класса не является пользовательским', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_val_spec_not_found', 'insert', 'pos_temp_prop_user_val', 'Спецификаторы значения указанного свойства не найдены', '-', '7', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_user_val_not_found', 'insert', 'pos_temp_prop_user_val', 'Данные значения пользовательского свойства не найдены', '-', '7', 'pos_temp_prop_user_small_val_set'), 
('max_val_spec_state_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Ограничение максимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_big_val_set'), 
('max_val_spec_state_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Ограничение максимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('min_val_spec_state_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Ограничение минимального значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('min_val_spec_state_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Ограничение минимального значения выше верхней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('round_val_spec_state_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Точность округления значения выше верхней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('round_val_spec_state_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Точность округления значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_user_val_out_of_min', 'insert', 'pos_temp_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('pos_temp_prop_user_val_out_of_max', 'insert', 'pos_temp_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'pos_temp_prop_user_small_val_set'), 
('round_val_spec_state_out_of_max', 'insert', 'class_prop_user_val', 'Точность округления значения выше верхней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('log_link_not_found', 'delete', 'log_link', 'Указанная запись журнала не найдена', '-', '1', 'log_link_del_by_entity'), 
('none', 'insert', 'position_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'position_prop_user_big_val_set'), 
('position_not_found', 'insert', 'position_prop_user_val', 'Указанная позиция не найдена', '-', '1', 'position_prop_user_big_val_set'), 
('none', 'insert', 'object_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'object_prop_user_big_val_set'), 
('class_prop_not_found', 'insert', 'object_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'object_prop_user_big_val_set'), 
('pos_temp_prop_not_found', 'insert', 'position_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'position_prop_user_big_val_set'), 
('pos_temp_prop_not_override', 'insert', 'position_prop_user_val', 'Указанное свойство не является переопределяемым', '-', '3', 'position_prop_user_big_val_set'), 
('class_prop_user_val_not_found', 'insert', 'object_prop_user_val', 'Данные значения пользовательского свойства объекта не найдены', '-', '7', 'object_prop_user_big_val_set'), 
('pos_temp_prop_not_override', 'insert', 'position_prop_user_val', 'Указанное свойство не является переопределяемым', '-', '3', 'position_prop_user_small_val_set'), 
('pos_temp_prop_type_not_user', 'insert', 'position_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'position_prop_user_big_val_set'), 
('pos_temp_prop_not_found_in_sort_list', 'update', 'pos_temp_prop', 'Указанное свойство не найдено в списке сортировки', '-', '3', 'pos_temp_prop_sort_bottom'), 
('position_prop_user_val_out_of_max', 'insert', 'position_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'position_prop_user_big_val_set'), 
('ppos_not_found', 'insert', 'object', 'Целевая позиция не найдена', '-', '3', 'object_add'), 
('position_prop_user_val_out_of_min', 'insert', 'position_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'position_prop_user_big_val_set'), 
('none', 'insert', 'position_prop_user_val', 'Неизвестная ошибка измнения значения пользовательского свойства', '-', '3', 'position_prop_user_small_val_set'), 
('position_not_found', 'insert', 'position_prop_user_val', 'Указанная позиция не найдена', '-', '1', 'position_prop_user_small_val_set'), 
('pos_temp_prop_not_found', 'insert', 'position_prop_user_val', 'Указанное свойство не найдено', '-', '1', 'position_prop_user_small_val_set'), 
('pos_temp_prop_type_not_user', 'insert', 'position_prop_user_val', 'Указанное свойство не является пользовательским', '-', '3', 'position_prop_user_small_val_set'), 
('position_prop_user_val_not_found', 'insert', 'position_prop_user_val', 'Данные значения свойства не найдены', '-', '7', 'position_prop_user_big_val_set'), 
('position_prop_user_val_not_found', 'insert', 'position_prop_user_val', 'Данные значения свойства не найдены', '-', '3', 'position_prop_user_small_val_set'), 
('position_prop_user_val_out_of_min', 'insert', 'position_prop_user_val', 'Значение свойства ниже меньшей границы диапазона значений', '-', '3', 'position_prop_user_small_val_set'), 
('position_prop_user_val_out_of_max', 'insert', 'position_prop_user_val', 'Значение свойства выше верхней границы диапазона значений', '-', '3', 'position_prop_user_small_val_set'), 
('usr_login_not_found', 'update', 'user', 'Указанный пользователь не найден', '-', '1', 'user_options_upd'), 
('conception_not_found', 'update', 'user', 'Указанная концепция не найдена', '-', '1', 'user_options_upd'), 
('class_act_not_found', 'cast', 'object', 'Активный класс редактируемого объекта не найден', '-', '3', 'object_cast_for_class_act'), 
('document_not_found', 'delete', 'doc_link', 'Ссылочный документ не найден', '-', '1', 'doc_link_del_by_entity'), 
('none', 'delete', 'doc_link', 'Неизвестная ошибка удаления ссылки на документ', '-', '1', 'doc_link_del_by_entity'), 
('none', 'delete', 'log_link', 'Неизвестная ошибка удаления ссылки записи журнала', '-', '1', 'log_link_del_by_entity'), 
('conception_ppos_and_pclass_not_match', 'insert', 'object', 'Концепции класса и целевой позиции не совпадают', '-', '3', 'object_add_for_class_act'), 
('ppos_in_recycle_space', 'insert', 'object', 'Целевая позиция удалена в корзину', '-', '3', 'object_add_for_class_act'), 
('pos_prototype_ppos_not_allow_include_object', 'insert', 'object', 'Прототип шаблона указанной позиции не допускает вложения объектов', '-', '3', 'object_add_for_class_act'), 
('rulel1_class_on_pos_temp_not_allowed', 'insert', 'object', 'Классу объекта не назначено разрешение уровня 1 для шаблона указанной позиции', '-', '3', 'object_add_for_class_act'), 
('none', 'insert', 'object', 'Неизвестная ошибка группового добавления объектов', '-', '1', 'object_add_for_class_act'), 
('pclass_in_recycle_space', 'insert', 'object', 'Указанный класс удален в корзину', '-', '1', 'object_add_for_class_act'), 
('pclass_not_found', 'insert', 'object', 'Указанный класс не найден', '-', '1', 'object_add_for_class_act'), 
('pclass_not_on', 'insert', 'object', 'Указанный класс выключен', '-', '1', 'object_add_for_class_act'), 
('ppos_not_found', 'insert', 'object', 'Указанная позиция не найдена', '-', '1', 'object_add_for_class_act'), 
('none', 'update', 'pos_temp_prop', 'Неизвестная ошибка сортировки свойства', '-', '3', 'pos_temp_prop_sort_bottom'), 
('pos_temp_prop_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_sort_bottom'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Активный класс указанного свойства не найден', '-', '1', 'pos_temp_prop_sort_bottom'), 
('class_not_found', 'insert', 'rulel2_class_on_position', 'Указанный класс не найден', '-', '1', 'rulel2_class_on_position_add'), 
('class_not_abstraction', 'insert', 'rulel2_class_on_position', 'Указанный класс не является абстрактным', '-', '3', 'rulel2_class_on_position_add'), 
('position_not_found', 'insert', 'rulel2_class_on_position', 'Указанная позиция не найдена', '-', '1', 'rulel2_class_on_position_add'), 
('conception_not_match', 'insert', 'rulel2_class_on_position', 'Концепции класса и позиции не совпадают', '-', '3', 'rulel2_class_on_position_add'), 
('class_in_group_recycle', 'insert', 'rulel2_class_on_position', 'Указанный класс уделан в корзину', '-', '3', 'rulel2_class_on_position_add'), 
('position_in_position_recycle', 'insert', 'rulel2_class_on_position', 'Указанная позиция уделана в корзину', '-', '3', 'rulel2_class_on_position_add'), 
('class_not_allowed', 'insert', 'rulel2_class_on_position', 'Указанный класс не разрешен для шаблона выбранной позции в правилах уровня 1 группа на шаблон', '-', '3', 'rulel2_class_on_position_add'), 
('rulel2_not_found', 'delete', 'rulel2_class_on_position', 'Указанный правило не найдено', '-', '1', 'rulel2_class_on_position_del'), 
('prop_enum_upd_not_found', 'delete', 'prop_enum_val', 'Указанный элемент перечисления не найден', '-', '1', 'prop_enum_val_sort_by_name'), 
('position_upd_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_sort_up'), 
('item_upper_not_found_is_upper_limit', 'update', 'position', 'Указанный элемент в крайней верхней позиции', '-', '3', 'position_sort_up'), 
('position_parent_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_sort_by_name'), 
('position_parent_not_found', 'update', 'position', 'Указанная позиция не найдена', '-', '1', 'position_root_sort_by_name'), 
('pos_temp_prop_not_found', 'delete', 'pos_temp_prop_user_val', 'Указанное свойство шаблона не найдено', '-', '1', 'pos_temp_prop_user_val_del'), 
('pos_temp_prop_not_user', 'delete', 'pos_temp_prop_user_val', 'Указанное свойство шаблона является пользовательским', '-', '3', 'pos_temp_prop_user_val_del'), 
('pos_temp_not_found', 'delete', 'pos_temp_prop_user_val', 'Указанный шаблон позиции не найден', '-', '1', 'pos_temp_prop_user_val_del'), 
('pos_recycle_not_found', 'delete', 'position', 'Корзина концепции не найдена', '-', '3', 'position_del'), 
('pos_include_freeze_object', 'delete', 'position', 'Позиция содержит заблокированные объекты', '-', '3', 'position_del'), 
('pos_temp_upd_not_found', 'update', 'pos_temp_prop', 'Указанное свойство шаблона позиции на найдено', '-', '1', 'pos_temp_prop_sort_by_name'), 
('plan_range_not_found', 'delete', 'plan_given_range_plan', 'Указанный плановый диапазон не найден', '-', '1', 'plan_given_range_plan_del_by_id_plan_range'), 
('none', 'delete', 'plan_given_range_plan', 'Неизвестная ошибка удаления планового диапазона', '-', '3', 'plan_given_range_plan_del_by_id_plan_range'), 
('round_val_spec_state_out_of_min', 'insert', 'class_prop_user_val', 'Точность округления значения меньше нижней разрешенной границы диапазона значений', '-', '3', 'class_prop_user_small_val_set'), 
('inherit_class_prop_not_override', 'insert', 'class_prop_user_val', 'Указанное свойство класса не является переопределяемым по значению', '-', '3', 'class_prop_user_small_val_set'), 
('usr_familiya_is_empty', 'update', 'user', 'Фамилия пользователя меньше одного символа', '-', '3', 'user_upd'), 
('usr_otchestvo_is_empty', 'insert', 'user', 'Отчество пользователя меньше одного символа', '-', '3', 'user_add'), 
('prop_enum_val_is_use', 'delete', 'prop_enum_val', 'Указанное значение перечисления используется', '-', '3', 'prop_enum_val_del'), 
('prop_data_type_alias_not_unique', 'insert', 'con_prop_data_type', 'Указанный алиас типа данных не явялеется уникальным для выбранной концепции', '-', '1', 'con_prop_data_type_set'), 
('prop_data_type_not_found', 'insert', 'con_prop_data_type', 'Указанный тип данных не найден', '-', '1', 'con_prop_data_type_set'), 
('rule_quantity_violated', 'update', 'object', 'Указанное количество объектов меньше или равно нулю', 'Количество объектов не может быть отрицательной величиной', '3', 'object_upd'), 
('usr_familiya_is_empty', 'insert', 'user', 'Фамилия пользователя меньше одного символа', '-', '3', 'user_add'), 
('usr_name_is_empty', 'insert', 'user', 'Имя пользователя меньше одного символа', '-', '3', 'user_add'), 
('usr_name_is_empty', 'update', 'user', 'Имя пользователя меньше одного символа', '-', '3', 'user_upd'), 
('usr_otchestvo_is_empty', 'update', 'user', 'Отчествопользователя меньше одного символа', '-', '3', 'user_upd'), 
('usr_rolname_is_empty', 'insert', 'user', 'Логин пользователя меньше одного символа', '-', '3', 'user_add'), 
('usr_rolname_is_empty', 'update', 'user', 'Логин пользователя меньше одного символа', '-', '3', 'user_upd'), 
('role_name_not_unique', 'insert', 'user', 'Указанный новый логин пользователя используется', '-', '3', 'user_add'), 
('user_role_user_role_name_is_empty', 'insert', 'role_user', 'Имя роли пользователя меньше одного символа', '-', '3', 'user_role_user_add'), 
('user_role_user_role_namesys_is_empty', 'insert', 'role_user', 'Системное имя роли пользователя меньше одного символа', '-', '3', 'user_role_user_add'), 
('user_role_user_namesys_new_is_empty', 'update', 'role_user', 'Новое системное имя роли пользователя меньше одного символа', '-', '3', 'user_role_user_upd'), 
('user_role_user_role_namesys_is_empty', 'update', 'role_user', 'Системное имя роли пользователя меньше одного символа', '-', '3', 'user_role_user_upd'), 
('user_role_user_role_name_is_empty', 'update', 'role_user', 'Имя роли пользователя меньше одного символа', '-', '3', 'user_role_user_upd'), 
('unit_conversion_rule_from_aggobject_is_single_only', 'update', 'unit_conversion_rule', 'Недопустимое значение on_single для правила пересчета объектных агрегатов', 'Правила учета объектных агрегатов не могут иметь значения количества отличные от одной единицы', '3', 'unit_conversion_rule_upd'), 
('class_upd_not_found', 'insert', 'class_prop', 'Указанный класс не найден', '-', '1', 'class_prop_add_as_global_prop'), 
('unit_conversion_rule_is_use_in_object', 'delete', 'unit_conversion_rule', 'Указанное правило пересчета  используется в объектах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_del'), 
('unit_conversion_rule_is_use_in_class_and_object', 'delete', 'unit_conversion_rule', 'Указанное правило пересчета  используется в классах и объектах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_del'), 
('unit_conversion_rule_is_single_only', 'update', 'unit_conversion_rule', 'Недопустимое значение mc для единичного правила пересчета', 'Правила единичного учета не могут иметь значения количества отличные от одной единицы', '3', 'unit_conversion_rule_upd'), 
('pos_is_lockdel', 'delete', 'position', 'Выбранная позиция заблокирована', '-', '3', 'position_del'), 
('pclass_in_recycle_space', 'insert', 'object', 'Выбранный класс находится в корзине', '-', '3', 'object_add'), 
('ppos_not_found', 'move', 'position', 'Целевая позиция не найдена', '-', '1', 'position_move'), 
('pos_not_found', 'move', 'position', 'Выбранная позиция не найдена', '-', '1', 'position_move'), 
('pos_is_lockdel', 'move', 'position', 'Выбранная позиция заблокирована', '-', '1', 'position_move'), 
('pos_is_recycle', 'move', 'position', 'Выбранная позиция является корзиной', 'Перенос сервисный и служебных позиций не допускается', '3', 'position_move'), 
('pos_not_found', 'delete', 'position', 'Выбранная позиция не найдена', '-', '1', 'position_del'), 
('pclass_not_found', 'insert', 'object', 'Выбранный вещественный класс не найден', '-', '1', 'object_add'), 
('unit_conversion_rule_is_use_in_class_and_object', 'update', 'unit_conversion_rule', 'Указанное правило пересчета  используется в классах и объектах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_is_use_in_object', 'update', 'unit_conversion_rule', 'Указанное правило пересчета  используется в объектах', 'Используемые правила пересчета заблокированы, так как их изменение или удалеие  повлияет на текушее количество ранее созданных объектов', '3', 'unit_conversion_rule_upd'), 
('unit_conversion_rule_is_base', 'delete', 'unit_conversion_rule', 'Указанное правило пересчета  является базовым', 'Базовые правила пересчета не могут быть удалены или модифицированы. При необходимости их изменения можно создать дополнительное правило с неабходимыми параметрами.', '3', 'unit_conversion_rule_del'), 
('class_unit_conversion_rules_is_default', 'delete', 'class_unit_conversion_rule', 'Указанное правило пересчета назначено правилом по умолчанию в выбранном классе', 'Базовые правила пересчета не могут быть удалены или модифицированы. При необходимости их изменения можно создать дополнительное правило с неабходимыми параметрами.', '3', 'class_unit_conversion_rules_del'), 
('newpwd_is_short', 'update', 'user', 'Новый пароль не соответствует требованиям к минимальной длине пароля', '-', '3', 'user_pwd_reset'), 
('newpwd_is_short', 'update', 'user', 'Новый пароль не соответствует требованиям к минимальной длине пароля', '-', '3', 'user_pwd_set'), 
('iid_parent_out_of_range', 'copy', 'position', 'Идентификатор целевой позиции за пределом допустимых значений', 'iid_parent имет отрицетельное значение или вышел за диапазон типа', '1', 'position_copy'), 
('pos_include_freeze_object', 'move', 'position', 'Переносимая позиция содержит заблокированые элементы', '-', '1', 'position_move'), 
('iid_parent_out_of_range', 'move', 'position', 'Идентификатор переносимой позиции за пределом допустимых значений', 'iid_parent имет отрицетельное значение или вышел за диапазон типа', '1', 'position_move'), 
('ppos_is_current_location', 'move', 'position', 'Целевая позиция является текущим расположением переносимой позиции', '-', '3', 'position_move'), 
('rules_nesting_pos_temp_limit_max_violated', 'move', 'position', 'Шаблоны целевой и перемещаемой позиций устанавливают ограничение на выбранное расположение', 'Нарушение ограничения правил вложенности шаблонов позиций на количество размещаемых элементов', '3', 'position_move'), 
('pos_name_not_unique', 'move', 'position', 'Наименование переносимой позиции не является уникальным в выбранном расположении', 'Выполните предварительное переименование переносимой позиции', '3', 'position_move'), 
('rules_nesting_pos_temp_violated', 'move', 'position', 'Прототипы целевой и перемещаемой позиций не допускают выбранное размещение', 'Нарушения правил вложенности прототипов позиций', '3', 'position_move'), 
('class_edit_name_is_empty', 'update', 'class', 'Выбранное наименование слишком короткое', '-', '3', 'class_upd'), 
('conception_name_is_empty', 'update', 'conception', 'Выбранное наименование слишком короткое', '-', '3', 'conception_upd'), 
('rules_nesting_pos_prototype_violated', 'move', 'position', 'Шаблоны целевой и перемещаемой позиций не допускают выбранное расположение', 'Нарушение правила вложенности шаблонов позиций', '3', 'position_move'), 
('ppos_enters_in_pos', 'move', 'position', 'Целевая позиция входит в переносимую позицию', 'Циклические ссылки не допускаются', '3', 'position_move'), 
('ppos_in_recycle_space', 'move', 'position', 'Целевая позиция находится в корзине', '-', '3', 'position_move'), 
('conception_not_match', 'move', 'position', 'Концепции переносимой и целевой позиций не совпадают', '-', '3', 'position_move'), 
('tpos_is_service', 'delete', 'pos_temp', 'Выбранный шаблон позиции является сервисным', '-', '3', 'pos_temp_del'), 
('tpos_pattern_not_found', 'copy', 'pos_temp', 'Выбранный шаблон позиции не найден', '-', '1', 'pos_temp_copy'), 
('desc_is_empty', 'update', 'log_category', 'Выбранное описание слишком короткое', '-', '3', 'log_category_upd'), 
('doc_upd_name_is_empty', 'insert', 'document', 'Выбранное наименование слишком короткое', '-', '3', 'document_add'), 
('doc_upd_name_is_empty', 'update', 'document', 'Выбранное наименование слишком короткое', '-', '3', 'document_upd'), 
('enum_name_is_empty', 'update', 'prop_enum', 'Выбранное наименование слишком короткое', '-', '3', 'prop_enum_upd'), 
('group_name_is_empty', 'update', 'group', 'Выбранное наименование слишком короткое', '-', '3', 'group_upd'), 
('log_message_is_empty', 'update', 'log', 'Выбранное сообщение слишком короткое', '-', '3', 'log_upd'), 
('log_title_is_empty', 'update', 'log', 'Выбранное описание слишком короткое', '-', '3', 'log_upd'), 
('name_is_empty', 'insert', 'doc_category', 'Выбранное наименование слишком короткое', '-', '3', 'doc_category_add'), 
('name_is_empty', 'update', 'doc_category', 'Выбранное наименование слишком короткое', '-', '3', 'doc_category_upd'), 
('tpos_not_found', 'move', 'position', 'Шаблон переносимой позиции не найден', '-', '1', 'position_move'), 
('tppos_not_found', 'move', 'position', 'Шаблон целевой позиции не найден', '-', '1', 'position_move'), 
('ppos_is_recycle', 'insert', 'position', 'Целевая позиция является корзиной', '-', '4', 'position_add'), 
('pos_pattern_is_recycle', 'copy', 'position', 'Копируемая позиция является корзиной', 'Копирование сервисных позиций не допускается', '3', 'position_copy'), 
('tpos_temp_not_found', 'insert', 'position', 'Шаблон создаваемой позиции не найден', '-', '7', 'position_add'), 
('tpos_temp_is_off', 'insert', 'position', 'Шаблон создаваемой позиции отключен', 'Для создания новых позиций на основе выбранного шаблона его необходимо включить', '3', 'position_add'), 
('tpos_temp_is_service', 'insert', 'position', 'Шаблон создаваемой позиции является сервисным', 'Функция position_add не принимает сервисные шаблоны для создания позиций', '3', 'position_add'), 
('rules_nesting_pos_prototype_violated', 'copy', 'position', 'Прототипы целевой и копируемой позиций не допускают выбранное расположение', 'Нарушение правила вложенности прототипов шаблонов позиций', '3', 'position_copy'), 
('rules_nesting_pos_prototype_violated', 'insert', 'position', 'Прототипы целевой и создаваемой позиций не допускают выбранное расположение', 'Нарушение правила вложенности прототипов шаблонов позиций', '3', 'position_add'), 
('rules_nesting_pos_temp_limit_max_violated', 'insert', 'position', 'Шаблоны целевой и создаваемой позиций устанавливают ограничение на выбранное расположение', 'Нарушение ограничения правил вложенности шаблонов позиций на количество размещаемых элементов', '3', 'position_add'), 
('rules_nesting_pos_temp_violated', 'insert', 'position', 'Шаблоны целевой и создаваемой позиций не допускают выбранное размещение', 'Нарушение правила вложенности шаблонов позиций', '3', 'position_add'), 
('rules_nesting_pos_temp_limit_max_violated', 'copy', 'position', 'Шаблоны целевой и копируемой позиций устанавливают ограничение на выбранное расположение', 'Нарушение ограничения правил вложенности шаблонов позиций на количество размещаемых элементов', '3', 'position_copy'), 
('rules_nesting_pos_temp_violated', 'copy', 'position', 'Шаблоны целевой и копируемой позиций не допускают выбранное размещение', 'Нарушение правила вложенности шаблонов позиций', '3', 'position_copy'), 
('pos_target_is_recycle', 'copy', 'position', 'Целевая позиция является корзиной', 'Копирование в сервисные позиции не допускается', '1', 'position_copy'), 
('tpos_name_not_unique', 'insert', 'pos_temp', 'Наименование шаблона позиции используется', '-', '3', 'pos_temp_add'), 
('tpos_name_is_empty', 'insert', 'pos_temp', 'Выбранное наименование слишком короткое', '-', '3', 'pos_temp_add'), 
('pclass_not_on', 'insert', 'object', 'Выбранный класс выключен', 'Выключенный классы не могут наследоваться новыми объектами', '3', 'object_add'), 
('class_unit_conversion_rule_not_available', 'insert', 'object', 'Выбранное правило пересчета не назначено для выбранного вещественного класса', '-', '3', 'object_add'), 
('rule_quantity_round_violated', 'insert', 'object', 'Указаное колличество объекта превышает заданную точность округления', '-', '3', 'object_add'), 
('rule_quantity_violated', 'insert', 'object', 'Указанное количество объекта меньше нуля', 'Количество объектов не может быть отрицательной величиной', '3', 'object_add'), 
('class_inherited_not_extensible', 'insert', 'class_prop', 'Наследуемый класс указанного класса объявлен как нерасширяемый и не допускает добавление расширенных свойств в наследующих классах', '-', '3', 'class_prop_add_as_global_prop'), 
('prop_type_not_allow_unit', 'insert', 'class_prop', 'Указанный тип свойства не совместим с измеряемой величиной несущего класса', '-', '3', 'class_prop_add_as_global_prop'), 
('prop_type_not_found', 'insert', 'class_prop', 'Указаный тип свойства класса не найден', '-', '7', 'class_prop_add_as_global_prop'), 
('global_prop_not_found', 'insert', 'class_prop', 'Указанное глобальное свойство концепции не найдено', '-', '7', 'class_prop_add_as_global_prop'), 
('global_prop_area_val_not_set', 'insert', 'class_prop', 'Область значений для указанного глобального свойства не установлена', '-', '7', 'class_prop_add_as_global_prop'), 
('data_type_not_allowed', 'insert', 'class_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'class_prop_add'), 
('data_type_not_allowed', 'insert', 'global_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'global_prop_add'), 
('data_type_not_allowed', 'insert', 'global_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'global_prop_add_as_class_prop'), 
('data_type_not_allowed', 'insert', 'global_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'global_prop_add_as_pos_temp_prop'), 
('data_type_not_allowed', 'update', 'global_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'global_prop_upd'), 
('data_type_not_allowed', 'update', 'class_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'class_prop_upd'), 
('data_type_not_allowed', 'insert', 'pos_temp_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'pos_temp_prop_add'), 
('data_type_not_allowed', 'update', 'pos_temp_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'pos_temp_prop_upd'), 
('data_type_not_allowed', 'insert', 'class_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'class_prop_add_as_global_prop'), 
('data_type_not_allowed', 'update', 'global_prop', 'Указанный тип данных свойства недоступен в текущей концепции', 'Проверьте список типов свойств разрешенных в концепции', '3', 'global_prop_area_val_set'), 
('global_prop_is_use', 'update', 'global_prop', 'Указанное глобальное свойство используется', 'Используемые глобальные свойства не допускают переопределения области значений', '3', 'global_prop_upd'), 
('global_prop_is_use', 'delete', 'global_prop_area_val', 'Указанное глобальное свойство используется', 'Используемые глобальные свойства не допускают удаления области значения', '3', 'global_prop_area_val_del'), 
('global_prop_name_not_unique', 'insert', 'global_prop', 'Указанное значение имени глобального свойства не является уникальным', 'Укажите уникальное значение имени глобального свойства в пределах текущей концепции', '3', 'global_prop_add_as_class_prop'), 
('global_prop_name_not_unique', 'insert', 'global_prop', 'Указанное значение имени глобального свойства не является уникальным', 'Укажите уникальное значение имени глобального свойства в пределах текущей концепции', '3', 'global_prop_add_as_pos_temp_prop'), 
('global_prop_name_not_unique', 'insert', 'global_prop', 'Указанное значение имени глобального свойства не является уникальным', 'Укажите уникальное значение имени глобального свойства в пределах текущей концепции', '3', 'global_prop_add'), 
('global_prop_name_not_unique', 'insert', 'class_prop', 'Указанное значение имени глобального свойства не является уникальным', 'Укажите уникальное значение имени глобального свойства в пределах текущей концепции', '3', 'class_prop_add_as_global_prop'), 
('global_prop_name_not_unique', 'update', 'global_prop', 'Указанное значение имени глобального свойства не является уникальным', 'Укажите уникальное значение имени глобального свойства в пределах текущей концепции', '3', 'global_prop_upd'), 
('class_prop_not_found', 'insert', 'class_prop_object_val', 'Указанное свойство класса не найдено', '-', '1', 'class_prop_object_val_set'), 
('class_val_not_include_branch_class_val_inherited_class_prop', 'insert', 'class_prop_object_val', 'Указанный класс значение свойства не входит в ветвь класса значения свойства установленного в наследуемом свойстве', 'В наследуемом переопределяемом объектном свойстве не допускается определение класса значения отличное от класса значения наследуемого свойства. Установите нужный класс в определяющем свойстве или в глобальном если свойства является глобальным.', '3', 'class_prop_object_val_set'), 
('class_val_not_include_branch_class_val_global_prop', 'insert', 'class_prop_object_val', 'Указанный класс значение свойства не входит в ветвь класса значения глобального свойства', 'В определяющем объектном свойстве класса, связанным с глобальным свойством, не допускается определение класса значения, отличного от класса значения, указанного в глобальном свойстве. Установите нужный класс в глобальном свойстве, предварительно удалив все имеющиеся ссылки на определяющие свойства классов и шаблонов позиций.', '3', 'class_prop_object_val_set'), 
('enum_val_not_match_enum_val_global_prop', 'insert', 'class_prop_enum_val', 'В определяющем свойстве класса типа перечисление, связанным с глобальным свойством, не допускается определение перечисления, отличного от перечисления, указанного в глобальном свойстве.', '-', '3', 'class_prop_enum_val_set'), 
('link_val_not_match_link_val_global_prop', 'insert', 'class_prop_link_val', 'В определяющем свойстве класса типа ссылка, связанным с глобальным свойством, не допускается определение сущности, отличной от сущности, указанной в глобальном свойстве.', '-', '3', 'class_prop_link_val_set');
END;