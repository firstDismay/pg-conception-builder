-- FUNCTION: int.int_class_prop_val_inherit(bigint, boolean)

-- DROP FUNCTION IF EXISTS "int".int_class_prop_val_inherit(bigint, boolean);

CREATE OR REPLACE FUNCTION "int".int_class_prop_val_inherit(
	iid_class_prop bigint,
	on_timestamp_class_upd boolean DEFAULT false)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    SET search_path=bpd, "int", py
AS $BODY$
DECLARE
    --**************************************************************************
    --Дата: 07.02.2020
    --Версия: 4.3(08.12.2024) изменение алгоритма наследования
    --Автор: Иванов Д.Ю.
    --Описание: Функция выполняет безусловное наследование значения свойства свойствами наследующих классов
    --**************************************************************************
    
    inherited_top_prop "bpd"."class_prop"%ROWTYPE; --Свойство наследуемое указанным наследуемым свойством
    inherited_prop "bpd"."class_prop"%ROWTYPE; -- НАСЛЕДУЕМОЕ СВОЙСТВО
    inheriting_class RECORD; -- НАСЛЕДУЮЩИЙ КЛАСС
    inheriting_class_prop RECORD; -- НАСЛЕДУЮЩЕЕ СВОЙСТВО
    
    class_val_include_branch_class_val BOOLEAN DEFAULT FALSE; --Выбранный класс значение входит в ветвь класса значения наследуемого свойства
    
    inherited_user_big_data "bpd"."vclass_prop_user_big_val"%ROWTYPE; -- Данные значения наследуемого ползовательского свойства тип 1 BIG
    inherited_user_small_data "bpd"."vclass_prop_user_small_val"%ROWTYPE; -- Данные значения наследуемого ползовательского свойства тип 1 SMALL
    inherited_enum_data "bpd"."vclass_prop_enum_val"%ROWTYPE; -- Данные значения наследуемого свойства перечисления тип 2
    inherited_object_data "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения наследуемого объектного свойства тип 3
    inherited_link_data "bpd"."vclass_prop_link_val"%ROWTYPE; -- Данные значения наследуемого свойства-ссылки тип 4
    
    inheriting_user_big_data "bpd"."vclass_prop_user_big_val"%ROWTYPE; -- Данные значения наследующего ползовательского свойства тип 1 BIG
    inheriting_user_small_data "bpd"."vclass_prop_user_small_val"%ROWTYPE; -- Данные значения наследующего ползовательского свойства тип 1 SMALL
    inheriting_enum_data "bpd"."vclass_prop_enum_val"%ROWTYPE; -- Данные значения наследующего свойства перечисления тип 2
    inheriting_object_data "bpd"."vclass_prop_object_val"%ROWTYPE; -- Данные значения наследующего объектного свойства тип 3
    inheriting_link_data "bpd"."vclass_prop_link_val"%ROWTYPE; -- Данные значения наследующего свойства-ссылки тип 4
    
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КЛАССА
BEGIN 
    --ШАГ №00 Подготовка штампа времени
    action_timestamp = LOCALTIMESTAMP(3);
    --ШАГ №01 Запрос наследуемого свойства
    SELECT * INTO inherited_prop FROM ONLY "bpd"."class_prop" WHERE id = iid_class_prop;
    IF NOT (inherited_prop IS NULL) THEN
        --ШАГ №02 Наследуемое свойство получено, проверяем необходимость актуализации данных значения
        IF inherited_prop.inheritance THEN
            --ШАГ №03 Наследуемое свойство наследовано получаем наследуемое им свойство
            SELECT * INTO inherited_top_prop FROM ONLY "bpd"."class_prop" WHERE id = inherited_prop.id_prop_inherit;
            IF NOT (inherited_top_prop IS NULL) THEN
                --ШАГ №03 Получаем данные значения свойства
                CASE inherited_top_prop.id_prop_type
                    WHEN 1 THEN --Пользовательское свойство
                        CASE inherited_top_prop.id_data_type
                            WHEN 7, 8, 14 THEN --BIG
                                
                                --ШАГ №03.1 Получаем данные значения наследуемого свойства USER BIG
                                SELECT * INTO inherited_user_big_data FROM "bpd"."vclass_prop_user_big_val"        
                                                WHERE id_class_prop = inherited_top_prop.id;
                                
                                --ШАГ №03.2 Получаем данные значения наследующего свойства USER BIG
                                SELECT * INTO inheriting_user_big_data FROM "bpd"."vclass_prop_user_big_val"        
                                                WHERE id_class_prop = inherited_prop.id;
                                
                                IF (NOT(inherited_user_big_data IS NULL)) AND (NOT(inheriting_user_big_data IS NULL)) THEN
                                    IF (inheriting_user_big_data.tablename = 'notsaved') THEN
                                        
                                        --ШАГ №03.3 Данные значения наследующего свойства USER BIG не сохранены, встявляем
                                        INSERT INTO "bpd"."class_prop_user_big_val"
                                            ("id_conception",
											 "id_class",
                                             "timestamp_class",   
                                             "id_class_prop",
                                             "id_data_type",
                                             "inheritance",

                                             "min_on",   
                                             "min_val", 
                                             "max_on", 
                                             "max_val")
                                        VALUES 
                                           (inherited_prop.id_conception,
											inherited_prop.id_class,
                                            action_timestamp,
                                            inherited_prop.id,
                                            inherited_top_prop.id_data_type,
                                            TRUE,
                                            
                                            inherited_user_big_data."min_on", 
                                            inherited_user_big_data."min_val", 
                                            inherited_user_big_data."max_on", 
                                            inherited_user_big_data."max_val");
                                    END IF;
                                    
                                    IF (inherited_prop.on_inherit) OR (NOT inherited_top_prop.on_override)  THEN
                                        --ШАГ №03.5 Значение наследуемого свойства установлено, 
                                        --          наследующее свойство наследует значение, наследуем
                                        UPDATE ONLY "bpd"."class_prop_user_big_val"
                                            SET
                                                "min_on" = inherited_user_big_data."min_on", 
                                                "min_val" = inherited_user_big_data."min_val", 
                                                "max_on" = inherited_user_big_data."max_on",
                                                "max_val" = inherited_user_big_data."max_val",
                                                
												 "id_data_type" = inherited_user_big_data.id_data_type,
                                                "val_text" = inherited_user_big_data."val_text",
                                                "val_bytea" = inherited_user_big_data."val_bytea",
                                                "val_json" = inherited_user_big_data."val_json",
												 "timestamp_class" = action_timestamp
                                            WHERE     
                                                "id_class_prop" = inherited_prop.id;   
                                    END IF;
                                END IF;
                            ELSE --SMALL (CASE)
                                --ШАГ №03.1 Получаем данные значения наследуемого свойства USER SMALL
                                SELECT * INTO inherited_user_small_data FROM "bpd"."vclass_prop_user_small_val"        
                                                WHERE id_class_prop = inherited_top_prop.id;
                                
                                --ШАГ №03.2 Получаем данные значения наследующего свойства USER SMALL
                                SELECT * INTO inheriting_user_small_data FROM "bpd"."vclass_prop_user_small_val"        
                                                WHERE id_class_prop = inherited_prop.id;
                                
                                IF (NOT(inherited_user_small_data IS NULL)) AND (NOT(inheriting_user_small_data IS NULL)) THEN
                                    IF (inheriting_user_small_data.tablename = 'notsaved') THEN
                                        --ШАГ №03.3 Данные значения наследующего свойства USER SMALL не сохранены, встявляем
                                        INSERT INTO "bpd"."class_prop_user_small_val"
                                           ("id_conception",
											"id_class",
                                            "timestamp_class",   
                                            "id_class_prop",
                                            "id_data_type",
                                            "inheritance",
                                     
                                            "min_on",
                                            "min_val",
                                            "max_on",
                                            "max_val",
                                            "round_on",
                                            "round")
                                        VALUES 
                                            (inherited_prop.id_conception,
											inherited_prop."id_class",
                                            action_timestamp,
                                            inherited_prop.id,
                                            inherited_top_prop."id_data_type",
                                            TRUE,
                                    
                                            inherited_user_small_data."min_on",
                                            inherited_user_small_data."min_val",
                                            inherited_user_small_data."max_on",
                                            inherited_user_small_data."max_val",
                                            inherited_user_small_data."round_on",
                                            inherited_user_small_data."round");
                                    END IF;
                                    IF (inherited_prop.on_inherit) OR (NOT inherited_top_prop.on_override) THEN
                                        --ШАГ №03.5 Значение наследуемого свойства установлено, 
                                        --          наследующее свойство наследует значение, наследуем
                                        UPDATE ONLY "bpd"."class_prop_user_small_val"
                                            SET
                                                "min_on" = inherited_user_small_data."min_on",
                                                "min_val" = inherited_user_small_data."min_val",
                                                "max_on" = inherited_user_small_data."max_on",
                                                "max_val" = inherited_user_small_data."max_val",
                                                "round_on" = inherited_user_small_data."round_on",
                                                "round" = inherited_user_small_data."round",
												
												 "id_data_type" = inherited_user_small_data."id_data_type",
                                                "val_varchar" = inherited_user_small_data."val_varchar",
                                                "val_int" = inherited_user_small_data."val_int",
                                                "val_numeric" = inherited_user_small_data."val_numeric",
                                                "val_real" = inherited_user_small_data."val_real",
                                                "val_double" = inherited_user_small_data."val_double",
                                                "val_money" = inherited_user_small_data."val_money",
                                                "val_boolean" = inherited_user_small_data."val_boolean",
                                                "val_date" = inherited_user_small_data."val_date",
                                                "val_time" = inherited_user_small_data."val_time",
                                                "val_interval" = inherited_user_small_data."val_interval",
                                                "val_timestamp" = inherited_user_small_data."val_timestamp",
                                                "val_bigint" = inherited_user_small_data."val_bigint",

												 "timestamp_class" = action_timestamp
                                            WHERE     
                                                "id_class_prop" = inherited_prop.id;  
                                    END IF;
                                END IF;        
                        END CASE;    
                    WHEN 2 THEN --Перечисление    
                        --ШАГ №03.1 Получаем данные значения наследуемого свойства ENUM
                        SELECT * INTO inherited_enum_data FROM "bpd"."vclass_prop_enum_val"        
                                        WHERE id_class_prop = inherited_top_prop.id;
                        
                        --ШАГ №03.2 Получаем данные значения наследующего свойства ENUM
                        SELECT * INTO inheriting_enum_data FROM "bpd"."vclass_prop_enum_val"        
                                        WHERE id_class_prop = inherited_prop.id;
                        
                        IF (NOT(inherited_enum_data IS NULL)) AND (NOT(inheriting_enum_data IS NULL)) THEN
                            IF (inheriting_enum_data.tablename = 'notsaved') THEN
                                
                                --ШАГ №03.3 Данные значения наследующего свойства ENUM не сохранены, встявляем
                                INSERT INTO "bpd"."class_prop_enum_val"
                                   ("id_conception",
									"id_class",
                                    "timestamp_class",   
                                    "id_class_prop",
                                    "inheritance",

                                    "id_prop_enum")
                                VALUES 
                                   (inherited_prop.id_conception,
  								    inherited_prop.id_class,
                                    action_timestamp,
                                    inherited_prop.id,
                                    TRUE,
                                    
                                    inherited_enum_data."id_prop_enum");
                            ELSE
                                --ШАГ №03.4 Данные значения наследующего свойства ENUM сохранены, обновляем
                                UPDATE ONLY "bpd"."class_prop_enum_val"
                                    SET
                                        "id_prop_enum" = inherited_enum_data."id_prop_enum",
                                        "timestamp_class" = action_timestamp
                                    WHERE     
                                        "id_class_prop" = inherited_prop.id;  
                                    
                            END IF;
                            IF (inherited_prop.on_inherit)  OR (NOT inherited_top_prop.on_override) THEN
                                --ШАГ №03.5 Значение наследуемого свойства установлено, 
                                --          наследующее свойство наследует значение, наследуем
                                UPDATE "bpd"."class_prop_enum_val"
                                    SET
                                        "id_prop_enum_val" = inherited_enum_data."id_prop_enum_val"
                                    WHERE     
                                        "id_class_prop" = inherited_prop.id;
                            END IF;            
                        END IF;        
                    WHEN 3 THEN --Объектное
                        --ШАГ №03.1 Получаем данные значения наследуемого свойства OBJECT
                        SELECT * INTO inherited_object_data FROM "bpd"."vclass_prop_object_val"        
                                        WHERE id_class_prop = inherited_top_prop.id;
                        
                        --ШАГ №03.2 Получаем данные значения наследующего свойства OBJECT
                        SELECT * INTO inheriting_object_data FROM "bpd"."vclass_prop_object_val"        
                                        WHERE id_class_prop = inherited_prop.id;
                        
                        IF (NOT(inherited_object_data IS NULL)) AND (NOT(inheriting_object_data IS NULL)) THEN
                            IF (inheriting_object_data.tablename = 'notsaved') THEN
                                --ШАГ №03.3 Данные значения наследующего свойства OBJECT не сохранены, встявляем
                                INSERT INTO "bpd"."class_prop_obj_val_class" 
                                   ("id_conception",
									"id_class",
                                    "timestamp_class",
                                    "id_class_prop",
                                    
                                    "id_class_val",
                                    "timestamp_class_val",
                                    
                                    "bquantity_max",
                                    "bquantity_min",
                                    
                                    "embed_single",
                                    "embed_mode",
                                    "embed_class_real_id",
                                    "id_unit_conversion_rule")
                                VALUES
                                   (inherited_prop.id_conception,
									inherited_prop.id_class,
                                    action_timestamp,
                                    inherited_prop.id,
                                    
                                    inherited_object_data.id_class_val,
                                    inherited_object_data.timestamp_class_val,
                                    
                                    inherited_object_data.bquantity_max,
                                    inherited_object_data.bquantity_min,
                                    
                                    inherited_object_data."embed_single",
                                    inherited_object_data."embed_mode",
                                    inherited_object_data."embed_class_real_id",
                                    inherited_object_data."id_unit_conversion_rule");
                            ELSE
                                --ШАГ №03.4 Определяем условие сохранения текущего значения наследующего свойства        
                                class_val_include_branch_class_val = EXISTS(
                                    WITH 
                                    RECURSIVE rpos ("id", "id_parent", "level", "patch", "cycle") AS 
                                        (SELECT 
                                            rp."id",
                                            rp."id_parent",
                                            0,
                                            ARRAY [rp."id"],
                                            false
                                            FROM ONLY "bpd"."class" rp
                                        WHERE rp."id" = inherited_object_data.id_class_val
                                    UNION all
                                        SELECT 
                                        rpc."id",
                                        rpc."id_parent",
                                        rpos."level" + 1,
                                        rpos."patch" || ARRAY [rpc."id"],    
                                        rpc."id" = ANY(rpos."patch")
                                        FROM ONLY "bpd"."class" rpc
                                        JOIN rpos ON rpos."id" = rpc."id_parent"
                                        WHERE NOT "cycle") 
                                    SELECT 1 FROM rpos WHERE id = inheriting_object_data.id_class_val);        
                            END IF;
                     
                            IF (inherited_prop.on_inherit)  OR 
                            (NOT inherited_top_prop.on_override) OR 
                            (NOT class_val_include_branch_class_val) THEN
                                
                                --ШАГ №03.5 Значение наследуемого свойства установлено, 
                                --          наследующее свойство наследует значение, наследуем
                                UPDATE ONLY "bpd"."class_prop_obj_val_class" 
                                    SET 
                                        "id_class_val" = inherited_object_data.id_class_val,
                                        "timestamp_class_val" = inherited_object_data.timestamp_class_val,

										 "bquantity_max" = inherited_object_data.bquantity_max,
                                        "bquantity_min" = inherited_object_data.bquantity_min,
                                        
                                        "embed_single" = inherited_object_data."embed_single",
                                        "embed_mode" = inherited_object_data."embed_mode",
                                        "embed_class_real_id" = inherited_object_data."embed_class_real_id",
                                        "id_unit_conversion_rule" = inherited_object_data."id_unit_conversion_rule",
										 "timestamp_class" = action_timestamp
                                    WHERE     
                                        "id_class_prop" = inherited_prop.id;  
                            END IF;    
                        END IF;    
                    WHEN 4 THEN --Ссылка    
                        --ШАГ №03.1 Получаем данные значения наследуемого свойства LINK
                        SELECT * INTO inherited_link_data FROM "bpd"."vclass_prop_link_val"        
                                        WHERE id_class_prop = inherited_top_prop.id;
                        
                        --ШАГ №03.2 Получаем данные значения наследующего свойства ENUM
                        SELECT * INTO inheriting_link_data FROM "bpd"."vclass_prop_link_val"        
                                        WHERE id_class_prop = inherited_prop.id;
                        
                        IF (NOT(inherited_link_data IS NULL)) AND (NOT(inheriting_link_data IS NULL)) THEN
                            IF (inheriting_link_data.tablename = 'notsaved') THEN
                                
                                --ШАГ №03.3 Данные значения наследующего свойства ENUM не сохранены, встявляем
                                INSERT INTO "bpd"."class_prop_link_val"
                                   ("id_conception",
									"id_class",
                                    "timestamp_class",   
                                    "id_class_prop",
                                    "inheritance",

                                    "id_entity") 
                                VALUES 
                                   (inherited_prop.id_conception,
									inherited_prop.id_class,
                                    action_timestamp,
                                    inherited_prop.id,
                                    TRUE,
                                    
                                    inherited_link_data."id_entity");
                            ELSE
                                --ШАГ №03.4 Данные значения наследующего свойства ENUM сохранены, обновляем
                                UPDATE ONLY "bpd"."class_prop_link_val"
                                    SET
                                        "id_entity" = inherited_link_data."id_entity",
                                        "timestamp_class" = action_timestamp
                                    WHERE     
                                        "id_class_prop" = inherited_prop.id;  
                                    
                            END IF;
                            IF (inherited_prop.on_inherit)  OR (NOT inherited_top_prop.on_override) THEN
                                
                                --ШАГ №03.5 Значение наследуемого свойства установлено, 
                                --          наследующее свойство наследует значение, наследуем
                                UPDATE ONLY "bpd"."class_prop_link_val"
                                    SET
                                        "id_entity_instance" = inherited_link_data."id_entity_instance"
                                    WHERE     
                                        "id_class_prop" = inherited_prop.id;  
                                
                                --ШАГ №03.6 Восстанавливаем признак наследования значения        
                                /*UPDATE ONLY "bpd"."class_prop" 
                                    SET 
                                        "on_inherit" = TRUE            
                                WHERE id = inherited_prop.id;  */       
                            END IF;            
                        END IF;            
                END CASE;    
                
                IF (on_timestamp_class_upd) THEN
                    --ШАГ №4.1 Обновляем штамп времени текущего свойства
                    UPDATE ONLY "bpd"."class_prop" cp
                        SET 
                            "timestamp_class" = action_timestamp            
                        WHERE (cp.id = inherited_prop.id) AND (cp."timestamp_class" <> action_timestamp);
                    --ШАГ №4 Обновляем штамп времени текущего представления класса
                    UPDATE ONLY "bpd"."class" c
                        SET 
                            "timestamp" = action_timestamp            
                        WHERE (c.id = inherited_prop.id_class) AND (c."timestamp" <> action_timestamp);
                    --ШАГ №4.1 Синхронизируем штамп времени класса носителя
                    --PERFORM bpd.int_sync_timestamp_by_id_class(inherited_prop.id_class);         
                END IF;
            END IF;
        END IF;
        
        --ШАГ №05 Наследуемое свойство получено и актуализировано, запускаем цикл наследования данных свойства подчиненными классами
        FOR inheriting_class IN SELECT id FROM ONLY "bpd"."class" c WHERE c.id_parent = inherited_prop.id_class
            --ШАГ №05.1 Входим в цикл перебора списка подчиненных классов
        LOOP
            --ШАГ №05.2 Зпрашиваем наследующее свойство подчиненнного класса
            SELECT id INTO inheriting_class_prop FROM ONLY "bpd"."class_prop" cp WHERE (cp.id_class = inheriting_class.id) AND 
                (cp.id_prop_inherit = inherited_prop.id);
            IF NOT(inheriting_class_prop IS NULL) THEN    
                
                --ШАГ №6 Запускаем каскадное наследование значения обновленного свойства подчиненными классами
                PERFORM int_class_prop_val_inherit(inheriting_class_prop.id, on_timestamp_class_upd);
            END IF;
        END LOOP;
    END IF;   
END;    
$BODY$;

ALTER FUNCTION "int".int_class_prop_val_inherit(bigint, boolean)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_val_inherit(bigint, boolean) TO base_level WITH GRANT OPTION;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_val_inherit(bigint, boolean) TO funcowner;

REVOKE ALL ON FUNCTION "int".int_class_prop_val_inherit(bigint, boolean) FROM PUBLIC;
