--FIX: object_add:
CREATE OR REPLACE FUNCTION bpd.object_add(
	iid_class bigint,
	iid_position bigint,
	iid_unit_conversion_rule integer,
	icquantity numeric,
	setname boolean DEFAULT true,
	OUT outid bigint)
    RETURNS bigint
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE SECURITY DEFINER PARALLEL SAFE 
    SET search_path=bpd, err
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 15.09.2019
    --Автор: Иванов Д.Ю.
    --Версия: 3.0 (22.05.2020)
    --Описание: Функция создает объект
    --**************************************************************************
    pclass "bpd"."class"%ROWTYPE; --НАСЛЕДУЕМЫЙ КЛАСС
    group_recycle "bpd"."group"%ROWTYPE; --Группа корзины концепции
    pclass_ready BOOLEAN DEFAULT TRUE; -- КЛАСС ГОТОВ К СОЗДАНИЮ ОБЪЕКТОВ
    
    ppos   "bpd"."position"%ROWTYPE; --РОДИТЕЛЬСКАЯ ПОЗИЦИЯ
    pos_recycle "bpd"."position"%ROWTYPE; --ПОЗИЦИЯ КОРЗИНЫ КОНЦЕПЦИИ
    
    unit_conversion_rule "bpd"."vunit_conversion_rules"%ROWTYPE; --Заданное правило пересчета
    bquantity_object_add numeric; --Количество встраиваемых объектов
    
    auto_object_prop_val "bpd"."vobject_prop_object_val"%ROWTYPE; --Данные значения объектного свойства проверяемого на наличие автоматизации встраивания
    cur_quantity NUMERIC; --количество автовстраиваемых аобъектов
    i NUMERIC DEFAULT 0;
    i_mc NUMERIC DEFAULT 1;
    
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОБНОВЛЕННОГО КАССА
    action_state character varying DEFAULT 'none'; --Статус действия над значением свойства перечисления
BEGIN
    SELECT * INTO pclass FROM ONLY "bpd"."class" WHERE "id" = iid_class;
    IF (pclass IS NULL) THEN
        action_state = 'pclass_not_found';
    ELSE
        IF (pclass."on_abstraction") THEN
            action_state = 'pclass_not_real';
        ELSE
            IF NOT(pclass."on") THEN
                action_state = 'pclass_not_on';
            ELSE
                --УКАЗАННЫЙ КЛАСС СУЩЕСТВУЕТ
                --ОПРЕДЕЛЯЕМ ГРУПУУ КОРЗИНЫ ТЕКУЩЕЙ КОНЦЕПЦИИ
                SELECT g.* INTO   group_recycle   FROM "bpd"."group" g 
                JOIN "bpd"."conception" c ON c.id = g.id_con
                WHERE g.id = c.group_recycle AND c.id = pclass.id_con;
                
                --ОПРЕДЕЛЯЕМ ПРИНАДЛЕЖИТ ЛИ ВЫБРАННЫЙ КЛАСС ПРОСТРАНСТВУ КОРЗИНЫ
                IF (pclass.id_group_root = group_recycle.id) THEN
                    action_state = 'pclass_in_recycle_space';
                ELSE
                    --Проверяем готовность класса к созданию объектов
                    IF NOT(bpd.class_act_prop_check(pclass.id)) THEN
                        action_state = 'class_real_include_noready_class_prop';
                    ELSE    
                        --Проверяем готовность формата имен объектов классов к созданию объектов
                        IF (NOT int.int_class_format_check(pclass.id)) THEN
                            action_state = 'class_real_noready_name_format';
                        ELSE
                            SELECT * INTO ppos FROM "bpd"."position" WHERE "id" = iid_position;
                            IF (ppos IS NULL) THEN
                                action_state = 'ppos_not_found';
                            ELSE 
                                --УКАЗАННАЯ ПОЗИЦИЯ СУЩЕСТВУЕТ
                                IF (ppos.id_con <> pclass.id_con) THEN   
                                    action_state = 'conception_ppos_and_pclass_not_match';
                                ELSE
                                    --КОНЕЦЕПЦИИ КЛАССА И ПОЗИЦИИ СОВПАДАЮТ
                                    --ОПРЕДЕЛЯЕМ ПОЗИЦИЮ КОРЗИНЫ ТЕКУЩЕЙ КОНЦЕПЦИИ
                                    SELECT p.* INTO   pos_recycle   FROM "bpd"."position" p 
                                            JOIN "bpd"."conception" c ON c.id = p.id_con
                                            WHERE p.id = c.pos_recycle AND c.id = ppos.id_con;
                                        --ОПРЕДЕЛЯЕМ ВХОЖДЕНИЕ  ЦЕЛЕВОЙ ПОЗИЦИИ В ПРОСТРАНСТВО КОРЗИНЫ
                                    IF (pos_recycle.id = ppos.id_root) THEN
                                        action_state = 'ppos_in_recycle_space';
                                    ELSE
                                                                         
                                        --ПРОТОТИП ШАБЛОНА ПОЗИЦИИ ДОПУСКАЕТ ВЛОЖЕНИЕ ОБЪЕКТОВ
                                        IF (NOT EXISTS(SELECT FROM "bpd"."pos_temp" t
                                            JOIN "bpd"."pos_prototype" proto ON t.id_prototype = proto.id    
                                                WHERE t.id = ppos.id_pos_temp AND proto.on_obj)) THEN    
                                            action_state = 'pos_prototype_ppos_not_allow_include_object';
                                        ELSE        
                                            --ПРОВЕРЯЕМ РАЗРЕШЕНИЕ УРОВНЯ 1
                                            IF (NOT int.int_rulel1_class_on_pos_temp_check_access(ppos.id_pos_temp, pclass.id)) THEN
                                                action_state = 'rulel1_class_on_pos_temp_not_allowed';
                                            ELSE    
                                                --ПРОВЕРЯЕМ НАЛИЧИЕ СПИСКА РАЗРЕШЕНИЙ УРОВНЯ 2 КЛАСС НА ПОЗИЦИЮ
                                                IF (EXISTS(SELECT FROM "bpd"."rulel2_class_on_position" rl2
                                                                    WHERE rl2.id_position = ppos.id)) THEN
                                                    --ПРОВЕРЯЕМ РАЗРЕШЕНИЯ УРОВНЯ 2 У ПОЗИЦИИ ДЛЯ УКАЗАННОГО КЛАССА
                                                    IF (NOT EXISTS(WITH
                                                                RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                                    (SELECT 
                                                                        rc."id",
                                                                        rc."id_parent",
                                                                        0,
                                                                        ARRAY [rc."id"],
                                                                        false
                                                                    FROM ONLY "bpd"."class" rc
                                                                    JOIN "bpd"."rulel2_class_on_position" rl2 ON rl2.id_class = rc.id
                                                                    WHERE rl2.id_position = ppos.id
                                                                UNION ALL
                                                                    SELECT 
                                                                        rpc."id",
                                                                        rpc."id_parent",
                                                                        rclass."level" + 1,
                                                                        rclass."patch" || ARRAY [rpc."id"],    
                                                                        rpc."id" = ANY(rclass."patch")
                                                                    FROM ONLY "bpd"."class" rpc
                                                                    JOIN rclass ON rclass."id" = rpc."id_parent"
                                                                    WHERE NOT "cycle") 
                                                                SELECT * FROM rclass WHERE rclass.id = pclass.id)) THEN
                                                        --СОЗДАНИЕ ОБЪЕКТА РАЗРЕШЕНО
                                                        action_state = 'rulel2_class_on_position_not_allowed';
                                                    ELSE    
                                                        action_state = 'object_creation_allowed';
                                                    END IF;
                                                ELSE
                                                    --СОЗДАНИЕ ОБЪЕКТА РАЗРЕШЕНО
                                                    action_state = 'object_creation_allowed';
                                                END IF;                               
                                            END IF;
                                        END IF;        
                                    END IF;
                                END IF;
                            END IF;    
                        END IF;
                    END IF;
                END IF;
            END IF;    
        END IF;    
    END IF;
        
    IF action_state = 'object_creation_allowed' THEN
        --Выполняем проверку доступности правила пересчета
        
        IF (NOT EXISTS(SELECT FROM "bpd"."class_unit_conversion_rules" cu
                                         WHERE cu.id_class = iid_class AND 
                                         cu.id_unit_conversion_rule = iid_unit_conversion_rule)) THEN
            action_state = 'class_unit_conversion_rule_not_available';
        ELSE                                 
            --Запрашиваем заданное правило пересчета
            SELECT * INTO unit_conversion_rule FROM "bpd"."vunit_conversion_rules" WHERE "id" = iid_unit_conversion_rule;                
            IF (unit_conversion_rule IS NULL) THEN
                action_state = 'unit_conversion_rule_not_found';
            ELSE
                bquantity_object_add = icquantity * unit_conversion_rule.mc;
                IF icquantity <> 1 AND unit_conversion_rule.on_single THEN
                    --Правило пересчета для объектов индивидуального учета не допускает значений не равных 1
                    action_state = 'rule_quantity_on_single_violated';
                ELSE
                    IF (unit_conversion_rule.not_fractional) AND (icquantity <> floor(icquantity)) THEN
                        --Правило пересчета для объектов не допускает дробных значений
                        action_state = 'rule_quantity_not_fractional_violated';
                    ELSE
                         IF (scale(icquantity) > unit_conversion_rule.round) AND (floor(icquantity) <> icquantity) THEN
                            --Заданный масштаб округления меньше указанной дробной части колличества объектов
                            action_state = 'rule_quantity_round_violated';
                        ELSE
                            IF icquantity <= 0 THEN
                                --Количество объектов не может быть отрицетельной величиной
                                action_state = 'rule_quantity_violated';
                            ELSE
                                --Все правила количества объектов выполнены
                                action_state = 'action_allowed';
                            END IF;
                        END IF;
                    END IF;    
                END IF;                    
            END IF;    
        END IF; 
    END IF;    
        
    IF (action_state = 'action_allowed') THEN                                     
    --Шаг №00 Создать снимок текущего представления класса
        PERFORM int.int_class_snapshot_create(iid_class);
        action_timestamp = LOCALTIMESTAMP(3); 
    --ШАГ №01 СОЗДАЕМ ОБЪЕКТ УКЗАННОГО КЛАССА В УКАЗАННОЙ ПОЗИЦИИ
        INSERT INTO "bpd"."object" ( 
            "id_conception",
            "id_group", 
            "id_group_root",
            "id_class",
            "timestamp_class", 
            "id_class_root",
            "name",
            "id_unit_conversion_rule",
            "mc",
            "id_position", 
            "id_position_root",
            "id_object_carrier",
            "id_class_prop_object_carrier",
            "id_pos_temp_prop",
			"path_array",
            "bquantity",
            "barcode_unit",     
            "on_freeze",  
            "timestamp",
            "desc" ) 
        VALUES ( 
            pclass."id_con", 
            pclass.id_group, 
            pclass.id_group_root, 
            pclass.id, 
            pclass.timestamp, 
            pclass.id_root, 
            pclass."name", 
            "iid_unit_conversion_rule", 
            unit_conversion_rule.mc,
            ppos.id, 
            ppos.id_root, 
            -1, 
            -1,
            -1,
			ARRAY[0],
            bquantity_object_add, 
            0, 
            false, 
            action_timestamp, 
            pclass.desc )
        RETURNING "id"  INTO outid;
    
    --Шаг №01.1 Расчитать баркод класса по идентификатору вещественного класса и обновить имя объекта по формату, определить массив пути объекта
	IF (setname) THEN
        UPDATE ONLY "bpd"."object" 
            SET
				"path_array" = ARRAY["outid"],
                "barcode_unit" = int.int_ean13_object_create("outid"),
                "name" = int.int_object_name_format("outid")
            WHERE id = "outid";
		
		--Шаг №01.2 Обновить штамп времени timestamp_child_change родительской позиции
		UPDATE ONLY "bpd"."position" 
			SET
				timestamp_child_change = action_timestamp
			WHERE (id = ppos.id) AND (timestamp_child_change <> action_timestamp);        
	ELSE 
		UPDATE ONLY "bpd"."object" 
            SET
                "barcode_unit" = int.int_ean13_object_create("outid")
            WHERE id = "outid";
	END IF;		
	
	--Шаг №03 Обновить штамп времени timestamp_child_change родительской позиции
	UPDATE ONLY "bpd"."position" 
		SET
			timestamp_child_change = action_timestamp
		WHERE id = ppos.id; 
        
    --Шаг №03 Обработка условий автоматизации  встраивания объектов значений объектных свойств
    --*******************************************
    --АВТОМАТИЗАЦИЯ ВСТРАИВАНИЯ ОБЪЕКТОВ НАЧАЛО                    
    --*******************************************
    FOR auto_object_prop_val IN SELECT * FROM "bpd"."vobject_prop_object_val" o WHERE o."id_object_carrier" = outid
    LOOP
        IF (auto_object_prop_val."embed_mode" = ANY(ARRAY[1,2])) THEN
            SELECT mc INTO i_mc FROM "bpd"."unit_conversion_rules" WHERE id = auto_object_prop_val."id_unit_conversion_rule";
            i_mc = COALESCE(i_mc, 1);
            --Автоматизация включена необходима тихое встраивание
            IF (auto_object_prop_val."embed_mode" = 1) THEN
                cur_quantity = COALESCE(auto_object_prop_val."bquantity_max", 0) * i_mc;
            ELSE    
                cur_quantity = COALESCE(auto_object_prop_val."bquantity_min", 0) * i_mc;
            END IF;
            IF (cur_quantity > 0) THEN
                IF NOT (auto_object_prop_val."embed_single") THEN
                    PERFORM "bpd"."object_prop_object_val_set_new"(outid, auto_object_prop_val."embed_class_real_id", auto_object_prop_val."id_class_prop_object_carrier", auto_object_prop_val."id_unit_conversion_rule", cur_quantity);
                ELSE
                    i = 0;
                    WHILE i < cur_quantity
                    LOOP
                        PERFORM "bpd"."object_prop_object_val_set_new"(outid, auto_object_prop_val."embed_class_real_id", auto_object_prop_val."id_class_prop_object_carrier", auto_object_prop_val."id_unit_conversion_rule", i_mc);
                        i = i + i_mc;
                    END LOOP;
                END IF;
            END IF;    
        END IF;
    END LOOP;
    --*******************************************
    --АВТОМАТИЗАЦИЯ ВСТРАИВАНИЯ ОБЪЕКТОВ КОНЕЦ                   
    --*******************************************
    END IF;    
    
    --************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************      
	perform error_exception( 'object_add', action_state);
END;
$BODY$;

ALTER FUNCTION bpd.object_add(bigint, bigint, integer, numeric, boolean)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION bpd.object_add(bigint, bigint, integer, numeric, boolean) TO bdu_object_insert;

GRANT EXECUTE ON FUNCTION bpd.object_add(bigint, bigint, integer, numeric, boolean) TO funcowner;

REVOKE ALL ON FUNCTION bpd.object_add(bigint, bigint, integer, numeric, boolean) FROM PUBLIC;

COMMENT ON FUNCTION bpd.object_add(bigint, bigint, integer, numeric, boolean)
    IS 'Функция создает объект';

---======================================================================================================

CREATE OR REPLACE FUNCTION "int".int_class_prop_inherit(
	iid_class_prop bigint,
	on_timestamp_class_upd boolean DEFAULT true)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    SET search_path=bpd, "int", py
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 06.02.2020
    --Версия: 5.0 (25.09.2020) -сохранение значений совпадающих по имени не наследованных свойств
    --Автор: Иванов Д.Ю.
    --Описание: Функция выполняет безусловное наследование указанного свойства класса (с переопределением по родителю)
    ----------:наследующими классами с переопределением одноименных неунаследованных свойств в унаследованные переопределенные
    --**************************************************************************
    inherited_prop "bpd"."class_prop"%ROWTYPE; -- НАСЛЕДУЕМОЕ СВОЙСТВО
    inheriting_class "bpd"."class"%ROWTYPE; -- НАСЛЕДУЮЩИЙ КЛАСС
    inheriting_prop "bpd"."class_prop"%ROWTYPE; -- НАСЛЕДУЮЩЕЕ СВОЙСТВО
    matching_name_prop "bpd"."class_prop"%ROWTYPE; --СВОЙСТВО НАСЛЕДУЮЩЕГО КЛАССА СОВПАДАЮЩЕЕ ПО ИМЕНИ СО СВОЙСТВОМ НАСЛЕДУЕМОГО КЛАССА И НЕ НАСЛЕДУЮЩЕЕ ОТ НЕГО
    global_prop_link "bpd"."global_prop_link_class_prop"; --Связанное глобальное свойство
    
    id_inheriting_prop BIGINT; -- Текущее наследующее свойство, созданное или обновляемое
    
    cur_on_override BOOLEAN; --Текущий флаг переопределяемости значения свойства, автоматически отключается для вещественных классов при создании наследующего свойства
    cur_on_inherit BOOLEAN; --Текущий флаг переопределяемости значения свойства, автоматически отключается для вещественных классов при создании наследующего свойства
    cur_id_class_definition BIGINT;--Текущий идентификатор класса определяющего свойство 
    cur_timestamp_class_definition timestamp; --Текущий штамп времени класса определяющего свойство  
    cur_id_prop_definition  BIGINT; --Текущий идентификатор определяющего свойства
    
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ РОДИТЕЛЬСКОГО КЛАССА
    class_prop_pattern_name  character varying; -- Уникальное имя класса паттерна
    class_prop_name_temp character varying; --Временная переменная для хранения промежуточных результатов
    n INTEGER DEFAULT 1;
    
    action_state character varying DEFAULT 'no_action'; --Результат обработки параметров цепи наследования свойств
    --**************************************************************************
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОПЕРАЦИИ
BEGIN 
    SELECT * INTO inherited_prop FROM ONLY "bpd"."class_prop" WHERE id = iid_class_prop;
    IF NOT (inherited_prop IS NULL) THEN
        
        --ШАГ №01 Определяем штамп времени текущей операции
            action_timestamp = LOCALTIMESTAMP(3);
            
        --Наследуемое свойство получено, обрабатываем в цикле перечень наследующих классов
        FOR inheriting_class IN SELECT * FROM ONLY "bpd"."class" c WHERE c.id_parent = inherited_prop.id_class
        LOOP
            --ШАГ №02.1 Выполняем поиск наследующего свойства входящего в цепь наследования текущего наследующего класса
            SELECT * INTO inheriting_prop FROM ONLY "bpd"."class_prop" cp WHERE (cp.id_class = inheriting_class.id) AND 
            (cp.id_prop_inherit = inherited_prop.id);
            
            --ШАГ №02.2 Выполняем поиск одноименных свойств в наследующем классе вне цепи наследования
                SELECT * INTO matching_name_prop  FROM ONLY "bpd"."class_prop" cp WHERE (cp.id_class = inheriting_class.id) AND 
                (cp.id_prop_inherit <> inherited_prop.id) AND (cp.name = inherited_prop.name);
            --********************************************************************
            --ШАГ №02.2 Анализ структуры списка свойств наследующего класса НАЧАЛО
            --********************************************************************
            IF ( inheriting_prop IS NULL) THEN
                --Наследующее свойство не найдено
                IF (matching_name_prop IS NULL) THEN
                    --Совпадение свойств по имени не найдено
                    action_state = 'inheriting_prop_add';
                ELSE
                    --Совпадение свойств по имени найдено
                    IF (matching_name_prop.id_prop_type <> inherited_prop.id_prop_type) OR 
                        (matching_name_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
                        --Тип найденного свойства и тип его  данных не совпадают с параметрами наследуемого свойства    
                        action_state = 'inheriting_prop_add_matching_name_prop_rename';
                    ELSE
                        action_state = 'matching_name_prop_connect';
                    END IF;    
                END IF;    
            ELSE
                --Наследующее свойство найдено
                IF (matching_name_prop IS NULL) THEN
                    --Совпадение свойств по имени не найдено
                    action_state = 'inheriting_prop_upd';
                ELSE
                    --Совпадение свойств по имени найдено
                    action_state = 'inheriting_prop_upd_matching_name_prop_rename';
                END IF;    
            END IF;
            --********************************************************************
            --ШАГ №02.2 Анализ структуры списка свойств наследующего класса КОНЕЦ
            --********************************************************************
            
            --ШАГ №03.1 Определяем параметры определяющего свойства для наследуемого свойства
            IF inherited_prop.inheritance THEN   
                cur_id_class_definition = inherited_prop.id_class_definition;
                cur_timestamp_class_definition = inherited_prop.timestamp_class_definition;
                cur_id_prop_definition = inherited_prop.id_prop_definition;
            ELSE
                cur_id_class_definition = inherited_prop.id_class;
                cur_timestamp_class_definition = inherited_prop.timestamp_class;
                cur_id_prop_definition = inherited_prop.id;
            END IF;
            
            CASE action_state
                WHEN 'inheriting_prop_add' THEN
                    --ШАГ №04.1 Определяем параметры переопределяемости наследующего свойства
                    cur_on_override = inherited_prop.on_override;
                    
                    --ШАГ №04.2 Определяем параметр on_inherit
                    cur_on_inherit = TRUE;
                    
                    --ШАГ №05 Наследуемое свойство отсуствует в цепи наследования наследующего класса, добовляем
                    INSERT INTO "bpd"."class_prop" ( 
                        "id_conception",
                        "id_class",
                        "timestamp_class", 
                        "id_prop_type",
                        "id_data_type",
                        "name",
                        "desc", 
                        "tag",
                        "sort",
                        
                        "on_inherit",
                        "inheritance",
                        "on_override", 
                        
                        "id_prop_inherit",
                        "timestamp_class_inherit",
                        
                        "id_class_definition",
                        "timestamp_class_definition",
                        "id_prop_definition") 
                    VALUES 
                        (inheriting_class.id_con,
                        inheriting_class.id, 
                        action_timestamp,
                        inherited_prop.id_prop_type, 
                        inherited_prop.id_data_type, 
                        inherited_prop.name, 
                        inherited_prop.desc, 
                        inherited_prop.tag, 
                        inherited_prop.sort,
                        
                        cur_on_inherit,
                        TRUE,
                        cur_on_override,
                        
                        inherited_prop.id,
                        inherited_prop.timestamp_class,
                        
                        cur_id_class_definition,
                        cur_timestamp_class_definition,
                        cur_id_prop_definition)
                    RETURNING "id"  INTO id_inheriting_prop;
                    id_inheriting_prop = COALESCE(id_inheriting_prop,0);  
                
                WHEN 'inheriting_prop_add_matching_name_prop_rename' THEN               
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS( SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE 
                        --Свойство дубликат является определяющим и может быть каскадно переименовано
                        --Определяем уникальное имя дубликата в цепи свойств наследующих классов
                        class_prop_name_temp =  matching_name_prop.name || ' - Дубликат';
                        n = 1;
                        LOOP
                            class_prop_pattern_name = concat( class_prop_name_temp,  '(', n, ')');
                            is_unique_name = NOT EXISTS( WITH 
                                            
                                            RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                (SELECT 
                                                    rc."id",
                                                    rc."id_parent",
                                                    0,
                                                    ARRAY [rc."id"],
                                                    false
                                                FROM ONLY "bpd"."class" rc
                                                WHERE rc."id" = inheriting_class.id
                                            UNION ALL
                                                SELECT 
                                                    rpc."id",
                                                    rpc."id_parent",
                                                    rclass."level" + 1,
                                                    rclass."patch" || ARRAY [rpc."id"],    
                                                    rpc."id" = ANY(rclass."patch")
                                                FROM ONLY "bpd"."class" rpc
                                                JOIN rclass ON rclass."id" = rpc."id_parent"
                                                WHERE NOT "cycle") 
                                            SELECT FROM ONLY "bpd"."class_prop" cp 
                                            JOIN rclass ON (rclass.id = cp.id_class)
                                            WHERE (cp.name = class_prop_pattern_name));
                            n = n + 1;                
                            IF is_unique_name THEN
                                EXIT;  -- выход из цикла
                            END IF;
                        END LOOP;
                        --Переименовываем дубликат с использованием полученного уникального имени
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        UPDATE ONLY  "bpd"."class_prop" dcp
                            SET
                                "name" = class_prop_pattern_name,
                                "timestamp_class" = action_timestamp
                        WHERE EXISTS(SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);                         
                    END IF;
                    
                    --ШАГ №04.2 Определяем параметры переопределяемости наследующего свойства раздельно для абстрактных и вещественных классов
                    IF (inheriting_class."on_abstraction") THEN
                        cur_on_override = inherited_prop.on_override;
                    ELSE
                        cur_on_override = FALSE;
                    END IF;  
                    
                    --ШАГ №04.3 Определяем параметр on_inherit
                    cur_on_inherit = TRUE;
                    
                    --ШАГ №05 Наследуемое свойство отсуствует в цепи наследования наследующего класса, добовляем
                    INSERT INTO "bpd"."class_prop" ( 
                        "id_conception",
                        "id_class",
                        "timestamp_class", 
                        "id_prop_type",
                        "id_data_type",
                        "name",
                        "desc", 
                        "tag",
                        "sort",
                        
                        "on_inherit",
                        "inheritance",
                        "on_override", 
                        
                        "id_prop_inherit",
                        "timestamp_class_inherit",
                        
                        "id_class_definition",
                        "timestamp_class_definition",
                        "id_prop_definition") 
                    VALUES 
                        (inheriting_class.id_con,
                        inheriting_class.id, 
                        action_timestamp,
                        inherited_prop.id_prop_type, 
                        inherited_prop.id_data_type, 
                        inherited_prop.name, 
                        inherited_prop.desc, 
                        inherited_prop.tag, 
                        inherited_prop.sort,
                        
                        cur_on_inherit,
                        TRUE,
                        cur_on_override,
                        
                        inherited_prop.id,
                        inherited_prop.timestamp_class,
                        
                        cur_id_class_definition,
                        cur_timestamp_class_definition,
                        cur_id_prop_definition)
                    RETURNING "id"  INTO id_inheriting_prop;
                    id_inheriting_prop = COALESCE(id_inheriting_prop,0); 
                                    
                WHEN 'matching_name_prop_connect' THEN
                    --ШАГ №04.00 Разрываем связь сопостовляемого свойства с глобальным при наличии
                    SELECT * INTO global_prop_link FROM bpd.global_prop_link_class_prop WHERE id_class_prop_definition = matching_name_prop.id;
                    IF NOT(global_prop_link IS NULL) THEN
                        PERFORM bpd.global_prop_link_class_prop_exclude(global_prop_link.id_class_prop_definition);
                    END IF;
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS(SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE
                        --ШАГ№4.2 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                        IF (inherited_prop.on_override) THEN
                            --без изменений
                            cur_on_override = matching_name_prop.on_override;
                            cur_on_inherit = matching_name_prop.on_inherit;
                        ELSE
                            --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                            cur_on_override = FALSE; --FALSE
                            cur_on_inherit = TRUE;
                        END IF;  
                        
                        --ШАГ №05 Выполняем сопоставление найденного свойства
                        UPDATE ONLY "bpd"."class_prop" 
                        SET 
                            "timestamp_class" = action_timestamp, 
                            
                            "id_class_definition" = cur_id_class_definition,
                            "timestamp_class_definition" = cur_timestamp_class_definition,
                            "id_prop_definition" = cur_id_prop_definition,
                            
                            "id_prop_inherit" = inherited_prop.id,
                            "timestamp_class_inherit" = inherited_prop.timestamp_class,
                            "desc" = inherited_prop.desc,
                            "tag" = inherited_prop.tag,
                            "sort" = inherited_prop.sort,
                            
                            "on_override" = cur_on_override,
                            "on_inherit" = cur_on_inherit,
                            "inheritance" = TRUE
                        WHERE id = matching_name_prop.id;
                    END IF; 
                WHEN 'inheriting_prop_upd' THEN
                    --ШАГ№5.1 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                    IF (inherited_prop.on_override) THEN
                        --без изменений
                        cur_on_override = inheriting_prop.on_override;
                        cur_on_inherit = inheriting_prop.on_inherit;
                    ELSE
                        --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                        cur_on_override = FALSE; --FALSE
                        cur_on_inherit = TRUE;
                    END IF; 
                    
                    --ШАГ №5.2 Обновляем наследующее свойство
                    UPDATE ONLY "bpd"."class_prop" SET 
                        "id_conception" = inheriting_class.id_con,
                        "id_class" = inheriting_class.id,
                        "timestamp_class" = action_timestamp, 
                        "id_prop_type" = inherited_prop.id_prop_type,
                        "id_data_type" = inherited_prop.id_data_type,
                        "name" = inherited_prop.name,
                        "desc" = inherited_prop.desc, 
                        "tag" = inherited_prop.tag, 
                        "sort" = inherited_prop.sort,
                        
                        "on_override" = cur_on_override,
                        "on_inherit" = cur_on_inherit,
                        "inheritance" = TRUE,
                        "id_prop_inherit" = inherited_prop.id,
                        "timestamp_class_inherit"  = inherited_prop.timestamp_class,
                        
                        "id_class_definition" = cur_id_class_definition,
                        "timestamp_class_definition" = cur_timestamp_class_definition,
                        "id_prop_definition" = cur_id_prop_definition
                    WHERE id = inheriting_prop.id;                
                    id_inheriting_prop = inheriting_prop.id;
                    
                    --ШАГ №05.3 Изменен тип свойства или тип данных свойства, удаляем существующие значения свойства
                    IF (inheriting_prop.id_prop_type <> inherited_prop.id_prop_type) OR (inheriting_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
						--Происходит изменение типа свойства или типа данных свойства.
						IF (inheriting_prop.id_prop_type = inherited_prop.id_prop_type) AND (inherited_prop."id_prop_type" = 1) THEN
							--Для пользовательского типа сохраняем значение
							CASE 
								WHEN (inheriting_prop."id_data_type" = 6) AND (inherited_prop.id_data_type = 3) THEN 
									--MONEY TO NUMERIC
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_numeric = val_money,
											id_data_type = 3
										WHERE
											"id_class_prop" = inheriting_prop.id;  

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_money = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 6) AND (inherited_prop.id_data_type = 1) THEN 
									--MONEY TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_money,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_money = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    	
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 2) AND (inherited_prop.id_data_type = 15) THEN 
									--INT4 TO INT8
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int8 = val_int4,
											id_data_type = 15
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 2) AND (inherited_prop.id_data_type = 1) THEN 
									--INT4 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_int4,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 3) AND (inherited_prop.id_data_type = 1) THEN 
									--NUMERIC TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_numeric,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_numeric = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 4) AND (inherited_prop.id_data_type = 1) THEN 
									--FLOAT4 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_float4,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************ 
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 5) AND (inherited_prop.id_data_type = 1) THEN 
									--FLOAT8 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_float8,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float8 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************ 
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 15) AND (inherited_prop.id_data_type = 1) THEN 
									--INT8 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_int8,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int8 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************ 
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 4) AND (inherited_prop.id_data_type = 5) THEN 
									--FLOAT4 TO FLOAT8
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float8 = val_float4,
											id_data_type = 5
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************ 
								ELSE 
									DELETE FROM ONLY "bpd"."class_prop_user_small_val"cpv
										WHERE
										"id_class_prop" = inheriting_prop.id;
									--************************************    
							END CASE;
						ELSE
							--В общем случае существующие значения удаляются
							DELETE FROM ONLY "bpd"."class_prop_user_big_val"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							DELETE FROM ONLY "bpd"."class_prop_user_small_val"
							WHERE
							"id_class_prop" = inheriting_prop.id;  
							--************************************    

							DELETE FROM ONLY "bpd"."class_prop_enum_val"
							WHERE
							"id_class_prop" = inheriting_prop.id;  
							--************************************    

							DELETE FROM ONLY "bpd"."class_prop_obj_val_class"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							--************************************

							DELETE FROM ONLY "bpd"."class_prop_link_val"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							--************************************
						END IF;
                    END IF;
                    
                WHEN 'inheriting_prop_upd_matching_name_prop_rename' THEN
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS( SELECT 1  FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE 
                        --Свойство дубликат является определяющим и может быть каскадно переименовано
                        --Определяем уникальное имя дубликата в цепи свойств наследующих классов
                        class_prop_name_temp =  matching_name_prop.name || ' - Дубликат';
                        n = 1;
                        LOOP
                            class_prop_pattern_name = concat( class_prop_name_temp,  '(', n, ')');
                            is_unique_name = NOT EXISTS( WITH 
                                            
                                            RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                (SELECT 
                                                    rc."id",
                                                    rc."id_parent",
                                                    0,
                                                    ARRAY [rc."id"],
                                                    false
                                                FROM ONLY "bpd"."class" rc
                                                WHERE rc."id" = inheriting_class.id
                                            UNION ALL
                                                SELECT 
                                                    rpc."id",
                                                    rpc."id_parent",
                                                    rclass."level" + 1,
                                                    rclass."patch" || ARRAY [rpc."id"],    
                                                    rpc."id" = ANY(rclass."patch")
                                                FROM ONLY "bpd"."class" rpc
                                                JOIN rclass ON rclass."id" = rpc."id_parent"
                                                WHERE NOT "cycle") 
                                            SELECT FROM ONLY "bpd"."class_prop" cp 
                                            JOIN rclass ON (rclass.id = cp.id_class)
                                            WHERE (cp.name = class_prop_pattern_name));
                            n = n + 1;                
                            IF is_unique_name THEN
                                EXIT;  -- выход из цикла
                            END IF;
                        END LOOP;
                        --Переименовываем дубликат с использованием полученного уникального имени
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        UPDATE ONLY  "bpd"."class_prop" dcp
                            SET
                                "name" = class_prop_pattern_name,
                                "timestamp_class" = action_timestamp
                        WHERE EXISTS(SELECT FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    END IF;
                    
                    --ШАГ№5.1 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                    IF (inherited_prop.on_override) THEN
                        --без изменений
                        cur_on_override = inheriting_prop.on_override;
                        cur_on_inherit = inheriting_prop.on_inherit;
                    ELSE
                        --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                        cur_on_override = FALSE; --FALSE
                        cur_on_inherit = TRUE;
                    END IF; 
                    
                    --ШАГ №5.2 Обновляем наследующее свойство
                    UPDATE ONLY "bpd"."class_prop" SET 
                        "id_conception" = inheriting_class.id_con,
                        "id_class" = inheriting_class.id,
                        "timestamp_class" = action_timestamp, 
                        "id_prop_type" = inherited_prop.id_prop_type,
                        "id_data_type" = inherited_prop.id_data_type,
                        "name" = inherited_prop.name,
                        "desc" = inherited_prop.desc, 
                        "tag" = inherited_prop.tag, 
                        "sort" = inherited_prop.sort,
                        
                        "on_override" = cur_on_override,
                        "on_inherit" = cur_on_inherit,
                        "inheritance" = TRUE,
                        "id_prop_inherit" = inherited_prop.id,
                        "timestamp_class_inherit"  = inherited_prop.timestamp_class,
                        
                        "id_class_definition" = cur_id_class_definition,
                        "timestamp_class_definition" = cur_timestamp_class_definition,
                        "id_prop_definition" = cur_id_prop_definition
                    WHERE id = inheriting_prop.id;                
                    id_inheriting_prop = inheriting_prop.id;
                    
                    --ШАГ №05.3 Изменен тип свойства или тип данных свойства, удаляем существующие значения свойства
                    IF (inheriting_prop.id_prop_type <> inherited_prop.id_prop_type) OR (inheriting_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
                        DELETE FROM ONLY "bpd"."class_prop_user_big_val"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        DELETE FROM ONLY "bpd"."class_prop_user_small_val"
                        WHERE
                        "id_class_prop" = inheriting_prop.id;  
                        --************************************    
                        
                        DELETE FROM ONLY "bpd"."class_prop_enum_val"
                        WHERE
                        "id_class_prop" = inheriting_prop.id;  
                        --************************************    
                        
                        DELETE FROM ONLY "bpd"."class_prop_obj_val_class"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        --************************************
                        
                        DELETE FROM ONLY "bpd"."class_prop_link_val"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        --************************************
                    END IF;
                ELSE
            END CASE;
            
            --ШАГ №06 Обновление штампа времени класса
            IF (on_timestamp_class_upd) THEN
                UPDATE ONLY "bpd"."class" c
                    SET 
                        "timestamp" = action_timestamp
                    WHERE (c.id = inheriting_class.id) AND (c."timestamp" <> action_timestamp);
            END IF; 
            --ШАГ №07 Выполняем синхронизацию наследуемого свойства в наследующих классах наследуемого класса (каскадно)        
            IF (id_inheriting_prop > 0) THEN
                PERFORM int_class_prop_inherit(id_inheriting_prop, on_timestamp_class_upd);
            END IF; 
        END LOOP;
    END IF;
END;    
$BODY$;

ALTER FUNCTION "int".int_class_prop_inherit(bigint, boolean)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_inherit(bigint, boolean) TO base_level WITH GRANT OPTION;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_inherit(bigint, boolean) TO funcowner;

REVOKE ALL ON FUNCTION "int".int_class_prop_inherit(bigint, boolean) FROM PUBLIC;

---======================================================================================================

-- FUNCTION: int.int_class_prop_inherit(bigint, bigint)

-- DROP FUNCTION IF EXISTS "int".int_class_prop_inherit(bigint, bigint);

CREATE OR REPLACE FUNCTION "int".int_class_prop_inherit(
	iid_class_prop bigint,
	iid_inheriting_class bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    SET search_path=bpd, "int", py
AS $BODY$
DECLARE
    --**************************************************************************
    --ДАТА: 07.07.2020
    --Версия: 2.0 (25.09.2020) -сохранение значений совпадающих по имени не наследованных свойств
    --Автор: Иванов Д.Ю.
    --Описание: Функция выполняет безусловное наследование указанного свойства УКАЗАННЫМ классом (с переопределением по родителю)
    ----------:наследующими классами с переопределением одноименных неунаследованных свойств в унаследованные переопределенные
    --**************************************************************************
    inherited_prop "bpd"."class_prop"%ROWTYPE; -- НАСЛЕДУЕМОЕ СВОЙСТВО
    inheriting_class "bpd"."class"%ROWTYPE; -- НАСЛЕДУЮЩИЙ КЛАСС
    inheriting_prop "bpd"."class_prop"%ROWTYPE; -- НАСЛЕДУЮЩЕЕ СВОЙСТВО
    matching_name_prop "bpd"."class_prop"%ROWTYPE; --СВОЙСТВО НАСЛЕДУЮЩЕГО КЛАССА СОВПАДАЮЩЕЕ ПО ИМЕНИ СО СВОЙСТВОМ НАСЛЕДУЕМОГО КЛАССА И НЕ НАСЛЕДУЮЩЕЕ ОТ НЕГО
    global_prop_link "bpd"."global_prop_link_class_prop"; --Связанное глобальное свойство
    
    id_inheriting_prop BIGINT; -- Текущее наследующее свойство, созданное или обновляемое
    
    cur_on_override BOOLEAN; --Текущий флаг переопределяемости значения свойства, автоматически отключается для вещественных классов при создании наследующего свойства
    cur_on_inherit BOOLEAN; --Текущий флаг переопределяемости значения свойства, автоматически отключается для вещественных классов при создании наследующего свойства
    cur_id_class_definition BIGINT;--Текущий идентификатор класса определяющего свойство 
    cur_timestamp_class_definition timestamp; --Текущий штамп времени класса определяющего свойство  
    cur_id_prop_definition  BIGINT; --Текущий идентификатор определяющего свойства
    
    is_unique_name BOOLEAN DEFAULT  FALSE; -- ИМЯ КЛАССА УНИКАЛЬНО В ПРЕДЕЛАХ РОДИТЕЛЬСКОГО КЛАССА
    class_prop_pattern_name  character varying; -- Уникальное имя класса паттерна
    class_prop_name_temp character varying; --Временная переменная для хранения промежуточных результатов
    n INTEGER DEFAULT 1;
    
    action_state character varying DEFAULT 'no_action'; --Результат обработки параметров цепи наследования свойств
    --**************************************************************************
    action_timestamp timestamp; --ШТАМП ВРЕМЕНИ ОПЕРАЦИИ
BEGIN 
    SELECT * INTO inherited_prop FROM ONLY "bpd"."class_prop" WHERE id = iid_class_prop;
    IF NOT (inherited_prop IS NULL) THEN
        
        --ШАГ №01 Определяем штамп времени текущей операции
        action_timestamp = LOCALTIMESTAMP(3);
            
        --Наследуемое свойство получено, обрабатываем наследующий класс
        SELECT * INTO inheriting_class FROM ONLY "bpd"."class" c WHERE c.id = iid_inheriting_class;
        
        IF NOT(inheriting_class IS NULL) THEN    
            
            --ШАГ №02.1 Выполняем поиск наследующего свойства входящего в цепь наследования текущего наследующего класса
            SELECT * INTO inheriting_prop FROM ONLY "bpd"."class_prop" cp WHERE (cp.id_class = inheriting_class.id) AND 
            (cp.id_prop_inherit = inherited_prop.id);
            
            --ШАГ №02.2 Выполняем поиск одноименных свойств в наследующем классе вне цепи наследования
                SELECT * INTO matching_name_prop  FROM ONLY "bpd"."class_prop" cp WHERE (cp.id_class = inheriting_class.id) AND 
                (cp.id_prop_inherit <> inherited_prop.id) AND (cp.name = inherited_prop.name);
            
            --********************************************************************
            --ШАГ №02.2 Анализ структуры списка свойств наследующего класса НАЧАЛО
            --********************************************************************
            IF ( inheriting_prop IS NULL) THEN
                --Наследующее свойство не найдено
                IF (matching_name_prop IS NULL) THEN
                    --Совпадение свойств по имени не найдено
                    action_state = 'inheriting_prop_add';
                ELSE
                    --Совпадение свойств по имени найдено
                    IF (matching_name_prop.id_prop_type <> inherited_prop.id_prop_type) OR 
                        (matching_name_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
                        --Тип найденного свойства и тип его  данных не совпадают с параметрами наследуемого свойства    
                        action_state = 'inheriting_prop_add_matching_name_prop_rename';
                    ELSE
                        action_state = 'matching_name_prop_connect';
                    END IF;    
                END IF;    
            ELSE
                --Наследующее свойство найдено
                IF (matching_name_prop IS NULL) THEN
                    --Совпадение свойств по имени не найдено
                    action_state = 'inheriting_prop_upd';
                ELSE
                    --Совпадение свойств по имени найдено
                    action_state = 'inheriting_prop_upd_matching_name_prop_rename';
                END IF;    
            END IF;
            --********************************************************************
            --ШАГ №02.2 Анализ структуры списка свойств наследующего класса КОНЕЦ
            --********************************************************************
            
			--ШАГ №03.1 Определяем параметры определяющего свойства для наследуемого свойства
            IF inherited_prop.inheritance THEN   
                cur_id_class_definition = inherited_prop.id_class_definition;
                cur_timestamp_class_definition = inherited_prop.timestamp_class_definition;
                cur_id_prop_definition = inherited_prop.id_prop_definition;
            ELSE
                cur_id_class_definition = inherited_prop.id_class;
                cur_timestamp_class_definition = inherited_prop.timestamp_class;
                cur_id_prop_definition = inherited_prop.id;
            END IF;
            
            CASE action_state
                WHEN 'inheriting_prop_add' THEN
                    --ШАГ №04.1 Определяем параметры переопределяемости наследующего свойства
                    cur_on_override = inherited_prop.on_override;
                    
                    --ШАГ №04.2 Определяем параметр on_inherit
                    cur_on_inherit = TRUE;
                    
                    --ШАГ №05 Наследуемое свойство отсуствует в цепи наследования наследующего класса, добовляем
                    INSERT INTO "bpd"."class_prop" ( 
                        "id_conception",
                        "id_class",
                        "timestamp_class", 
                        "id_prop_type",
                        "id_data_type",
                        "name",
                        "desc", 
                        "tag",
                        "sort",
                        
                        "on_inherit",
                        "inheritance",
                        "on_override", 
                        
                        "id_prop_inherit",
                        "timestamp_class_inherit",
                        
                        "id_class_definition",
                        "timestamp_class_definition",
                        "id_prop_definition") 
                    VALUES 
                        (inheriting_class.id_con,
                        inheriting_class.id, 
                        action_timestamp,
                        inherited_prop.id_prop_type, 
                        inherited_prop.id_data_type, 
                        inherited_prop.name, 
                        inherited_prop.desc, 
                        inherited_prop.tag, 
                        inherited_prop.sort,
                        
                        cur_on_inherit,
                        TRUE,
                        cur_on_override,
                        
                        inherited_prop.id,
                        inherited_prop.timestamp_class,
                        
                        cur_id_class_definition,
                        cur_timestamp_class_definition,
                        cur_id_prop_definition)
                    RETURNING "id"  INTO id_inheriting_prop;
                    id_inheriting_prop = COALESCE(id_inheriting_prop,0);  
                
                WHEN 'inheriting_prop_add_matching_name_prop_rename' THEN               
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS( SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE 
                        --Свойство дубликат является определяющим и может быть каскадно переименовано
                        --Определяем уникальное имя дубликата в цепи свойств наследующих классов
                        class_prop_name_temp =  matching_name_prop.name || ' - Дубликат';
                        n = 1;
                        LOOP
                            class_prop_pattern_name = concat( class_prop_name_temp,  '(', n, ')');
                            is_unique_name = NOT EXISTS( WITH 
                                            RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                (SELECT 
                                                    rc."id",
                                                    rc."id_parent",
                                                    0,
                                                    ARRAY [rc."id"],
                                                    false
                                                FROM ONLY "bpd"."class" rc
                                                WHERE rc."id" = inheriting_class.id
                                            UNION ALL
                                                SELECT 
                                                    rpc."id",
                                                    rpc."id_parent",
                                                    rclass."level" + 1,
                                                    rclass."patch" || ARRAY [rpc."id"],    
                                                    rpc."id" = ANY(rclass."patch")
                                                FROM ONLY "bpd"."class" rpc
                                                JOIN rclass ON rclass."id" = rpc."id_parent"
                                                WHERE NOT "cycle") 
                                            SELECT FROM ONLY "bpd"."class_prop" cp 
                                            JOIN rclass ON (rclass.id = cp.id_class)
                                            WHERE (cp.name = class_prop_pattern_name));
                            n = n + 1;                
                            IF is_unique_name THEN
                                EXIT;  -- выход из цикла
                            END IF;
                        END LOOP;
                        --Переименовываем дубликат с использованием полученного уникального имени
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        UPDATE ONLY  "bpd"."class_prop" dcp
                            SET
                                "name" = class_prop_pattern_name,
                                "timestamp_class" = action_timestamp
                        WHERE EXISTS(SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);                         
                    END IF;
                    
                    --ШАГ №04.2 Определяем параметры переопределяемости наследующего свойства раздельно для абстрактных и вещественных классов
                    IF (inheriting_class."on_abstraction") THEN
                        cur_on_override = inherited_prop.on_override;
                    ELSE
                        cur_on_override = FALSE;
                    END IF;  
                    
                    --ШАГ №04.3 Определяем параметр on_inherit
                    cur_on_inherit = TRUE;
                    
                    --ШАГ №05 Наследуемое свойство отсуствует в цепи наследования наследующего класса, добовляем
                    INSERT INTO "bpd"."class_prop" ( 
                        "id_conception",
                        "id_class",
                        "timestamp_class", 
                        "id_prop_type",
                        "id_data_type",
                        "name",
                        "desc", 
                        "tag",
                        "sort",
                        
                        "on_inherit",
                        "inheritance",
                        "on_override", 
                        
                        "id_prop_inherit",
                        "timestamp_class_inherit",
                        
                        "id_class_definition",
                        "timestamp_class_definition",
                        "id_prop_definition") 
                    VALUES 
                        (inheriting_class.id_con,
                        inheriting_class.id, 
                        action_timestamp,
                        inherited_prop.id_prop_type, 
                        inherited_prop.id_data_type, 
                        inherited_prop.name, 
                        inherited_prop.desc, 
                        inherited_prop.tag, 
                        inherited_prop.sort,
                        
                        cur_on_inherit,
                        TRUE,
                        cur_on_override,
                        
                        inherited_prop.id,
                        inherited_prop.timestamp_class,
                        
                        cur_id_class_definition,
                        cur_timestamp_class_definition,
                        cur_id_prop_definition)
                    RETURNING "id"  INTO id_inheriting_prop;
                    id_inheriting_prop = COALESCE(id_inheriting_prop,0); 
                                    
                WHEN 'matching_name_prop_connect' THEN
                    --ШАГ №04.00 Разрываем связь сопостовляемого свойства с глобальным при наличии
                    SELECT * INTO global_prop_link FROM bpd.global_prop_link_class_prop WHERE id_class_prop_definition = matching_name_prop.id;
                    IF NOT(global_prop_link IS NULL) THEN
                        PERFORM bpd.global_prop_link_class_prop_exclude(global_prop_link.id_class_prop_definition);
                    END IF;
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS(SELECT 1 FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE
                        --ШАГ№4.2 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                        IF (inherited_prop.on_override) THEN
                            --без изменений
                            cur_on_override = matching_name_prop.on_override;
                            cur_on_inherit = matching_name_prop.on_inherit;
                        ELSE
                            --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                            cur_on_override = FALSE; --FALSE
                            cur_on_inherit = TRUE;
                        END IF;  
                        
                        --ШАГ №05 Выполняем сопоставление найденного свойства
                        UPDATE ONLY "bpd"."class_prop" 
                        SET 
                            "id_conception" = inheriting_class.id_con,
                            "id_class" = inheriting_class.id,
                            "timestamp_class" = action_timestamp, 
                            
                            "id_class_definition" = cur_id_class_definition,
                            "timestamp_class_definition" = cur_timestamp_class_definition,
                            "id_prop_definition" = cur_id_prop_definition,
                            
                            "id_prop_inherit" = inherited_prop.id,
                            "timestamp_class_inherit" = inherited_prop.timestamp_class,
                            "desc" = inherited_prop.desc,
                            "tag" = inherited_prop.tag,
                            "sort" = inherited_prop.sort,
                            
                            "on_override" = cur_on_override,
                            "on_inherit" = cur_on_inherit,
                            "inheritance" = TRUE
                        WHERE id = matching_name_prop.id;
                    END IF; 
                WHEN 'inheriting_prop_upd' THEN
                    --ШАГ№5.1 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                    IF (inherited_prop.on_override) THEN
                        --без изменений
                        cur_on_override = inheriting_prop.on_override;
                        cur_on_inherit = inheriting_prop.on_inherit;
                    ELSE
                        --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                        cur_on_override = FALSE; --FALSE
                        cur_on_inherit = TRUE;
                    END IF; 
                    
                    --ШАГ №5.2 Обновляем наследующее свойство
                    UPDATE ONLY "bpd"."class_prop" SET 
                        "id_conception" = inheriting_class.id_con,
                        "id_class" = inheriting_class.id,
                        "timestamp_class" = action_timestamp, 
                        
                        "id_prop_type" = inherited_prop.id_prop_type,
                        "id_data_type" = inherited_prop.id_data_type,
                        "name" = inherited_prop.name,
                        "desc" = inherited_prop.desc, 
                        "tag" = inherited_prop.tag, 
                        "sort" = inherited_prop.sort,
                        
                        "on_override" = cur_on_override,
                        "on_inherit" = cur_on_inherit,
                        "inheritance" = TRUE,
                        "id_prop_inherit" = inherited_prop.id,
                        "timestamp_class_inherit"  = inherited_prop.timestamp_class,
                        
                        "id_class_definition" = cur_id_class_definition,
                        "timestamp_class_definition" = cur_timestamp_class_definition,
                        "id_prop_definition" = cur_id_prop_definition
                    WHERE id = inheriting_prop.id;                
                    id_inheriting_prop = inheriting_prop.id;
                    
                    --ШАГ №05.3 Изменен тип свойства или тип данных свойства, удаляем существующие значения свойства
                    IF (inheriting_prop.id_prop_type <> inherited_prop.id_prop_type) OR (inheriting_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
                        --Происходит изменение типа свойства или типа данных свойства.
						IF (inheriting_prop.id_prop_type = inherited_prop.id_prop_type) AND (inherited_prop."id_prop_type" = 1) THEN
							--Для пользовательского типа сохраняем значение
							CASE 
								WHEN (inheriting_prop."id_data_type" = 6) AND (inherited_prop.id_data_type = 3) THEN 
									--MONEY TO NUMERIC
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_numeric = val_money,
											id_data_type = 3
										WHERE
											"id_class_prop" = inheriting_prop.id;  

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_money = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 6) AND (inherited_prop.id_data_type = 1) THEN 
									--MONEY TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_money,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_money = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    	
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 2) AND (inherited_prop.id_data_type = 15) THEN 
									--INT4 TO INT8
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int8 = val_int4,
											id_data_type = 15
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    
										--************************************    

								WHEN (inheriting_prop."id_data_type" = 2) AND (inherited_prop.id_data_type = 1) THEN 
									--INT4 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_int4,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************    
										--************************************    

								WHEN (inheriting_prop."id_data_type" = 3) AND (inherited_prop.id_data_type = 1) THEN 
									--NUMERIC TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_numeric,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_numeric = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************   
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 4) AND (inherited_prop.id_data_type = 1) THEN 
									--FLOAT4 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_float4,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 5) AND (inherited_prop.id_data_type = 1) THEN 
									--FLOAT8 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_float8,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float8 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 15) AND (inherited_prop.id_data_type = 1) THEN 
									--INT8 TO VARCHAR
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_varchar = val_int8,
											id_data_type = 1
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_int8 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************  
									--************************************    

								WHEN (inheriting_prop."id_data_type" = 4) AND (inherited_prop.id_data_type = 5) THEN 
									--FLOAT4 TO FLOAT8
									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float8 = val_float4,
											id_data_type = 5
										WHERE
											"id_class_prop" = inheriting_prop.id;

									UPDATE ONLY "bpd"."class_prop_user_small_val"
										SET
											val_float4 = NULL 
										WHERE
											"id_class_prop" = inheriting_prop.id;
									--************************************  
								ELSE 
									DELETE FROM ONLY "bpd"."class_prop_user_small_val"cpv
										WHERE
										"id_class_prop" = inheriting_prop.id;
									--************************************    
							END CASE;
						ELSE
							--В общем случае существующие значения удаляются
							DELETE FROM ONLY "bpd"."class_prop_user_big_val"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							DELETE FROM ONLY "bpd"."class_prop_user_small_val"
							WHERE
							"id_class_prop" = inheriting_prop.id;  
							--************************************    

							DELETE FROM ONLY "bpd"."class_prop_enum_val"
							WHERE
							"id_class_prop" = inheriting_prop.id;  
							--************************************    

							DELETE FROM ONLY "bpd"."class_prop_obj_val_class"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							--************************************

							DELETE FROM ONLY "bpd"."class_prop_link_val"
							WHERE
								"id_class_prop" = inheriting_prop.id;  
							--************************************
						END IF;
                    END IF;
                    
                WHEN 'inheriting_prop_upd_matching_name_prop_rename' THEN
                    
                    --ШАГ №04.1 Определяем действие с дубликатом
                    IF (matching_name_prop.inheritance) THEN 
                        --Свойство дубликат наследовано и не может быть переопределено
                        --Для обеспечения структурной целостности цепочек данных удаляем
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        DELETE FROM ONLY  "bpd"."class_prop" dcp 
                        WHERE EXISTS( SELECT 1  FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    ELSE 
                        --Свойство дубликат является определяющим и может быть каскадно переименовано
                        --Определяем уникальное имя дубликата в цепи свойств наследующих классов
                        class_prop_name_temp =  matching_name_prop.name || ' - Дубликат';
                        n = 1;
                        LOOP
                            class_prop_pattern_name = concat( class_prop_name_temp,  '(', n, ')');
                            is_unique_name = NOT EXISTS( WITH 
                                            
                                            RECURSIVE rclass ("id", "id_parent", "level", "patch", "cycle") AS 
                                                (SELECT 
                                                    rc."id",
                                                    rc."id_parent",
                                                    0,
                                                    ARRAY [rc."id"],
                                                    false
                                                FROM ONLY "bpd"."class" rc
                                                WHERE rc."id" = inheriting_class.id
                                            UNION ALL
                                                SELECT 
                                                    rpc."id",
                                                    rpc."id_parent",
                                                    rclass."level" + 1,
                                                    rclass."patch" || ARRAY [rpc."id"],    
                                                    rpc."id" = ANY(rclass."patch")
                                                FROM ONLY "bpd"."class" rpc
                                                JOIN rclass ON rclass."id" = rpc."id_parent"
                                                WHERE NOT "cycle") 
                                            SELECT FROM ONLY "bpd"."class_prop" cp 
                                            JOIN rclass ON (rclass.id = cp.id_class)
                                            WHERE (cp.name = class_prop_pattern_name));
                            n = n + 1;                
                            IF is_unique_name THEN
                                EXIT;  -- выход из цикла
                            END IF;
                        END LOOP;
                        --Переименовываем дубликат с использованием полученного уникального имени
                        WITH 
                            RECURSIVE rclass_prop ("id", "id_prop_inherit", "level", "patch", "cycle") AS 
                                (SELECT 
                                    rcp."id",
                                    rcp."id_prop_inherit",
                                    0,
                                    ARRAY [rcp."id"],
                                    false
                                FROM ONLY "bpd"."class_prop" rcp
                                WHERE (rcp.id = matching_name_prop.id)
                            UNION ALL
                                SELECT 
                                    rpcp."id",
                                    rpcp."id_prop_inherit",
                                    rclass_prop."level" + 1,
                                    rclass_prop."patch" || ARRAY [rpcp."id"],    
                                    rpcp."id" = ANY(rclass_prop."patch")
                                FROM ONLY "bpd"."class_prop" rpcp
                                JOIN rclass_prop ON rclass_prop."id" = rpcp."id_prop_inherit"
                                WHERE NOT "cycle") 
                        UPDATE ONLY  "bpd"."class_prop" dcp
                            SET
                                "name" = class_prop_pattern_name,
                                "timestamp_class" = action_timestamp
                        WHERE EXISTS(SELECT FROM rclass_prop WHERE rclass_prop.id = dcp.id);
                    END IF;
                    
                    --ШАГ№5.1 Определяем параметры переопределяемости наследующего свойства в зависмости от переопределяемости наследуемого
                    IF (inherited_prop.on_override) THEN
                        --без изменений
                        cur_on_override = inheriting_prop.on_override;
                        cur_on_inherit = inheriting_prop.on_inherit;
                    ELSE
                        --Наследуемое свойство не переопределяемое, наследующее свойство не переопределяемое и наследует значение
                        cur_on_override = FALSE; --FALSE
                        cur_on_inherit = TRUE;
                    END IF; 
                    
                    --ШАГ №5.2 Обновляем наследующее свойство
                    UPDATE ONLY "bpd"."class_prop" SET 
                        "id_conception" = inheriting_class.id_con,
                        "id_class" = inheriting_class.id,
                        "timestamp_class" = action_timestamp, 
                        "id_prop_type" = inherited_prop.id_prop_type,
                        "id_data_type" = inherited_prop.id_data_type,
                        "name" = inherited_prop.name,
                        "desc" = inherited_prop.desc, 
                        "tag" = inherited_prop.tag, 
                        "sort" = inherited_prop.sort,
                        
                        "on_override" = cur_on_override,
                        "on_inherit" = cur_on_inherit,
                        "inheritance" = TRUE,
                        "id_prop_inherit" = inherited_prop.id,
                        "timestamp_class_inherit"  = inherited_prop.timestamp_class,
                        
                        "id_class_definition" = cur_id_class_definition,
                        "timestamp_class_definition" = cur_timestamp_class_definition,
                        "id_prop_definition" = cur_id_prop_definition
                    WHERE id = inheriting_prop.id;                
                    id_inheriting_prop = inheriting_prop.id;
                    
                    --ШАГ №05.3 Изменен тип свойства или тип данных свойства, удаляем существующие значения свойства
                    IF (inheriting_prop.id_prop_type <> inherited_prop.id_prop_type) OR (inheriting_prop."id_data_type" <> inherited_prop.id_data_type)  THEN
                        DELETE FROM ONLY "bpd"."class_prop_user_big_val"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        DELETE FROM ONLY "bpd"."class_prop_user_small_val"
                        WHERE
                        "id_class_prop" = inheriting_prop.id;  
                        --************************************    
                        
                        DELETE FROM ONLY "bpd"."class_prop_enum_val"
                        WHERE
                        "id_class_prop" = inheriting_prop.id;  
                        --************************************    
                        
                        DELETE FROM ONLY "bpd"."class_prop_obj_val_class"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        --************************************
                        
                        DELETE FROM ONLY "bpd"."class_prop_link_val"
                        WHERE
                            "id_class_prop" = inheriting_prop.id;  
                        --************************************
                    END IF;
                ELSE
            END CASE;
            
            --ШАГ №06 Обновление штампа времени класса
            
            UPDATE ONLY "bpd"."class" c
                SET 
                    "timestamp" = action_timestamp
                WHERE (c.id = inheriting_class.id) AND (c."timestamp" <> action_timestamp);
            
            --ШАГ №07 Выполняем синхронизацию наследуемого свойства в наследующих классах наследуемого класса (каскадно)        
             IF (id_inheriting_prop > 0) THEN
                PERFORM int_class_prop_inherit(id_inheriting_prop);
            END IF;         
        END IF;
    END IF;
END;    
$BODY$;

ALTER FUNCTION "int".int_class_prop_inherit(bigint, bigint)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_inherit(bigint, bigint) TO base_level WITH GRANT OPTION;

GRANT EXECUTE ON FUNCTION "int".int_class_prop_inherit(bigint, bigint) TO funcowner;

REVOKE ALL ON FUNCTION "int".int_class_prop_inherit(bigint, bigint) FROM PUBLIC;

---======================================================================================================

-- FUNCTION: bpd.group_move(bigint, bigint)

-- DROP FUNCTION IF EXISTS bpd.group_move(bigint, bigint);

CREATE OR REPLACE FUNCTION bpd.group_move(
	iid bigint,
	iid_parent bigint)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE SECURITY DEFINER PARALLEL UNSAFE
    SET search_path=bpd, ext, err
AS $BODY$

DECLARE
    --ОГРАНИЧЕНИЯ МЕТОДА
    --1. Нельзя изменить концепцию группы
    --2. Нельзя переместить корзину
    --3. Нельзя переместить группу во вложенные в группу группы или в саму себя
    --4. Нельзя переносить группу содержащую классы в пространство корзины
    --**************************************************************************
    --ДАТА: 13.06.2020
    --Версия: 2.1 
    --Автор: Иванов Д.Ю.
    --Описание: Функция перемещает группу
    --**************************************************************************
    group_recycle "bpd"."group"%ROWTYPE; --Группа корзины концепции
    
    mgroup "bpd"."group"%ROWTYPE; --Переносимая группа
    mgroup_name_is_unique BOOLEAN DEFAULT  FALSE; -- Имя переносимой группы уникально в указанном расположении
    
    pgroup "bpd"."group"%ROWTYPE; --Новая родительская группа
    pgroup_is_recycle BOOLEAN DEFAULT FALSE; --целевая группа корзина
    
    --1. Не допускается перенос группы в саму себя
    --2. Недопускается перенос группы в дочерниии группы
    on_moving_correct BOOLEAN DEFAULT FALSE; --перенос коррктен и отвечает базовым правилам построения дерева
    
    iid_moved_class BIGINT; -- ИДЕНТИФИКАТОРЫ ПЕРЕМЕЩЕННЫХ КЛАССОВ
    
    childgroup RECORD; -- дочерние группы переносимой группы
    
    action_timestamp timestamp; -- Время создания группы
    action_state character varying DEFAULT 'none'; --Статус действия    
BEGIN
    --ВЫБИРАЕМ ГРУППУ ПОДЛЕЖАЩУЮ ПЕРЕНОСУ
    SELECT * INTO mgroup FROM "bpd"."group" WHERE id = iid;
    IF (mgroup IS NULL) THEN
        action_state = 'group_moved_not_found';
    ELSE
        --ОПРЕДЕЛЯЕМ ГРУПУУ КОРЗИНЫ ТЕКУЩЕЙ КОНЦЕПЦИИ
        SELECT g.* INTO   group_recycle   FROM "bpd"."group" g 
        JOIN "bpd"."conception" c ON c.id = g.id_con
        WHERE g.id = c.group_recycle AND c.id = mgroup.id_con;
        --ОПРЕДЕЛЯЕМ ЯВЛЯЕТСЯ ЛИ ПЕРЕНОСИМАЯ ГРУППА КОРЗИНОЙ
        IF (mgroup.id = group_recycle.id) THEN
            action_state = 'group_moved_is_recycle';
        ELSE
            --ОПРЕДЕЛЯЕМ ЯВЛЯЕТСЯ ЛИ НОВОЕ РОДИТЕЛЬСКАЯ ПОЗИЦИЯ КОРЗИНОЙ ИЛИ УДАЛЕННОЙ ГРУППОЙ
            IF (iid_parent > 0) THEN
                SELECT * INTO pgroup FROM "bpd"."group" WHERE id = iid_parent;
                IF (pgroup IS NULL) THEN
                    action_state = 'group_target_not_found';
                ELSE
                    IF (mgroup.id_con <> pgroup.id_con) THEN
                        action_state = 'conception_not_match';
                    ELSE    
                        --Проверяем является ли целевая группа корзиной или входит в корзину
                        IF (group_recycle.id = pgroup.id) THEN
                            pgroup_is_recycle = TRUE;
                            action_state = 'moved_allowed';
                        ELSE
                            IF (group_recycle.id = pgroup.id_root) THEN
                                action_state = 'group_target_in_recycle_space';
                            ELSE
                                IF (pgroup.on_class) THEN
                                    action_state = 'group_target_not_include_child_group';
                                ELSE
                                    action_state = 'moved_allowed';
                                END IF;        
                            END IF;    
                        END IF; 
                    END IF;    
                END IF;
            ELSE
                IF (iid_parent = 0) THEN
                    action_state = 'moved_allowed';
                END IF;    
            END IF;    
        END IF;

        IF (action_state = 'moved_allowed') THEN
            --ОПРЕДЕЛЯЕМ ДОПУСТИМОСТЬ ИМЕНИ ПЕРЕНОСИМОЙ ПОЗИЦИИ В НОВОМ РАСПОЛОЖЕНИИ
            IF (pgroup_is_recycle ) THEN
                mgroup_name_is_unique = TRUE;
            ELSE    
                mgroup_name_is_unique = NOT EXISTS(SELECT FROM "bpd"."group" g
                                    WHERE (LOWER(g."name") = LOWER(mgroup.name)) AND (g.id_con = mgroup.id_con) AND (g.id_parent = iid_parent));
            END IF;

            IF NOT(mgroup_name_is_unique) THEN
                action_state = 'group_moved_name_not_unique';
            ELSE
                --ОПРЕДЕЛЯЕМ СПИСОК ГРУПП ПОДЛЕЖАЩИХ ПЕРЕНОСУ
                CREATE TEMP TABLE groupmove ON COMMIT DROP AS
                WITH 
                    RECURSIVE rpos ("id", "id_parent", "level", "path", "cycle") AS 
                        (SELECT 
                            rp."id",
                            rp."id_parent",
                            0,
                            ARRAY [rp."id"],
                            FALSE
                        FROM "bpd"."group" rp
                        WHERE rp."id" = iid
                    UNION all
                        SELECT 
                            rpc.id,
                            rpc.id_parent,
                            rpos.level + 1,
                            rpos.path || ARRAY [rpc.id],    
                            rpc.id = ANY(rpos.path)
                        FROM "bpd"."group" rpc
                        JOIN rpos ON rpos."id" = rpc."id_parent"
                        WHERE NOT "cycle") 
                    SELECT * FROM rpos;

                IF iid_parent > 0 THEN
                    --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС В СУЩЕСТВУЮЩЕЕ РАСПОЛОЖЕНИЕ
                    IF (mgroup.id_parent <> iid_parent) THEN 
                        --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС ВО ВЛОЖЕННЫЕ ГРУППЫ ПЕРЕНОСИМОЙ ГРУППЫ ИЛИ САМОЙ В СЕБЯ
                        on_moving_correct = NOT EXISTS (SELECT FROM groupmove gm WHERE gm.id = iid_parent);
                    ELSE    
                        on_moving_correct = FALSE;
                    END IF;
                ELSE
                    IF (iid_parent = 0) THEN        
                        --НЕ ВЫПОЛНЯЕТСЯ ПЕРЕНОС В СУЩЕСТВУЮЩЕЕ РАСПОЛОЖЕНИЕ
                        IF (mgroup.id_parent > 0 )THEN 
                            --ПОЗИЦИЯ ПЕРЕНОСИТСЯ В КОРЕНЬ И НЕ БЛОКИРОВАНА
                            on_moving_correct = TRUE;
                        END IF;
                    END IF;
                END IF;
                
                IF NOT(on_moving_correct) THEN
                    action_state = 'group_moved_target_path_not_correct';
                ELSE
                    action_state = 'action_allowed';
                END IF;

                IF (action_state = 'action_allowed') THEN
                --Если позиция перенесена но не нарушены правила вложенности вносим изменения и нет блокировок удаления
                --ШАГ №00 Формирование обновленного штампа времени
                    action_timestamp = LOCALTIMESTAMP(3);
                    IF iid_parent > 0 THEN
                    --ШАГ №01 Преносим группу
                        UPDATE bpd."group" SET
                            "id_parent" = iid_parent,
                            "timestamp" = action_timestamp
                        WHERE
                            "id" = iid;
                    --ШАГ №02 Переопределяем уровни вложенности для дочерних групп    
                        UPDATE "bpd"."group" g
                            SET 
                                "id_root" = pgroup."id_root", 
                                "level" = (pgroup.level +   groupmove.level + 1),
                                "path_array" = pgroup.path_array || groupmove.path,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = g."id";
                                    
                    --ШАГ №03 Переопределяем корневую группу для вложенных классов и Отключаем признак белого списка в классах 
                        UPDATE ONLY "bpd"."class" c
                            SET 
                                "id_group_root" = pgroup."id_root",
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = c."id_group";

					--ШАГ №03.1 Очищаем белый список разрешений уровня 2 класс на позицию
                        DELETE FROM "bpd"."rulel2_class_on_position" rl2
                            WHERE EXISTS(SELECT FROM ONLY "bpd"."class" c
                            JOIN groupmove gm ON gm.id = c.id_group
                            WHERE rl2.id_class = c.id);
                    
					--Шаг №04.1 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
                        FOR iid_moved_class IN SELECT id FROM ONLY "bpd"."class" c 
                            WHERE EXISTS(SELECT FROM groupmove 
                                WHERE groupmove.id = c."id_group")
                            LOOP 
                            PERFORM int.int_sync_timestamp_by_id_class(iid_moved_class);       
                        END LOOP;
                    
					--Шаг №04.2 Обновить штамп времени timestamp_child_change бывшей и новой родительских групп
                        UPDATE "bpd"."group" 
                            SET
                                timestamp_child_change = action_timestamp
                            WHERE (id = mgroup.id_parent) OR id = (iid_parent);
                    END IF;    
                
                    IF iid_parent = 0 THEN
                    --ШАГ №01 Преносим группу
                        UPDATE bpd."group" 
                            SET
                            "id_root" = iid, 
                            "id_parent" = 0,
                            "level" = 0,
                            "timestamp" = action_timestamp
                        WHERE "id" = iid;
                    
					--ШАГ №02 Переопределяем уровни вложенности для дочерних групп 
                        UPDATE "bpd"."group" g
                            SET 
                                "id_root" = iid, 
                                "level" = groupmove.level,
                                "path_array" = groupmove.path,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                        WHERE groupmove.id = g."id" AND   mgroup.id <> iid;
                            
                    --ШАГ №03 Переопределяем корневую группу для вложенных классов
                        UPDATE ONLY "bpd"."class" c
                            SET 
                                "id_group_root" = iid,
                                "timestamp" = action_timestamp
                            FROM groupmove 
                            WHERE groupmove.id = c."id_group";
                            
                    --ШАГ №03.1 Очищаем белый список разрешений уровня 2 класс на позицию
                        DELETE FROM "bpd"."rulel2_class_on_position" rl2
                            WHERE EXISTS(SELECT  FROM ONLY "bpd"."class" c
                            JOIN groupmove gm ON gm.id = c.id_group
                            WHERE rl2.id_class = c.id);
                    
					--Шаг №04 Синхронизировать штамп времени активного класса, всех наследующих классов и их свойств    
                        FOR iid_moved_class IN SELECT id FROM ONLY "bpd"."class" c 
                            WHERE EXISTS(SELECT  FROM groupmove 
                            WHERE groupmove.id = c."id_group")
                        LOOP 
                            PERFORM int.int_sync_timestamp_by_id_class(iid_moved_class);       
                        END LOOP;    
                    
					--Шаг №04.1 Обновить штамп времени timestamp_child_change бывшей родительской группы
                        UPDATE ONLY "bpd"."group" 
                            SET
                                timestamp_child_change = action_timestamp
                            WHERE id = mgroup.id_parent;
                    END IF;        
                END IF;
            END IF;
        END IF;            
    END IF;
        
	--************************************************************
	----------------ОБЛАСТЬ ФОРМИРОВАНИЯ ИСКЛЮЧЕНИЙ
	--************************************************************
    perform error_exception( 'group_move', action_state);
END;
$BODY$;

ALTER FUNCTION bpd.group_move(bigint, bigint)
    OWNER TO funcowner;

GRANT EXECUTE ON FUNCTION bpd.group_move(bigint, bigint) TO bdu_group_update;

GRANT EXECUTE ON FUNCTION bpd.group_move(bigint, bigint) TO funcowner;

REVOKE ALL ON FUNCTION bpd.group_move(bigint, bigint) FROM PUBLIC;

COMMENT ON FUNCTION bpd.group_move(bigint, bigint)
    IS 'Функция перемещает группу';


---======================================================================================================